param([ValidateSet('restart-on','restart-off')][string]$Name='restart-on')
$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$target=Join-Path $PSScriptRoot 'final'
$archive=Join-Path $PSScriptRoot $Name
if(Test-Path -LiteralPath $archive){throw 'Fresh restart evidence directory required'}
if(@(Get-Process -Name Metin2* -ErrorAction SilentlyContinue).Count){throw 'Another client is running'}
if($Name -eq 'restart-on') {
 New-Item -ItemType Directory -Path "$PSScriptRoot/final-matrix" | Out-Null
 foreach($file in @('frame-pacing.csv','frame-pacing-meta.txt','exit.json','source-resource-audit.log','terrain-renderer.log','p3-expected.json','summary.json','p3-run.jsonl')) {
  Copy-Item -LiteralPath "$target/$file" -Destination "$PSScriptRoot/final-matrix/$file"
 }
 $entry=[IO.File]::ReadAllText("$source/tests/Graphics/p3_runtime_entry.py")
 $indented=($entry -split "`n" | ForEach-Object {"    $_"}) -join "`n"
 $wrapped="import builtins, traceback`ntry:`n$indented`nexcept Exception:`n    with builtins.old_open('p3-failure.log', 'w') as failure:`n        failure.write(traceback.format_exc())`n    import app`n    app.Exit()`n"
 [IO.File]::WriteAllText("$target/test-root/root/prototype.py",$wrapped,[Text.UTF8Encoding]::new($false))
 & "$source/build-h2x/msvc/bin/Release/PackMaker.exe" --input "$target/test-root/root" --output "$target/pack" *> "$PSScriptRoot/restart-package.log"
 if($LASTEXITCODE -ne 0){throw 'Private restart package failed'}
}
New-Item -ItemType Directory -Path $archive | Out-Null
Copy-Item -LiteralPath "$target/config/graphics.cfg","$target/p3-expected.json" -Destination $archive
$arguments='--renderer-diagnostics --frame-pacing-capture --shader-cache-dir="'+"$target/shader-cache"+'"'
$watch=[Diagnostics.Stopwatch]::StartNew()
$process=Start-Process -FilePath "$target/Metin2_Release.exe" -WorkingDirectory $target -ArgumentList $arguments -WindowStyle Hidden -PassThru
while(-not $process.WaitForExit(1000)){if($watch.Elapsed.TotalSeconds -gt 30){$process.Kill();throw 'Owned restart smoke timeout'}}
$process.WaitForExit()
@{PID=$process.Id;ExitCode=$process.ExitCode;Seconds=$watch.Elapsed.TotalSeconds;Name=$Name;ExeSHA256=(Get-FileHash "$target/Metin2_Release.exe").Hash;PackSHA256=(Get-FileHash "$target/pack/root.pck").Hash} | ConvertTo-Json | Set-Content "$archive/exit.json"
if($process.ExitCode -ne 0){throw 'Restart failed'}
if(Test-Path "$target/p3-failure.log"){throw (Get-Content "$target/p3-failure.log" -Raw)}
foreach($file in @('frame-pacing.csv','frame-pacing-meta.txt','p3-restart.jsonl','source-resource-audit.log','terrain-renderer.log')) {Copy-Item -LiteralPath "$target/$file" -Destination "$archive/$file"}
Copy-Item -LiteralPath "$target/log/syserr.txt" -Destination "$archive/syserr.txt"
if((Get-Item -LiteralPath "$archive/syserr.txt").Length -ne 0){throw 'Python errors on restart'}
Get-Content "$archive/exit.json"
