param([string]$Name='pilot',[string]$Entry='p3_runtime_entry.py')
$ErrorActionPreference='Stop'
if($Name -notmatch '^[a-z0-9-]+$'){throw 'Invalid name'}
if($Entry -notmatch '^[a-z0-9_-]+\.py$'){throw 'Invalid entry filename'}
$source=Split-Path $PSScriptRoot -Parent
$original=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$target=Join-Path $PSScriptRoot $Name
if(Test-Path -LiteralPath $target){throw 'Fresh run required'}
New-Item -ItemType Directory -Path "$target/test-root","$target/pack","$target/log","$target/mark","$target/upload" | Out-Null
Copy-Item -LiteralPath "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe" -Destination "$target/Metin2_Release.exe"
Copy-Item -LiteralPath "$original/config" -Destination "$target/config" -Recurse
Copy-Item -LiteralPath "$original/assets/root" -Destination "$target/test-root/root" -Recurse
$entry=[IO.File]::ReadAllText("$source/tests/Graphics/$Entry")
$indented=($entry -split "`n" | ForEach-Object {"    $_"}) -join "`n"
$wrapped="import builtins, traceback`ntry:`n$indented`nexcept Exception:`n    with builtins.old_open('p3-failure.log', 'w') as failure:`n        failure.write(traceback.format_exc())`n    import app`n    app.Exit()`n"
[IO.File]::WriteAllText("$target/test-root/root/prototype.py",$wrapped,[Text.UTF8Encoding]::new($false))
foreach($package in Get-ChildItem -LiteralPath "$original/pack" -File){if($package.Name -ne 'root.pck'){New-Item -ItemType HardLink -Path "$target/pack/$($package.Name)" -Target $package.FullName | Out-Null}}
New-Item -ItemType Junction -Path "$target/bgm" -Target "$original/bgm" | Out-Null
& "$source/build-h2x/msvc/bin/Release/PackMaker.exe" --input "$target/test-root/root" --output "$target/pack" *> "$target/package.log"
if($LASTEXITCODE -ne 0){throw 'Packaging failed'}
Copy-Item -LiteralPath "$source/build-p0l-final-production/shader-cache" -Destination "$target/shader-cache" -Recurse
Get-FileHash -LiteralPath "$target/Metin2_Release.exe","$target/pack/root.pck" | ConvertTo-Json | Set-Content "$target/hashes.json"
Write-Output $target
