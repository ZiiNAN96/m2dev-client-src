param([string]$Name='pilot',[switch]$Pilot)
$ErrorActionPreference='Stop'
if($Name -notmatch '^[a-z0-9-]+$'){throw 'Invalid name'}
$target=(Resolve-Path -LiteralPath "$PSScriptRoot/$Name").Path
if(Test-Path "$target/exit.json"){throw 'Fresh run required'}
$others=@(Get-Process Metin2* -ErrorAction SilentlyContinue)
if($others.Count){throw 'Existing Metin2 process would contaminate measurement'}
if($Pilot){$env:M2_P3_PILOT='1'}else{Remove-Item Env:M2_P3_PILOT -ErrorAction SilentlyContinue}
Remove-Item Env:M2_MAP_LOAD_TRACE -ErrorAction SilentlyContinue

$started=Get-Date
$arguments='--renderer-diagnostics --frame-pacing-capture --shader-cache-dir="'+"$target/shader-cache"+'"'
$process=Start-Process -FilePath "$target/Metin2_Release.exe" -WorkingDirectory $target -ArgumentList $arguments -WindowStyle Hidden -PassThru
@{PID=$process.Id;Path="$target/Metin2_Release.exe";Arguments=$arguments;Started=$started.ToString('o');ExistingClients=0} | ConvertTo-Json | Set-Content "$target/launch.json"
while(-not $process.WaitForExit(1000)){if(((Get-Date)-$started).TotalSeconds -gt 180){$process.Kill();throw 'Owned P1 probe timeout'}}
$process.WaitForExit()
@{ExitCode=$process.ExitCode;Seconds=((Get-Date)-$started).TotalSeconds;PID=$process.Id} | ConvertTo-Json | Set-Content "$target/exit.json"
if($process.ExitCode -ne 0){throw 'P1 probe failed'}
if(Test-Path "$target/p3-failure.log"){throw (Get-Content "$target/p3-failure.log" -Raw)}
Get-Content "$target/exit.json"
