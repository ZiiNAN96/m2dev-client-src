# H2 bounded performance sanity

1024 x 768, fixed B1 camera and six actors; first 180 sample=1 frames per preset after two seconds of warmup. No outliers removed. Capture at six seconds is outside this window. CPU is elapsed frame work excluding Present and the existing limiter, not OS CPU accounting; GPU uses the existing asynchronous frame query. Runs are sequential without a concurrent build or GPU test. One bounded run per build/content combination; not a statistical benchmark or a 60/120-FPS claim. G8 and H2 use the same moving sky and fixed water time. A preexisting Metin2 process remained running unchanged; this is not a fully isolated machine benchmark. Hardware inventory is in evidence/hardware-*.json; it does not identify the adapter selected by Diligent.

baseline = committed G8; legacy = H2 with converted trees only; performance = H2 with one modern tree override and mask grass.

| Build / content | Preset | CPU avg / median / P95 / P99 ms | GPU avg / median / P95 / P99 ms |
| --- | --- | --- | --- |
| baseline | Low | 1.044 / 0.935 / 1.356 / 1.420 | 0.241 / 0.213 / 0.536 / 0.848 |
| baseline | Medium | 1.214 / 1.156 / 1.531 / 1.747 | 0.464 / 0.375 / 0.919 / 1.165 |
| baseline | High | 1.623 / 1.371 / 1.737 / 2.112 | 0.757 / 0.591 / 1.285 / 1.710 |
| baseline | Ultra | 1.660 / 1.600 / 1.969 / 2.430 | 0.942 / 0.814 / 1.688 / 2.027 |
| legacy | Low | 1.456 / 1.105 / 1.389 / 1.523 | 0.245 / 0.208 / 0.550 / 0.841 |
| legacy | Medium | 1.422 / 1.340 / 1.881 / 2.620 | 0.479 / 0.384 / 0.987 / 1.133 |
| legacy | High | 1.618 / 1.568 / 1.945 / 2.194 | 0.747 / 0.588 / 1.521 / 1.664 |
| legacy | Ultra | 1.969 / 1.862 / 2.521 / 3.445 | 0.932 / 0.828 / 1.645 / 2.125 |
| performance | Low | 1.438 / 1.079 / 1.348 / 12.093 | 0.372 / 0.205 / 1.064 / 3.338 |
| performance | Medium | 1.394 / 1.344 / 1.666 / 1.828 | 0.455 / 0.386 / 0.856 / 1.080 |
| performance | High | 1.608 / 1.555 / 1.937 / 2.183 | 0.722 / 0.591 / 1.205 / 1.633 |
| performance | Ultra | 2.008 / 1.946 / 2.338 / 2.466 | 0.913 / 0.795 / 1.740 / 1.878 |

## Windows GPU process memory

Sampled Windows GPU Process Memory counters, summed across adapters for the exact launcher PID. Samples use seconds 2 to 4.5 after the observer first sees each view, before capture and teardown. DedicatedUsage is GPU dedicated memory charged to the whole client; SharedUsage is system memory shared with the GPU. These are sampled process values, not isolated per-asset residency or the physical card capacity. The same lightweight observer ran during all three comparison runs.

| Build / content | Preset | Samples | Dedicated median / peak MiB | Shared median / peak MiB |
| --- | --- | ---: | --- | --- |
| baseline | Low | 3 | 124.72 / 124.72 | 15.20 / 15.20 |
| baseline | Medium | 3 | 177.31 / 177.31 | 15.82 / 15.82 |
| baseline | High | 3 | 252.30 / 252.30 | 19.59 / 19.59 |
| baseline | Ultra | 3 | 300.70 / 300.70 | 17.23 / 17.23 |
| legacy | Low | 3 | 124.85 / 124.85 | 16.22 / 16.97 |
| legacy | Medium | 3 | 177.88 / 177.88 | 15.86 / 15.86 |
| legacy | High | 3 | 252.70 / 252.70 | 18.27 / 18.27 |
| legacy | Ultra | 3 | 301.47 / 301.47 | 17.50 / 17.50 |
| performance | Low | 3 | 128.23 / 128.23 | 15.74 / 15.74 |
| performance | Medium | 3 | 181.23 / 181.23 | 15.86 / 15.86 |
| performance | High | 3 | 255.86 / 255.86 | 17.61 / 17.61 |
| performance | Ultra | 3 | 304.96 / 304.96 | 16.88 / 16.88 |

## Isolated vegetation color submission

Real D3D11 duration queries around DrawBatch. These exclude shadows, composite, Present and readback. Cold shader setup is retained in the raw CSV and is not a steady-state cost. Visible/draw/triangle counters refer to this color pass, not an entire native frame.

| Case | Submitted / visible / culled | Draws | Triangles | Uploads | Instance bytes | CPU ms | GPU color ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| beech-repeat | 1 / 1 / 0 | 2 | 1896 | 0 | 160 | 0.0483 | 0.00976 |
| beech-dense | 600 / 600 / 0 | 4 | 1137600 | 4 | 96000 | 0.8454 | 0.379776 |
| beech-behind-camera | 600 / 0 / 600 | 0 | 0 | 0 | 0 | 0.0535 | 3.2e-05 |
| grass-repeat | 1 / 1 / 0 | 1 | 32 | 0 | 80 | 0.0158 | 0.011648 |
| grass-dense | 1000 / 1000 / 0 | 2 | 32000 | 2 | 80000 | 0.4329 | 0.065248 |
| grass-behind-camera | 1000 / 0 / 1000 | 0 | 0 | 0 | 0 | 0.0871 | 0 |
| bush-repeat | 1 / 1 / 0 | 2 | 858 | 0 | 160 | 0.0169 | 0.01392 |
| bush-dense | 600 / 600 / 0 | 4 | 514800 | 4 | 96000 | 0.2739 | 0.269728 |
| bush-behind-camera | 600 / 0 / 600 | 0 | 0 | 0 | 0 | 0.0599 | 0 |

Instance bytes are allocated buffer capacity and can exceed the current visible set. Process VRAM is measured above; it is not attributed to individual vegetation assets. Geometry/material/texture sharing and zero shutdown resources are asserted separately.
