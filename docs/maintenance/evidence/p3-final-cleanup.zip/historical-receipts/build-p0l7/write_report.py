import csv
import json
from pathlib import Path

base = Path('build-p0l/l7-before')
after = Path('build-p0l/l7-after')
old = json.loads((base/'animation-loading.json').read_text())
new = json.loads((after/'animation-loading.json').read_text())
gate = json.loads((after/'animation-gate.json').read_text())
parallel = json.loads((after/'gr2-parallel-comparison.json').read_text())
a, b = old[1], new[1]
ma, mb = a['metrics'], b['metrics']
f = lambda x: f'{x:.3f}'
decode_total = sum(g['decode_wall_ms'] for g in a['categories'].values())
share = ma['decode_wall_ms']/decode_total*100
text = f'''# P0-L7 – Animation Loading Bottleneck

## P0-L7 SUMMARY

17.09.2026: **NO-GO nach dem vollständigen angeforderten kurzen Offline-Gate. Kein Commit, kein Push. STOP nach genau einem Animations-Fix.**

Der Ladefix ist wirksam und korrekt: A1 Cold **{f(a['total_ms'])} → {f(b['total_ms'])} ms**, **{f(gate['cold_saved_ms'])} ms / {f(gate['cold_saved_percent'])} %** weniger. **{f(share)} % der GR2-Dekompressions-Wallzeit** entfällt vor dem Fix auf Animationen. Genau ein funktionaler Fix wurde implementiert: begrenzte parallele native GR2-Vorbereitung innerhalb der vorhandenen synchronen Python-Ladestufe.

**GO-Blocker:** Beim ersten Attack/Death bleiben Frame-Spitzen über dem vorhandenen 50-ms-Stabilitätsbudget; Player Death nachher **79.307 ms**. Der Vergleich mit der gesicherten Vorher-EXE zeigt bereits dort entsprechende Spitzen (Player Attack 54.233 ms, Death 70.655 ms). In diesen Fenstern gibt es **0 GR2-Parses**; die Kosten liegen in `Document::BoundClip` / `GR2::BindAnimation`. Der Fix verschiebt keine GR2-Arbeit nach dem First Frame. Trotzdem ist „keine First-Use-Stalls“ nicht erfüllt und wird nicht als PASS umgedeutet. Keine zweite Optimierung an BindAnimation/Prewarm begonnen.

## STARTSTAND / SCOPE

- Source: `m2dev-client-src`, Branch `codex/g56-hdr-atmosphere`, HEAD **873d989**; davor `73dc92e`, `5563d78`.
- Separates Runtime-/Python-Source-Repository: `m2dev-client`, Branch `codex/g56-hdr-colors`, HEAD **548c43b4**.
- Vorbestehend untracked: Source `docs/performance/p0l3-shader-pso-breakdown.md`, Runtime `docs/p0l-map-loading-deployment.json` und `docs/p0l2-shader-loading-deployment.json`. SHA256-identisch erhalten; nichts gestagt.
- Einzige Änderung im Runtime-Repository ist **Python-Source** `assets/root/playersettingmodule.py`: vorhandenen `load()`-Aufruf synchron durch `chrmgr.LoadMotionDataBatch(load)` ausführen, mit `hasattr`-Kompatibilität für ältere Clients.
- Originalclient-EXE und Original-`root.pck` SHA256-identisch. Kein Deployment; die Messungen verwenden private Offline-Probes mit Originalpacks und jeweils einem privaten Root-Pack.
- Area-Parallelismus (`Area.cpp`) und SSE2-Decoder (`GR2Compression.cpp`) SHA256-identisch. Keine Änderungen an Shadercode, Renderer, Terrain, Vegetation, GR2-Format, Clips, Keyframes oder Qualität. Alle **73** gefüllten Shadercache-Dateien nach allen Läufen hash-identisch.

## REALER PRODUKTIVER CALL PATH / THREAD SAFETY

| Stufe | Produktiver Pfad / Zustand | Klassifikation |
| --- | --- | --- |
| Request / MSA | `playersettingmodule.LoadGameData` → `chrmgr.RegisterCacheMotionData` → `CRaceData::RegisterMotionData` → `CRaceMotionData::LoadMotionData`; MSA liefert tatsächlichen GR2-Pfad und Motion-ID | **OWNER THREAD ONLY**: Python/GIL, Textloader, Race-Pools, Effekte |
| Registrierung / Cache lookup | `NEW_RegisterMotion` → `CResourceManager::GetResourcePointer`; unveränderte Pfadnormalisierung/CRC und CResource-Identität | **OWNER THREAD ONLY**: Resource-Maps, statische Pfadbuffer, Motion-Vektoren |
| File read / Input | `CPackManager::GetFile`, pro neu vorbereitetem Pfad eigener Payload-Vektor | Packintern **SHARED LOCKED**, vollständiger Consumer-/Diagnosepfad bewusst **OWNER THREAD ONLY** |
| Header / CRC / Decode | `GR2::File` → `Inspect` → Section-Dekompression; Oodle1-Decoder, adaptive Tabellen und Scratch | **THREAD LOCAL**; unveränderliche CRC-Tabelle nach sicherer statischer Initialisierung **THREAD SAFE** |
| Section parsing | Bounds, Fixups, Relocations, `Types`, Typgraph | **THREAD LOCAL**; Sections einer Datei fertig vor dem Objektgraph |
| Animation parsing / Trackdaten | `Read` → `ReadAnimation` → `ReadCurve`; eigene Gruppen, Namen, Knot-/Control-Vektoren, Counts und Metadaten | **THREAD LOCAL**; kein globaler Clipcache, keine Runtime-Registrierung |
| CPU Skeleton-IR | `RuntimeSkeleton::Initialize` falls im Container vorhanden | Daten **THREAD LOCAL**; Lebensdauerzähler atomar **THREAD SAFE**, BindingId Inhalts-Hash |
| Publish / Cache | Provider `Preparation::Take` → `Document`; `CResource::Load`, `LoadStaticCache`, `CGraphicThing::LoadMotions`, `CGrannyMotion::BindAsset` | **OWNER THREAD ONLY**, ursprüngliche Anfragefolge |
| Skeleton lookup / Bone mapping | Actor `SetRace` / `RegisterMotionThing`; `Instance::SetMotion` → `Document::BoundClip` → `FindTransformTrack` | **OWNER THREAD ONLY**: Actorzustand und mutable Document-Bindings |
| ZiiNAN Runtime preparation | `BindAnimation` → `ConvertCurve` → `RuntimeAnimationClip::Initialize`, Skeleton-Binding und Keyframevorbereitung | weiterhin **OWNER THREAD ONLY**, unverändert; nicht mit GR2-Dateidecode verwechseln |
| IDs / Handles | AssetId aus Pfad; Clip-/Modellindex aus unveränderter Dateireihenfolge; BoneId aus originalem Index; Runtime BindingId aus Skeletoninhalt | deterministisch, keine Vergabe durch Worker-Scheduling; Owner-Publish |
| MapLoadTrace | Worker-eigener TLS-State, Intervall-/Zählermerge erst nach allen Joins | **THREAD LOCAL** bis Join, danach **OWNER THREAD ONLY** |
| AnimationStallAudit | gemeinsame mutable Audit-/Framezähler | **OWNER THREAD ONLY**; bei aktivem Audit ist Preparation deaktiviert und der serielle Pfad bleibt erhalten |
| GPU / Materials / Motion-Adapter | unveränderter Consumerpfad nach dem Join | **OWNER THREAD ONLY**; keine GPU-Aufrufe in Workers |

Temporäre Eingabe-/Section-/Kurvenbuffer gehören jeweils dem Dateijob. `Contents` besitzt den kompletten Output; keine geliehenen GR2-Referenzen überleben den Job. Worker-Ausnahmen werden im Ergebnis gesammelt; der Owner erzeugt weiterhin `InvalidAsset`. Der vorhandene Preparation-Executor joint bereits gestartete Jobs auch bei Submission-/Futurefehlern. Kein Hintergrundjob überlebt die synchrone Ladestufe.

## BEFORE / AFTER

Neue Prozesse, identische Einstellungen und Originalpacks, gefüllter Shadercache. „Cold“ bedeutet Prozess-cold, **kein geleerter OS-Dateicache**. Warm ist A1 nach **A1 → B1 → A1**. Endpunkt: drei stabile World-Presents ohne neue Lade-/Upload-/Compilearbeit; Screenshots folgen danach. Ein akzeptiertes Vorher-/Nachher-Paar, keine statistische Benchmarkserie.

| Messung | Before ms | After ms | Ersparnis ms | % |
| --- | ---: | ---: | ---: | ---: |
'''
rows = [('A1 Cold TOTAL', a['total_ms'], b['total_ms']), ('A1 Warm TOTAL', old[-1]['total_ms'], new[-1]['total_ms']),
        ('A1 Cold GR2 Wall', a['gr2_wall_ms'], b['gr2_wall_ms']),
        ('Animation Decode Wall', ma['decode_wall_ms'], mb['decode_wall_ms']),
        ('Animation Parse Wall, inkl. Referenzen', ma['parse_wall_ms'], mb['parse_wall_ms']),
        ('Animation Parse kumuliert, exklusiv', ma['parse_exclusive_ms'], mb['parse_exclusive_ms']),
        ('Animation Runtime Preparation', ma['runtime_prep_ms'], mb['runtime_prep_ms']),
        ('GR2 Dekompression Wall gesamt', decode_total, sum(g['decode_wall_ms'] for g in b['categories'].values())),
        ('Animation Decode kumulierte Dauer', ma['decode_cumulative_ms'], mb['decode_cumulative_ms']),
        ('Animation Parse kumulierte Dauer', ma['parse_cumulative_ms'], mb['parse_cumulative_ms']),
        ('B1 TOTAL', old[2]['total_ms'], new[2]['total_ms'])]
for name, x, y in rows:
    text += f'| {name} | {f(x)} | {f(y)} | {f(x-y)} | {f(100*(x-y)/x) if x else "—"} |\n'
text += f'''
**CPU und Wall getrennt:** Decode-Wall ist die Vereinigung überlappender Decodeintervalle je Batch plus serielle Decodezeit. Parse-Wall entsprechend für `ReadAnimation`. Decode und Parse verschiedener Dateien können überlappen: ihre Wallwerte **nicht addieren**. GR2 Wall verwendet kumulierte exklusive GR2-Dauern minus Worker-Dauern plus Batch-Wartefenster. Kumulierte Bereichsdauer ist verstrichene Zeit innerhalb CPU-Code, nicht reine Thread-CPU. Die zusätzlich erfassten Windows-Threadzeiten sind grob quantisiert.

Die früher genannten ~405 ms waren **exklusive** Kurvenparsezeit. Hier ist die vergleichbare neue Before-Zahl {f(ma['parse_exclusive_ms'])} ms; für die echte Stage-Wall-Messung einschließlich Referenzauflösung werden {f(ma['parse_wall_ms'])} ms verwendet. Die kumulierte CPU-Bereichsdauer steigt unter Parallelität etwas; der Gewinn stammt aus Überlappung. Runtime-Preparation schwankt wegen normaler Zufallsauswahl von Idle-Varianten; diese 41.284 → 91.732 ms sind kein zusätzlicher Fix. Warm decodiert und parst weder vorher noch nachher eine GR2-Datei. Seine kleine Differenz wird nicht als Parallelgewinn ausgegeben.

## ANIMATION FILES

| A1 Cold | Before | After |
| --- | ---: | ---: |
'''
for key in ('requests','unique','loads','parses','cache_hits','compressed_bytes','expanded_bytes'):
    text += f'| {key} | {ma[key]} | {mb[key]} |\n'
text += '''
Requests sind tatsächliche `GetResourcePointer`-Aufrufe, Cache hits bestehende CResource-Lookups; ein Lookup-Hit allein bedeutet nicht zwingend bereits decodierten Inhalt. „Loads“ zählt tatsächliche leere CResources, „Parses“ tatsächliche native GR2-File/Read-Ausführungen. Keine doppelten Parses; auch über A1 → B1 → A1 insgesamt unverändert 903 Dateien. A1 Warm: Requests/Loads/Parses/Decode jeweils 0; vorhandene Motion-/Document-Referenzen bleiben nutzbar.

## DECOMPRESSION BY CATEGORY

Animation wird durch den **tatsächlichen geparsten AnimationCount** erkannt, nicht durch Clipnamen. Die übrigen Container werden anhand ihres realen VFS-Bereichs den Area-/Prop- oder Actor-/Model-Pfaden zugeordnet. Alle A1-Dateien sind klassifiziert, Other=0. Bytes beziehen sich auf Section-Payloads; Dateiheader/Typmetadaten außerhalb komprimierter Sections sind nicht „compressed bytes“.

| Kategorie | Dateien | Compressed B | Expanded B | Before kumuliert ms | Before Wall ms | After Wall ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('Area/Prop','Animation','Actor/Model','Other'):
    x,y=a['categories'][name],b['categories'][name]
    text += f"| {name} | {x['files']} | {x['compressed_bytes']} | {x['expanded_bytes']} | {f(x['decode_cumulative_ms'])} | {f(x['decode_wall_ms'])} | {f(y['decode_wall_ms'])} |\n"
text += f'''
**Exakte Antwort für die frische Baseline:** Animationen verursachen **{f(ma['decode_wall_ms'])} von {f(decode_total)} ms = {f(share)} %** der Dekompressions-Wallzeit. Kumuliert sind es {f(ma['decode_cumulative_ms'])} von {f(sum(g['decode_cumulative_ms'] for g in a['categories'].values()))} ms. Die historischen ~1140 ms von P0-L6 werden nicht nachträglich geschätzt oder mit dem neuen Lauf vermischt.

## FIRST PLAYABLE / SOFORT ALLE CLIPS?

Ja, der Player-Startup ruft `RegisterCacheMotionData` für beide Geschlechter aller vier Klassen auf. MSA-Dateien werden registriert und ihre GR2-Dateien synchron in den Static Cache geladen, auch wenn der sichtbare Actor diese Motion nicht abspielt. Weitere nur registrierte Emote-/NPC-/Mob-Clips bekommen spätestens bei `CActorInstance::SetRace` über `RegisterMotionThing` eine Resource-Referenz und werden dabei geladen. `RegisterRaceName` allein lädt dagegen nicht alle NPC-Dateien.

Die Diagnose zeichnet `animation-registration` als **GR2-Pfad | Race-ID | Motion-Mode | Motion-ID** auf; `animation-actor-reference` belegt tatsächlich instanziierte Rassen, `animation-active-mode` den angeforderten Actor-Mode und `animation-use-before-present` einen erfolgreichen nativen `SetMotion` vor dem ersten World-Present. Cliptypen im Report stammen aus den Motion-ID-Enums, nicht aus Dateinamen.

| Klasse im beobachteten A1-Start | Dateien | Before GR2-Dateikosten ms | Decode ms | Parse ms |
| --- | ---: | ---: | ---: | ---: |
'''
for name, g in a['first_playable'].items():
    text += f"| {name} | {g['files']} | {f(g['cumulative_total_ms'])} | {f(g['decode_ms'])} | {f(g['parse_ms'])} |\n"
unused = a['first_playable']['DEFERABLE']['cumulative_total_ms']
text += f'''
- **CRITICAL:** die vier tatsächlich vor dem Present gebundenen Clips, einschließlich anfänglichem General- und anschließendem Waffen-Idle. Sie werden vom realen Startpfad benötigt.
- **NEAR:** sechs weitere registrierte Idle-/Walk-/Run-Referenzen der tatsächlich vorhandenen Actors in ihren angeforderten Modes.
- **DEFERABLE:** alle übrigen 683 Dateien ohne vorzeitigen Playback-Request; die vollständige Datei-Zuordnung mit Race-/Motion-Referenzen steht im lokalen `animation-loading.json` und `build-p0l7/animation-files.csv`. Das ist eine Beobachtung dieses A1-Starts, **keine Garantie** für beliebige Gameplay-/Netzwerksituationen oder sicheres späteres Streaming.

Die noch nicht abgespielten Dateien kosten vor dem Fix **{f(unused)} ms / {f(100*unused/a['total_ms'])} % A1 Cold**. Das ist theoretisches Verschiebepotenzial, keine als sicher freigegebene Lazy-Loading-Ersparnis. Der nachgewiesene Runtime-First-Use-Hitch spricht zusätzlich gegen aggressives Verschieben.

## SELECTED FIX / SINGLE FLIGHT / DETERMINISMUS

**A) bounded parallel animation decode/parse**, genau ein Fix. Vorhandenen `GR2::Preparation`-Mechanismus in eine explizite synchrone Python-Ladegrenze eingebunden. `RegisterMotionData` und MSA-/Race-Registrierung laufen unverändert sofort auf dem Owner; nur die bisher unmittelbar anschließenden Static-Cache-Ladevorgänge werden innerhalb dieser Callback-Grenze in Gruppen von maximal 32 Anforderungen gesammelt. Der letzte Teilbatch wird auch bei einer Python-Ausnahme abgearbeitet, bevor der Fehler zurückgegeben wird. Außerhalb dieser expliziten Grenze bleibt die bisherige API seriell.

Der Owner liest neue, noch nicht geladene GR2-Payloads. Der bestehende CGameThreadPool verarbeitet File/Read mit höchstens **min(Poolgröße, 4, max(1, Hardwarethreads−2), Dateizahl)** Lanes. Maximal 32 Ergebnisdateien / bestehende 16-MiB-Input-Aufnahmeschwelle je Batch; der letzte Input kann die Schwelle überschreiten, weitere Inputs fallen auf den bisherigen seriellen Pfad zurück. Kein neuer Threadpool, keine Section-Parallelisierung, keine verschachtelten Pool-Jobs. Gemessener Pool: 16 logische CPUs / 16 Poolthreads, maximal 4 aktive Jobs.

Nach allen Joins erfolgen Static-Cache-Loads/Provider-Publish in ursprünglicher Anfragereihenfolge. Vorbereitungsschlüssel normalisieren Slash-/Großschreibung und vereinigen doppelte Pfade **vor Read/Parse**. Wiederholungen nach Veröffentlichung nutzen den bestehenden Cache. Kein Worker greift auf ResourceManager, Python, mutable Clipcache oder IDs/Handles zu. Neue Implementierung verändert weder Tracks noch deren Reihenfolge noch die Kurven-/Runtimealgorithmen.

Produktiver Scope: **646 von 693** A1-Animationsdateien in den Batches. Die übrigen 47 Animationen aus den bisherigen nicht gecachten Registrierungs-/Actorpfaden bleiben seriell; insbesondere `emotion.py` benutzt `RegisterMotionData`, nicht `RegisterCacheMotionData`. Alle 693 sind weiterhin vor dem First Frame geladen. Keine Clips ausgelassen/gelöscht/verkürzt, kein Deferring, keine neue Backgroundlast nach der Ladestufe. Der vorhandene Area-Batch-Scope bleibt 98 A1-Dateien / 67 B1-Dateien.

Kandidatenentscheidung: Parallelisierung nutzt den größten gemessenen Block (1025.533 ms Decode plus 430.777 ms Parse) bei begrenztem Consumer-Umbau und vorhandener deterministischer IR. Deferring hätte größeres theoretisches Verschiebepotenzial, aber keinen sicheren First-Use-Nachweis. Ein Parser-Mikrofix hätte nur einen Teil der 430.777 ms beeinflusst und wurde nicht zusätzlich umgesetzt.

## ANIMATION CONCURRENCY

| Messwert, nur A1-Animation-Batches | Wert |
| --- | ---: |
'''
c=b['concurrency']
for label,value in [('Dateijobs',c['animation-jobs']),('Peak concurrency',c['peak']),('Average concurrency',f(c['average'])),
                    ('Worker busy ms',f(c['animation-worker-busy-ns']/1e6)),('Batch wall ms',f(c['animation-worker-wall-ns']/1e6)),
                    ('Grobe kumulierte Worker Thread-CPU ms',f(c['animation-worker-cpu-ns']/1e6)),('Single-flight joins',c['animation-single-flight-joins'])]:
    text+=f'| {label} | {value} |\n'
text+='''
Average = Summe aktiver Jobdauern / Summe der Batch-Wartefenster. Joins zählen identische normalisierte Pfade innerhalb eines Batches; spätere Cachetreffer sind getrennt erfasst. B1 und Warm haben 0 Animation-Jobs. Keine Oversubscription durch zusätzliche Pools; die normalen vorhandenen Pool- und Owner-Grenzen bleiben erhalten.

## TOP 30 ANIMATION FILES – BEFORE

Total ist die Summe exklusiver dateizuordbarer Bereiche einschließlich vorhandener Owner-Preparation. Decode / Parse / Prep sind ihre gesonderten Stage-Dauern; Parse enthält Referenzauflösung. Deshalb nicht sämtliche Spalten blind addieren. „Race“ stammt aus realer Registrierung; Pfad liefert zusätzlich den Actornamen. Größen sind komprimierte Sectionbytes bzw. expandierte Sectionbytes.

| # | Path | Compressed B | Expanded B | Sections | Decode ms | Animation parse ms | Runtime prep ms | Total ms | Race IDs | Cliptyp |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
'''
for i,x in enumerate(a['animations'][:30],1):
    races=','.join(map(str,sorted({r[0] for r in x['registration_references']})))
    text+=f"| {i} | `{x['path']}` | {x['compressed_bytes']} | {x['expanded_bytes']} | {x['sections']} | {f(x['decompression_ms'])} | {f(x['animation_parse_ms'])} | {f(x['runtime_prep_ms'])} | {f(x['total_ms'])} | {races} | {', '.join(x['clip_types'])} |\n"
text+='''
## CORRECTNESS

- **PASS:** frisch gegen die gemessenen A1/B1-Pfade validierter Corpus: 903 Dateien, 7224 Sections, **60.042.028 expandierte Bytes bytegleich** seriell vs parallel. Inputgrößen und native Payload-CRCs gegen den Packtrace geprüft.
- **PASS:** komplette relevante IR-Felder bitgleich: 217 Modelle, 281 Meshes, 282 Materialien, 217 Skeletons, 729 Bones, **693 Animationen**. Namen, IDs, Dauer/TimeStep, Track-/Gruppenreihenfolge, Bone-Referenzen, alle Knot-/Controlwerte, Events, Bind-Matrizen und Skeleton-EvaluationOrder im Vergleich. Kein Pointer-/Paddingvergleich.
- **PASS:** 13 reale Modell-/Clip-Paare: Warrior Idle/Walk/Run/Attack/Damage/Death, Wildhund dieselben sechs Typen, Goods-NPC Idle. Alle Runtime-Keys, Zielbones, Track-Interpolation, Duration, Looping und BindingIds bitgleich für Once- und Loop-Ränder; anschließend **234 exakte Provider-/Runtime-Posevergleiche**. Prepared Provider-Publish führt keinen zweiten Parse aus; AssetId und Handle-Indizes gleich.
- **PASS:** 903 halbierte Dateien zusammen mit gültigen Dateien sauber abgelehnt. Synthetische malformed/truncated Dateien weiter `InvalidAsset`; vier wiederholte Batches mit Pfadalias-/Duplikatanfragen sowie injizierter Executorfehler. Keine beobachteten Race-/Deadlocksymptome, alle Jobs gejoint, Lebensdauerzähler 0. Kein ThreadSanitizer-Lauf behauptet.
- **PASS:** native Before-/After-Traces: identische Requests/Hits/Misses, Registrierungen/Actorreferenzen, Parsepfade, CRCs, Sectionbytes, Modell-/Skeleton-/Animationscounts, Kopierbytes und Shaderbytecodes. Keine ausgelassene Datei und keine zusätzliche Warm-Decodierung.

## FAST GATE – FAIL wegen verbleibender First-Use-Stalls

| Check | Ergebnis |
| --- | --- |
| Release Build, finale gemessene EXE | PASS, Exit 0; vorhandene Vendor-/Linkerwarnungen |
| Animation-Korrektheit / focused tests | PASS, 7/7: Preparation, Independence, Safety, Compatibility, static/animation Golden, Warmup |
| A1 Cold / A1 Warm / A1 → B1 → A1 | PASS, je frischer Before-/After-Prozess |
| Kurzer Actor-/Mob-Smoke | PASS für vorhandene/ausgeführte Idle, Walk, Run, Attack, Damage, Death; reale erfolgreiche Native-Requests für beide Actors überprüft |
| Keine First-Use-Stalls | **FAIL**: 4 After-Fenster >50 ms; Runtime-Vorbereitung bleibt synchron beim ersten Binding |
| Diligent ERROR/FATAL | 0 / 0 |
| GPU fallback / CPU deformation | 0 / 0 |
| Shutdown resources / Exit | alle 30 geprüften Fehler-/Resourcezähler 0, alle vier Prozesse Exit 0 |
| Shadercompile / Cachemiss | 0 / 0 im Messpaar; Cachedateien hash-identisch |

Die „fast-gate.json“-Dateien des älteren Map-/Resource-Verifiers melden nur dessen begrenzte Teilprüfungen PASS. Das vollständige **P0-L7-Gate** ergänzt die First-Use-Prüfung und steht in `l7-after/animation-gate.json` ausdrücklich auf **FAIL / NO-GO**.

Smoke je Motion eine Sekunde, nach dem Map-Gate, ohne Netzwerklogin; Locomotion über normale Loop-API, Attack/Damage/Death über normale Once-Queue. Erfolgreiche Playbackpfade werden gegen reale Race-/Motion-Registrierungen abgeglichen. Screenshot-I/O ist aus den gemeldeten nachfolgenden Frameintervallen ausgenommen. 50 ms ist das schon vorhandene Probe-Stabilitätsbudget, keine Behauptung, 49 ms seien unsichtbar. Ein 79-ms-Frame mit 79 ms Runtime-Preparation erlaubt kein uneingeschränktes „keine sichtbaren Hänger“. Kurze Screenshot-Sichtprüfung bestätigt Player/NPC/Mob und Posen; keine manuelle Vollprodukt-/Originalclient-Abnahme behauptet.

| Actor / Motion | Before max frame ms | After max frame ms | After Runtime prep im Fenster ms |
| --- | ---: | ---: | ---: |
'''
for x,y in zip(gate['smoke_before'],gate['smoke_after']):
    text+=f"| {y['actor']} / {y['motion']} | {f(x['max_frame_ms'])} | {f(y['max_frame_ms'])} | {f(y['runtime_preparation_ms'])} |\n"
text+='''
Alle Smoke-Fenster haben **0 neue GR2-Parses**. Zufällige Idle-/Attack-/Damagevarianten können zwischen Prozessen wechseln; die gleichen verfügbaren Referenzen und deren Inhalte sind separat exakt geprüft. Die First-Use-Spitzen sind also schon im seriellen Referenzpfad vorhanden, aber nicht beseitigt.

## REPRODUKTION / BELEGE

Lokale, nicht zu commitende Belege:

- `build-p0l/l7-before`: neue Baseline, PID 6304, Exit 0; `animation-loading.json`, `gr2-pipeline.json`, Native-Logs, Bilder, Resource-Gate.
- `build-p0l/l7-after`: finaler funktionaler Fix, PID 19324, Exit 0; A/B- und vollständiges P0-L7-Gate.
- `build-p0l/l7-smoke-before` / `build-p0l/l7-smoke`: identischer Smoke mit gesicherter Before-/After-EXE, PIDs 8608 / 37128, beide Exit 0; jeweils `animation-smoke.json` und native Tracefenster.
- `build-p0l7`: Release-/Test-/Corpuslogs, `decoder-files.txt`, `runtime-pairs.txt`, komplette Datei-Klassifikation `animation-files.csv`, Hashbelege. Unbekannte vorherige Dateien erhalten.

EXE SHA256 Before: `54DABF9B24CBCECFBE97D52C04A5DF1405C29E735F35D62569327363367F949B`.
After, Smoke und aktueller Release-Build: `E1826294B2E24FAB400B94502432B704A27DAFFD9E4BDC7B2ACB808259ED254F`.

```powershell
# Vorhandene VS-x64-Umgebung; Python-Source im separaten Runtime-Checkout gehört zum Fix.
cmake --build build-h2x/msvc --config Release --target UserInterface GR2PreparationTest GR2SafetyTest GR2CompatibilityTest GR2GoldenTest GR2WarmupTest --parallel 6
ctest --test-dir build-h2x/msvc -C Release -R '^AssetRuntime.GR2(Safety|Compatibility|Golden\.(static|animation)|Preparation|Independence|Warmup)$' --output-on-failure
build-h2x/msvc/tests/AssetRuntime/Release/GR2PreparationTest.exe build-p0l7/decoder-files.txt build-p0l7/runtime-pairs.txt
tests/Loading/run_shader_cache_probe.ps1 -Name fresh-l7 -CacheDirectory C:/absolute/filled-cache -ShaderLifecycle
python tests/Loading/verify_probe.py build-p0l/fresh-l7 --shader-lifecycle
python tests/Loading/animation_loading.py build-p0l/fresh-l7
tests/Loading/prepare_probe.ps1 -Name fresh-l7-smoke -ShaderLifecycle -AnimationSmoke
tests/Loading/run_probe.ps1 -Name fresh-l7-smoke -ShaderCacheDirectory C:/absolute/filled-cache
python tests/Loading/verify_probe.py build-p0l/fresh-l7-smoke --shader-lifecycle --animation-smoke
python tests/Loading/verify_animation_loading.py build-p0l/l7-before build-p0l/l7-after build-p0l/l7-smoke-before build-p0l/l7-smoke
# Letzter Check liefert bewusst Exit 1 / NO-GO wegen der belegten First-Use-Spitzen.
```

Der erste Buildversuch scheiterte am sandboxbedingten Zugriff auf das vorhandene Windows SDK; der Build in der autorisierten VS-Umgebung war erfolgreich. Native Probe-Starts unverändert über den vorhandenen Windows-Startpfad, kein Manifest-/Admin-Umbau.

## NEXT BOTTLENECK / COMMIT / STOP

Größter verbleibender gemessener GR2-Ladeblock: **608.492 ms GR2-Dekompressions-Wall gesamt**, davon **520.205 ms Animationen**; Animationsparse-Wall **305.865 ms** (zwischen Worker-Stufen überlappend, nicht additiv). Daneben ist **späte Runtime-Clip-Vorbereitung bis 79.078 ms im Death-Fenster** der konkrete GO-Blocker. Nur dokumentiert.

**Commit-Hash: keiner. HEAD bleibt 873d989; Runtime-HEAD bleibt 548c43b4.** Änderungen liegen prüfbar und ungestagt in beiden Source-Bereichen. Kein Commit trotz Cold-Gewinn, weil das explizite GO-Kriterium fehlt. Keine Logs, Traces, Buildoutputs, Cachedateien, Testclients oder Backups gestagt; kein Push. Nach genau diesem einen Fix STOP. Kein persistenter GR2-Cache, kein P1, keine weitere Shader-/Parser-/Prewarm-Optimierung.
'''
Path('docs/performance/p0l7-animation-loading.md').write_text(text, encoding='utf-8')
with Path('build-p0l7/animation-files.csv').open('w', newline='', encoding='utf-8') as out:
    writer=csv.writer(out)
    writer.writerow(['path','classification','race_mode_motion_references','clip_types','compressed_bytes','expanded_bytes','decode_ms','parse_ms','runtime_prep_ms','total_ms'])
    for x in a['animations']:
        writer.writerow([x['path'],x['first_playable'],x['registration_references'],x['clip_types'],x['compressed_bytes'],x['expanded_bytes'],x['decompression_ms'],x['animation_parse_ms'],x['runtime_prep_ms'],x['total_ms']])
print('Wrote report and',len(a['animations']),'per-file classifications; decision',gate['decision'])
