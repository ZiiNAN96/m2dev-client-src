from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
def edit(file, transform):
    p=root/'src'/file
    s=p.read_bytes().decode('latin1').replace('\r\n','\n')
    old=s
    s=transform(s)
    assert s!=old,file
    if '#include "EterBase/MapLoadTrace.h"' not in s:
        pos=s.find('\n')+1
        s=s[:pos]+'#include "EterBase/MapLoadTrace.h"\n'+s[pos:]
    p.write_bytes(s.replace('\n','\r\n').encode('latin1'))
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b,1)
def scope(s,signature,phase,name,kind='cpu',extra=''):
    i=s.index(signature); i=s.index('{',i)+1
    return s[:i]+f'\n    MapLoadTrace::Scope p0lScope("{phase}","{name}","{kind}");\n'+extra+s[i:]
def scopes(file,items):
    def apply(s):
        for item in items:s=scope(s,*item)
        return s
    edit(file,apply)
scopes('GameLib/MapManager.cpp',[
 ('void CMapManager::Initialize()', 'Metadata','map index'),
 ('void CMapManager::LoadProperty()', 'Metadata','property registry'),
 ('bool CMapManager::LoadMap(', 'Metadata','map load orchestration'),
 ('void CMapManager::Destroy()', 'Metadata','map teardown')])
scopes('GameLib/MapOutdoorLoad.cpp',[
 ('bool CMapOutdoor::Load(', 'Metadata','outdoor orchestration'),
 ('bool CMapOutdoor::LoadSetting(', 'Metadata','settings and material setup'),
 ('bool CMapOutdoor::LoadTerrain(', 'Terrain','sector load'),
 ('bool CMapOutdoor::LoadArea(', 'Static objects','area load')])
scopes('GameLib/AreaTerrain.cpp',[
 ('bool CTerrain::LoadHeightMap(', 'Terrain','height and normals'),
 ('bool CTerrain::RAW_LoadTileMap(', 'Terrain','tile and splat data'),
 ('void CTerrain::RAW_AllocateSplats(', 'Terrain','splat allocation'),
 ('void CTerrain::RAW_GenerateSplat(', 'Terrain','splat generation'),
 ('void CTerrain::CalculateTerrainPatch()', 'Terrain','geometry generation'),
 ('bool CTerrain::LoadGrassData(', 'Vegetation','grass source preparation','cpu','    MapLoadTrace::Count("grass-source",c_pszFileName);\n'.replace('c_pszFileName','directory'))])
scopes('GameLib/Area.cpp',[
 ('bool CArea::Load(', 'Static objects','placement and instances','cpu','    MapLoadTrace::Count("area-build",c_szPathName);\n'),
 ('bool CArea::__Load_LoadObject(', 'Static objects','placement parsing'),
 ('void CArea::__Load_BuildObjectInstances()', 'Static objects','instance build'),
 ('void CArea::__SetObjectInstance_SetBuilding(', 'Static objects','building preparation'),
 ('void CArea::__SetObjectInstance_SetTree(', 'Vegetation','tree bush placement preparation'),
 ('void CArea::__SetObjectInstance_SetEffect(', 'Effects','world effects'),
 ('void CArea::Refresh()', 'Static objects','area refresh')])
scopes('GameLib/WorldTree.cpp',[
 ('WorldTreePtr CreateWorldTree(', 'Vegetation','tree bush instance creation'),
 ('std::shared_ptr<NativeResources> Resources(', 'Vegetation','render asset preparation')])
scopes('Vegetation/VegetationFormat.cpp',[
 ('Result Registry::Parse(', 'Vegetation','registry parse','cpu','    MapLoadTrace::Count("registry-parse","vegetation");\n')])
scopes('Vegetation/VegetationRuntime.cpp',[
 ('LoadResult Runtime::Load(', 'Vegetation','registry and override lookup'),
 ('LoadResult Runtime::LoadCompiled(', 'Vegetation','compiled asset lookup and load','cpu','    MapLoadTrace::Count("vegetation-request",compiled);\n')])
edit('Vegetation/VegetationRuntime.cpp',lambda s:replace(s,'    auto fail=[&]', '    MapLoadTrace::Count("vegetation-load",compiled,0,true);\n    auto fail=[&]'))
scopes('Vegetation/VegetationRenderer.cpp',[
 ('std::shared_ptr<const RenderAsset> Prepare(', 'Vegetation','geometry material preparation','cpu','    MapLoadTrace::Count("vegetation-render-prepare");\n')])
scopes('EterLib/Resource.cpp',[
 ('void CResource::Load()', 'Assets','resource load','cpu','    MapLoadTrace::Count("resource-load-request",GetFileName());\n    MapLoadTrace::Count(me_state==STATE_EMPTY?"resource-miss":"resource-hit",GetFileName());\n')])
edit('EterLib/Resource.cpp',lambda s:replace(s,'\tconst char * c_szFileName = GetFileName();','\tconst char * c_szFileName = GetFileName();\n    MapLoadTrace::Count("resource-load",c_szFileName,0,true);'))
scopes('EterLib/ResourceManager.cpp',[
 ('CResource * CResourceManager::GetResourcePointer(', 'Assets','shared resource lookup')])
scopes('EterGrnLib/Thing.cpp',[
 ('bool CGraphicThing::OnLoad(', 'Assets','model adapters','cpu','    MapLoadTrace::Count("model-adapter",GetFileName());\n')])
for f,name in [('AssetRuntime/GR2/GR2AssetProvider.cpp','GR2'),('AssetRuntime/GlTF/GlTFAssetProvider.cpp','GLB')]:
    scopes(f,[('LoadResult Load(AssetId id,','Assets',name+' parse','cpu',f'    MapLoadTrace::Count("{name.lower()}-parse",id,bytes.size(),true);\n')])
scopes('EterLib/TextureSource.cpp',[
 ('std::shared_ptr<Renderer::TextureResource> DecodeTextureSource(', 'Textures','source decode and copy','cpu','    MapLoadTrace::Count("texture-decode",asset?asset:"",size,true);\n')])
scopes('EterLib/ImageDecoder.cpp',[
 ('bool CImageDecoder::DecodeSTB(', 'Textures','PNG TGA JPG decode')])
scopes('EterLib/TerrainTextureLoader.cpp',[
 ('Renderer::TerrainTexturePtr LoadTerrainTextureMemory(', 'Textures','DDS view mip processing'),
 ('Renderer::TerrainTexturePtr LoadTerrainTextureFile(', 'Textures','terrain texture load','cpu','    MapLoadTrace::Count("terrain-texture-load",filename?filename:"");\n')])
scopes('PackLib/Pack.cpp',[
 ('bool CPack::GetFileWithPool(', 'File access','mapped read decompress decrypt','io+cpu','    MapLoadTrace::Count("pack-read",entry.file_name,entry.compressed_size,true);\n    MapLoadTrace::Count("pack-decoded-bytes",entry.file_name,entry.file_size);\n')])
scopes('PackLib/PackManager.cpp',[
 ('bool CPackManager::GetFileWithPool(', 'File access','file lookup and loose read','io','    MapLoadTrace::Count("file-request",path);\n'),
 ('bool CPackManager::IsExist(', 'File access','existence lookup','io','    MapLoadTrace::Count("exist-request",path);\n')])
edit('PackLib/PackManager.cpp',lambda s:replace(replace(s,'\tstd::ifstream ifs(buf, std::ios::binary);','    MapLoadTrace::Count("loose-open-attempt",buf);\n\tstd::ifstream ifs(buf, std::ios::binary);'),'\t\tif (ifs.read(', '        MapLoadTrace::Count("loose-read",buf,size,true);\n\t\tif (ifs.read('))
scopes('UserInterface/PythonBackground.cpp',[
 ('void CPythonBackground::Initialize()', 'Metadata','background initialize')])
scopes('UserInterface/PythonApplication.cpp',[
 ('void CPythonApplication::RenderGame()', 'First frames','world render','cpu','    MapLoadTrace::WorldRendered();\n')])
# Attribute renderer creation at the actual API call, including cache misses only.
for p in (root/'src/Renderer').glob('Diligent*.cpp'):
    s=p.read_bytes().decode('latin1')
    pattern=r'([\w.>\-]+->(CreateShader|CreateGraphicsPipelineState|CreateBuffer|CreateTexture)\([^;]+?\);)'
    if not re.search(pattern,s):continue
    def render(s):
        def wrap(m):
            method=m[2];phase='Shaders / PSOs' if method in ('CreateShader','CreateGraphicsPipelineState') else 'GPU resources'
            kind='cpu' if method=='CreateShader' else 'gpu-api'
            return '{ MapLoadTrace::Scope p0lCreate("'+phase+'","'+method+'","'+kind+'"); MapLoadTrace::Count("'+method+'","",0,true); '+m[1]+' }'
        return re.sub(pattern,wrap,s)
    edit(str(p.relative_to(root/'src')),render)
edit('Renderer/FirstUseAudit.h',lambda s:replace(replace(s,'    const char* category_;','    MapLoadTrace::Scope p0lScope_;\n    const char* category_;'),'        category_(category),','        p0lScope_("Shaders / PSOs",name,"cpu",enabled), category_(category),'))
edit('Renderer/DiligentD3D11Backend.cpp',lambda s:replace(replace(s,'        m_impl->swapChain->Present(1);','        { MapLoadTrace::Scope p0lPresent("Synchronization","Present vsync","wait"); m_impl->swapChain->Present(1); }\n        MapLoadTrace::Presented();'),'s.context->WaitForIdle();','{ MapLoadTrace::Scope p0lWait("Synchronization","screenshot WaitForIdle","wait"); s.context->WaitForIdle(); }'))
edit('UserInterface/PythonApplicationModule.cpp',lambda s:replace(replace(s,'PyObject* appRenderGame(','''PyObject* appMapLoadTrace(PyObject*, PyObject* args)
{
    const char* command; const char* label="";
    if(!PyArg_ParseTuple(args,"s|s",&command,&label))return nullptr;
    if(std::string_view(command)=="begin")return PyBool_FromLong(MapLoadTrace::Begin(label));
    if(std::string_view(command)=="end")return PyBool_FromLong(MapLoadTrace::End(label));
    if(std::string_view(command)=="active")return PyBool_FromLong(MapLoadTrace::state.active);
    return PyErr_Format(PyExc_ValueError,"unknown trace command");
}

PyObject* appRenderGame('''),'\tstatic PyMethodDef s_methods[] =\n\t{','\tstatic PyMethodDef s_methods[] =\n\t{\n        { "MapLoadTrace", appMapLoadTrace, METH_VARARGS },'))
print('Instrumentation installed')
