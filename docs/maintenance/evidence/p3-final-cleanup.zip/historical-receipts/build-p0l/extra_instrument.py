from pathlib import Path
root=Path(__file__).resolve().parents[1]
exec((root/'build-p0l/instrument.py').read_text().split("scopes('GameLib/MapManager.cpp'")[0])
scopes('PRTerrainLib/TextureSet.cpp', [('bool CTextureSet::Load(', 'Materials','terrain material setup')])
scopes('EterGrnLib/Material.cpp',[
 ('bool CGrannyMaterial::CreateFromAsset(', 'Materials','material creation'),
 ('std::shared_ptr<const Renderer::MaterialRuntimeData> CGrannyMaterial::GetModernMaterial(', 'Materials','modern material lookup')])
scopes('GameLib/MapOutdoorUpdate.cpp',[('bool CMapOutdoor::Update(', 'Residency','visibility sector update')])
edit('UserInterface/PythonApplicationModule.cpp',lambda s:replace(s,'    const char* command; const char* label="";',
 '    static std::vector<std::unique_ptr<MapLoadTrace::Scope>> scopes;\n    const char* command; const char* label="";').replace('    if(std::string_view(command)=="begin")',
 '    if(std::string_view(command)=="push"){scopes.push_back(std::make_unique<MapLoadTrace::Scope>(label,label));Py_RETURN_NONE;}\n    if(std::string_view(command)=="pop"){if(!scopes.empty())scopes.pop_back();Py_RETURN_NONE;}\n    if(std::string_view(command)=="begin")'))
print('Extra boundaries installed')
