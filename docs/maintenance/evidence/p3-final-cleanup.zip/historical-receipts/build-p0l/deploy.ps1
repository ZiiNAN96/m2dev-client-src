$ErrorActionPreference='Stop'
$source=(Get-Location).Path
$original=(Resolve-Path -LiteralPath "$source/../m2dev-client").Path
$evidence=Join-Path $source 'build-p0l/deployment'
if(Test-Path -LiteralPath $evidence){throw 'Fresh deployment receipt required'}
New-Item -ItemType Directory -Path "$evidence/backup" | Out-Null
$built="$source/build-h2x/msvc/bin/Release/Metin2_Release.exe"
$tested="$source/build-p0l/after/Metin2_Release.exe"
$expected=(Get-FileHash -LiteralPath $tested).Hash
if((Get-FileHash -LiteralPath $built).Hash -ne $expected){throw 'Build differs from tested binary'}
$protected=@(Get-ChildItem -LiteralPath "$original/pack","$original/config" -File -Recurse)+@(Get-Item -LiteralPath "$original/Metin2_Debug.exe")
$before=@($protected | ForEach-Object {@{path=$_.FullName;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}})
$before | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$evidence/protected-before.json"
$target="$original/Metin2_Release.exe"
$oldHash=(Get-FileHash -LiteralPath $target).Hash
Copy-Item -LiteralPath $target -Destination "$evidence/backup/Metin2_Release.exe"
if((Get-FileHash -LiteralPath "$evidence/backup/Metin2_Release.exe").Hash -ne $oldHash){throw 'Backup mismatch'}
Copy-Item -LiteralPath $tested -Destination $target -Force
if((Get-FileHash -LiteralPath $target).Hash -ne $expected){throw 'Installed binary mismatch'}
foreach($file in $before){if((Get-FileHash -LiteralPath $file.path).Hash -ne $file.sha256){throw "Protected file changed: $($file.path)"}}
$receipt=@{time=(Get-Date).ToString('o');originalClient=$original;oldSHA256=$oldHash;releaseSHA256=$expected;backup="$evidence/backup/Metin2_Release.exe";protectedFiles=$before.Count;protectedUnchanged=$true;nativeEvidence="$source/build-p0l/after/fast-gate.json";networkLogin='NOT RUN';restartRequired=$true}
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$evidence/receipt.json"
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$original/docs/p0l-map-loading-deployment.json"
$receipt | ConvertTo-Json -Depth 4
