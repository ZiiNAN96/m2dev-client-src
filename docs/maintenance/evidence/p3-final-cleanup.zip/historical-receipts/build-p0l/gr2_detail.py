from pathlib import Path
root=Path(__file__).resolve().parents[1]
exec((root/'build-p0l/instrument.py').read_text().split("scopes('GameLib/MapManager.cpp'")[0])
scopes('AssetRuntime/GR2/GR2File.cpp',[
 ('Header Inspect(', 'Assets','GR2 header checksum'),
 ('File::File(', 'Assets','GR2 relocations')])
scopes('AssetRuntime/GR2/GR2Compression.cpp',[
 ('std::vector<std::byte> Decompress(', 'Assets','GR2 section decompression')])
scopes('AssetRuntime/GR2/GR2ModelReader.cpp',[
 ('Contents Read(', 'Assets','GR2 object graph'),
 ('SkeletonAsset ReadSkeleton(', 'Actors','GR2 skeleton')])
scopes('AssetRuntime/GR2/GR2AnimationReader.cpp',[
 ('AnimationData ReadAnimation(', 'Actors','GR2 animation curves')])
scopes('AssetRuntime/GR2/GR2MeshReader.cpp',[
 ('MeshData ReadMesh(', 'Assets','GR2 mesh')])
edit('AssetRuntime/GR2/GR2AssetProvider.cpp',lambda s:replace(s,'            GR2::File file(bytes); containerAudit.Stop();',
 '            MapLoadTrace::Scope containerTrace("Assets","GR2 container");\n            GR2::File file(bytes); containerTrace.Stop(); containerAudit.Stop();'))
# Missing broad phase labels, without changing renderer behavior.
scopes('GameLib/MapOutdoorWater.cpp', [('void CMapOutdoor::LoadWaterTexture()', 'Water','water texture setup')])
scopes('Renderer/DiligentAtmosphere.cpp', [('void DiligentAtmosphere::Prepare(', 'Sky atmosphere HDR','atmosphere preparation')])
print('GR2 detail installed')
