@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l\vs-compare.log
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /O2 /EHsc /I src build-p0l\decoder_compare.cpp /Fe:build-p0l\decoder_compare.exe /Fo:build-p0l\decoder_compare.obj > build-p0l\decoder-compare-build.log 2>&1
if errorlevel 1 exit /b 1
build-p0l\decoder_compare.exe build-p0l\decoder-files.txt > build-p0l\decoder-compare.txt
exit /b %errorlevel%
