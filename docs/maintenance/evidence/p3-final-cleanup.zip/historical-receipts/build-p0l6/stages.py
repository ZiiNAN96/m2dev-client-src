import json
from pathlib import Path
for name in ('l6-before','l6-after'):
    print(name)
    for x in json.loads(Path('build-p0l/'+name+'/gr2-pipeline.json').read_text()):
        if x['label']!='client-setup':
            b=x['breakdown']
            print(x['label'], {k: b.get(k) for k in ('GR2 animation curves','GR2 animation preparation','GR2 decoder loop')})
