@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l6\parity-vs.log
powershell -NoProfile -ExecutionPolicy Bypass -File tests\Loading\run_gr2_decoder_parity.ps1 -CorpusList build-p0l6/decoder-files.txt -OutputDirectory build-p0l6/decoder-parity -Baseline 73dc92e > build-p0l6\decoder-parity.log 2>&1
exit /b %errorlevel%
