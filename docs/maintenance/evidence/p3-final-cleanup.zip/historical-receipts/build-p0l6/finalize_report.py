from pathlib import Path
p=Path('docs/performance/p0l6-parallel-gr2.md')
s=p.read_text(encoding='utf-8')
replacements={
'2156.785':'2219.191','104.305':'41.900','4.613':'1.853','1757.584':'1814.050','107.962':'51.496','5.787':'2.760','1100.332':'1139.957','48.326':'8.700','4.207':'0.757','394.148':'404.897','-1.455':'-12.204','-0.371':'-3.108','1850.923':'1910.918','14.623':'-45.373','0.784':'-2.432','1149.591':'1188.474','-0.933':'-39.816','-0.081':'-3.466','1812.500':'1843.750','-31.250':'-62.500','-1.754':'-3.509','164.406':'163.743','51.377':'52.041','23.810':'24.117','0.993':'10.500','60.174':'50.667','98.376':'82.834','287.637':'271.245','99.278':'115.669','25.659':'29.895','123.186':'113.239','98.881':'108.828','44.528':'49.007','59.195':'54.134','34.670':'39.730','36.936':'42.327','70.706':'64.882','164.291':'161.954','2.324':'2.496','2.746':'2.552','226.730':'202.670','82.567':'79.414','125.000':'140.625','328.125':'140.625','14.5 % / 17.2 %':'15.6 % / 16.0 %','1.77 / 3.97':'2.17 / 1.77','0.003 ms':'9.405 ms','30.288 ms':'39.088 ms','1051.152':'1088.925','**46008**':'**26700**','**5/5 PASS**':'**6/6 PASS**','GR2Preparation, GR2Safety':'GR2Preparation, GR2Independence, GR2Safety','09BA4D5B9A510B6BCACA226A00462E3B65CF1D3C8A1822B5B6D0E4BCD261D1B0':'EAC38F283DA10A5567032DB7BB72AD41A800500DDF3C40E70FBA77AAE04B3A9C','`build-p0l/l6-after`':'`build-p0l/l6-after-final`','|Preparation)$':'|Preparation|Independence)$',
'Je ein neuer Prozess, identische Originalpacks':'Ausgewertet wird ein finales Vorher-/Nachher-Paar mit je einem neuen Prozess, identischen Originalpacks',
'Dekompressionsarbeit in kumulierter Dauer bleibt praktisch gleich.':'die kumulierte Dekompressionsdauer liegt gleichzeitig 39.816 ms / 3.466 % höher als in der Baseline. Diese Schwankung reduziert den verbleibenden Gesamtgewinn.',
'können bei vielen kurzen Jobs über- oder unterschätzen.':'können bei vielen kurzen Jobs über- oder unterschätzen. Die Windows-Zeitabfrage wird als Callback vom Consumer übergeben; der GR2-Core bleibt ohne Plattform-Includes.',
'Keine separate interaktive OS-Reaktionszeitmessung behauptet.':'Keine separate interaktive OS-Reaktionszeitmessung behauptet.',
}
for a,b in replacements.items():
    if a not in s: print('not found:',a)
    s=s.replace(a,b)
s=s.replace('Das akzeptierte einzelne Messpaar zeigt den Gewinn; keine statistische Benchmarkbehauptung.', 'Das akzeptierte finale Messpaar zeigt einen moderaten Gewinn; keine statistische Benchmarkbehauptung. Ein früherer Zwischenbuild ergab 104.305 ms / 4.613 %, wird aber nicht als finales Resultat gewählt: Nach Abschlussreview wurden Diagnose-Allokationen hinter alle Joins verlegt, die CPU-Zeitabfrage aus dem GR2-Core in den Windows-Consumer verschoben und die Bibliotheksabhängigkeit explizit gemacht. Danach erneuter Release-Build und genau ein finaler Nachher-Lauf: maßgeblich sind die kleineren 41.900 ms / 1.853 %.')
s=s.replace('GR2Golden.animation. Corpus-', 'GR2Golden.animation. Corpus-')
p.write_text(s,encoding='utf-8')
