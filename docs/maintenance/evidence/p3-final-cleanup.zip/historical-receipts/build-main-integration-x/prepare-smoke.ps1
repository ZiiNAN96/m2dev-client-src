$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$previous=Join-Path $source 'build-p0l-final-production'
$audit=Join-Path $source 'build-h2x/msvc/tests/AssetRuntime/Release/PackContentAudit.exe'
if(@(Get-Process -Name '*Metin2*' -ErrorAction SilentlyContinue).Count){throw 'Client already running; do not touch installed pack'}
if(Test-Path -LiteralPath "$PSScriptRoot/backup"){throw 'Fresh backup required'}
$expectedExe='7D4582444DC7DF7D18099D62E2DF0222DA1642D00423A322A3C10BAA24EB8F19'
$expectedRoot='6A6D2017373876FBEBF4774A90AFB1712C0FD78D33A0B83C083CA875185B4CF3'
if((Get-FileHash "$runtime/Metin2_Release.exe").Hash -ne $expectedExe){throw 'Unexpected installed EXE'}
if((Get-FileHash "$runtime/pack/root.pck").Hash -ne $expectedRoot){throw 'Unexpected installed pack'}
New-Item -ItemType Directory -Path "$PSScriptRoot/backup","$PSScriptRoot/production-pack","$PSScriptRoot/smoke-pack","$PSScriptRoot/shader-cache" | Out-Null
$mutable=@(Get-ChildItem -LiteralPath $runtime -File)+@(Get-ChildItem -LiteralPath "$runtime/config","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)
$mutable+=Get-Item -LiteralPath "$runtime/pack/root.pck"
$manifest=@()
foreach($file in $mutable){
 $relative=[IO.Path]::GetRelativePath($runtime,$file.FullName)
 $dest=Join-Path "$PSScriptRoot/backup" $relative
 New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null
 Copy-Item -LiteralPath $file.FullName -Destination $dest
 $hash=(Get-FileHash -LiteralPath $file.FullName).Hash
 if((Get-FileHash -LiteralPath $dest).Hash -ne $hash){throw "Backup mismatch: $relative"}
 $manifest+=@{path=$relative;sha256=$hash;bytes=$file.Length}
}
$manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/backup-manifest.json"
$protected=@(Get-ChildItem -LiteralPath "$runtime/pack","$runtime/config","$runtime/assets/root","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)+@(Get-ChildItem -LiteralPath $runtime -File)
$protected | ForEach-Object {@{path=[IO.Path]::GetRelativePath($runtime,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/protected-before.json"
Copy-Item -LiteralPath "$runtime/pack/root.pck" -Destination "$PSScriptRoot/production-pack/root.pck"
Copy-Item -LiteralPath "$previous/smoke-pack/root.pck" -Destination "$PSScriptRoot/smoke-pack/root.pck"
& $audit compare "$PSScriptRoot/production-pack/root.pck" "$PSScriptRoot/smoke-pack/root.pck" "$PSScriptRoot/smoke-pack-diff.tsv" 'prototype.py' > "$PSScriptRoot/smoke-pack-diff.log"
if($LASTEXITCODE -ne 0){throw 'Unexpected temporary smoke pack delta'}
Copy-Item -Path "$previous/shader-cache/*" -Destination "$PSScriptRoot/shader-cache"
Copy-Item -LiteralPath "$previous/run-original-smoke.ps1" -Destination "$PSScriptRoot/run-original-smoke.ps1"
@{newExeSHA256=$expectedExe;newRootSHA256=$expectedRoot;runtime=$runtime;sourceMain='ed3e744daef68937f5bcb3246bee0c6165dea9eb';runtimeMain='d54637a4b323b9d40f0e200951c40d4d226a2cfc';scope='Installed original-client offline production-path smoke; existing accepted entry with full prewarm and 36 motion windows reused unchanged. No executable deployment.'} | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/deployment.json"
Write-Output "Protected files: $($protected.Count); isolated existing cache entries: $(@(Get-ChildItem -LiteralPath "$PSScriptRoot/shader-cache" -File).Count)."
Get-Content -LiteralPath "$PSScriptRoot/smoke-pack-diff.log"
