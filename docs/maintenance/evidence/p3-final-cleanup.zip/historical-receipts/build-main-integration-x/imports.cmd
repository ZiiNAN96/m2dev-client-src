@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-main-integration-x\imports-vs.log
if errorlevel 1 exit /b 1
dumpbin /dependents ..\m2dev-client\Metin2_Release.exe > build-main-integration-x\installed-imports.txt
if errorlevel 1 exit /b 1
dumpbin /dependents build-h2x\msvc\bin\Release\Metin2_Release.exe > build-main-integration-x\main-release-imports.txt
exit /b %errorlevel%
