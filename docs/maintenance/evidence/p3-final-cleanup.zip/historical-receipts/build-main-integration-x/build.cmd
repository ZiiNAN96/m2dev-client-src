@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-main-integration-x\vs.log
if errorlevel 1 exit /b 1
"C:\Program Files\CMake\bin\cmake.exe" --build build-h2x/msvc --config Release --target UserInterface RendererStartupOptionsTest ShaderBytecodeCacheTest GR2SafetyTest GR2CompatibilityTest GR2GoldenTest GR2PreparationTest GR2WarmupTest GlTFCharacterTest GraphicsSettingsTest MaterialMappingTest AtmosphereConfigTest WaterConfigTest DiligentFXMaterialTest DiligentFXModernTest VegetationModernTest --parallel 6 > build-main-integration-x\build-release.log 2>&1
exit /b %errorlevel%
