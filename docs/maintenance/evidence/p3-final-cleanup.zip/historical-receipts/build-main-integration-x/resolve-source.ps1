$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
$production='6f140539f3996f8ccd390fd358a5f4d01813dc30'
function GitChecked([string[]]$arguments) {
    $output=& git -C $repo @arguments
    if($LASTEXITCODE -ne 0){throw "Git failed: $arguments"}
    return $output
}
$reasons=@{
 'CMakeLists.txt'='Keep the current test registration; old Materials/Lighting/Shadows suites compile the superseded custom stack.'
 'src/AssetRuntime/AssetRuntime.h'='Keep current native material fields and vertex extras; old MaterialData model/materialVertices would create a parallel contract.'
 'src/AssetRuntime/CMakeLists.txt'='Do not compile superseded MaterialData.cpp; retain current GR2 preparation target.'
 'src/AssetRuntime/GlTF/GlTFAssetProvider.cpp'='Keep current GLB material import, UV validation and vertex extras consumed by DiligentModernRenderer.'
 'src/EterGrnLib/Material.cpp'='Keep current MaterialRuntimeData cache and authored classic diffuse/sphere semantics; reject incompatible old GetRenderMaterial implementation.'
 'src/EterGrnLib/Material.h'='Keep current runtime material type and cache layout; old MaterialRuntimePtr is incompatible with current bridge.'
 'src/EterGrnLib/Model.cpp'='Keep current captured material/vertex extras; old MaterialVertex parallel streams belong to superseded shader inputs.'
 'src/EterGrnLib/Thing.cpp'='Keep current versioned MaterialOverrides path; do not add old AssetDocument::ApplyMaterialOverrides API.'
 'src/EterLib/GrpObjectInstance.cpp'='Keep current modern-frame caster visibility and closure fixes; old global shadowPassIndex belongs to removed custom cascades.'
 'src/EterLib/SourceResourceAudit.h'='Keep current resource diagnostics; old MaterialRuntime/SceneLightingRuntime/ShadowAmbientRuntime counters require removed owners.'
 'src/GameLib/ActorRenderBridge.cpp'='Keep current cached material submissions, attachments and prewarm path; old material pointer type is incompatible.'
 'src/GameLib/CMakeLists.txt'='Do not reinstate diagnostic macro used solely to include old LightingProofState into WorldTree.'
 'src/GameLib/MapManager.cpp'='Keep current modern-frame reset and environment-to-SceneLighting conversion instead of old global SceneLightingState.'
 'src/GameLib/MapOutdoorRender.cpp'='Keep current modern-frame terrain/caster submission and production residency behavior; reject old global custom shadow-pass branch.'
 'src/GameLib/StaticObjectBridge.cpp'='Keep current MaterialRuntimeData/modern submissions and texture ownership; old material pointer contract is superseded.'
 'src/GameLib/WorldTree.cpp'='Keep H2 vegetation and stable production detail policy; do not inject old lighting fixture state into runtime.'
 'src/Graphics/CMakeLists.txt'='Current SceneLighting is header-only and cascades/AO use DiligentFX; old SceneLighting.cpp/ShadowAmbient.cpp must not be compiled.'
 'src/Graphics/GraphicsSettings.cpp'='Keep current supported PBR/HDR/sky/water/shadow/AO resolution; old config explicitly leaves later capabilities unavailable.'
 'src/Graphics/GraphicsSettings.h'='Keep stable current graphics contract and DiligentFX config; old custom ShadowQualityConfig/AmbientDepthConfig are incompatible.'
 'src/Graphics/SceneLighting.h'='Retain current shared SceneLighting and ResolveLegacyEnvironmentLight used by Modern/HDR/atmosphere/water; old stateful lighting contract is superseded.'
 'src/Renderer/ActorRenderData.h'='Keep current actor vertex extras and runtime material contract; old MaterialVertex stream is incompatible.'
 'src/Renderer/CMakeLists.txt'='Keep DiligentFX subset, modern renderer and persistent shader-cache integration; do not compile DiligentShadowAmbient.'
 'src/Renderer/DiligentActorRenderer.cpp'='Keep current actor geometry and submission path with existing attachment ownership; reject old stream layout.'
 'src/Renderer/DiligentD3D11Backend.cpp'='Keep current modern renderer lifecycle and shader cache; do not add old depthEffects owner or custom BeginSunCascade API.'
 'src/Renderer/DiligentD3D11Backend.h'='Keep current backend API; old modern-scene/custom cascade entrypoints require superseded depthEffects.'
 'src/Renderer/DiligentD3D11BackendInternal.h'='Keep current ModernRenderer/FX ownership and cache; old global lightBuffer/depthEffects would introduce competing scene state.'
 'src/Renderer/DiligentEffectRenderer.cpp'='Keep authored effects, HDR binding and current modern-frame state; reject old shadowPassIndex/depthEffects target binding.'
 'src/Renderer/DiligentStaticObjectRenderer.cpp'='Keep current shared DiligentModernRenderer, H2 instancing and loading optimizations; old custom PBR/shadow shader owners are superseded.'
 'src/Renderer/DiligentTerrainRenderer.cpp'='Keep current DiligentFX terrain adapter and cache; old embedded MODERN_TERRAIN/light/shadow shader pipeline is superseded.'
 'src/Renderer/SkinningBenchmark.h'='Keep current diagnostic schema; old ambientBenchmarkGpuTimes and custom cascade counters have no current owner.'
 'src/Renderer/StaticObjectRenderData.h'='Keep MaterialRuntimeData, current vertex extras and H2 instance contract; reject old MaterialRuntimePtr/MaterialVertex layout.'
 'src/Renderer/TerrainPresentation.cpp'='Keep current modern-frame lifecycle and resource shutdown; old BeginModernScene/custom cascade replay is superseded.'
 'src/Renderer/TerrainPresentation.h'='Keep current presentation contract; do not re-add old ShadowAmbient-dependent virtual methods.'
 'src/UserInterface/InstanceBase.cpp'='Keep current caster/actor logic; old global shadowPassIndex guards would suppress work on the wrong architecture.'
 'src/UserInterface/PythonApplication.cpp'='Keep current G8/H2/P0 production frame and prewarm path; old custom cascade loop would reintroduce duplicate rendering.'
 'src/UserInterface/PythonSystemModule.cpp'='Keep current diagnostics/settings bindings; do not export obsolete LightingProof/DepthProof test APIs.'
 'tests/AssetRuntime/CMakeLists.txt'='Keep current native GR2/GLB and preparation tests; old conditional custom material test integration is incompatible.'
 'tests/AssetRuntime/GR2RenderTest.cpp'='Keep current real-asset fixture; old custom lighting-proof setup references removed scene globals.'
 'tests/AssetRuntime/GlTFCharacterRenderTest.cpp'='Keep current GLB character modern-frame GPU test; old PBR/light/cascade APIs are superseded.'
 'tests/AssetRuntime/GlTFRenderTest.cpp'='Keep current shared modern GLB test instead of old custom material test path.'
 'tests/Graphics/GraphicsSettingsTest.cpp'='Keep current supported capability expectations including HDR/sky/water and DiligentFX AO; old custom configuration expectations are obsolete.'
}
$legacyNew=@{
 'src/AssetRuntime/MaterialData.cpp'='Old custom PBR material parsing/runtime contract replaced by current AssetRuntime material fields and MaterialOverrides.h.'
 'src/AssetRuntime/MaterialData.h'='Old MaterialModel/PBRMaterialData/MaterialVertex types conflict with current material/vertex contracts.'
 'src/Graphics/SceneLighting.cpp'='Old stateful SceneLightingState implementation replaced by current shared header-only SceneLighting.'
 'src/Graphics/ShadowAmbient.cpp'='Custom cascade math and AO quality implementation replaced by DiligentFX ShadowMapManager/SSAO.'
 'src/Graphics/ShadowAmbient.h'='Old custom cascade/AO contract replaced by current DiligentFX configuration.'
 'src/Renderer/DiligentPBRMaterial.inl'='Custom PBR pipeline/shaders replaced by DiligentModernRenderer and pinned FX PBR helpers.'
 'src/Renderer/DiligentShadowAmbient.cpp'='Custom shadow/AO renderer replaced by pinned DiligentFX shadow/AO passes.'
 'src/Renderer/DiligentShadowAmbient.h'='Old custom shadow/AO owner is absent from the current backend.'
 'src/Renderer/DiligentShadowCaster.inl'='Old custom caster pipeline replaced by the current shared modern mesh pass.'
 'src/Renderer/MaterialRuntime.h'='Old material owner replaced by MaterialRuntimeData.h.'
 'src/Renderer/PBRShader.h'='Custom BRDF replaced by ModernMeshShader.h and pinned DiligentFX PBR functions.'
 'src/Renderer/SceneLightingRuntime.h'='Old global lighting state replaced by current SceneLighting passed through ModernFrame.'
 'src/Renderer/SceneLightingShader.h'='Old custom light shader replaced by current shared DiligentFX material/lighting path.'
 'src/Renderer/ShadowAmbientRuntime.h'='Old global cascade/pass state replaced by current ModernFrame and DiligentFX owners.'
 'src/Renderer/ShadowAmbientShader.h'='Old custom PCF/AO shader replaced by pinned DiligentFX implementations.'
}
$preview=Get-Content -LiteralPath "$PSScriptRoot/source-merge-preview.txt"
$conflicts=@($preview | Where-Object {$_ -match '^CONFLICT'} | ForEach-Object {($_ -split 'Merge conflict in ',2)[1]})
$delta=@(GitChecked @('diff','--name-status',$production,$preview[0]))
$ledger=@()
foreach($line in $delta){
 $status,$path=$line -split "`t",2
 if($path.StartsWith('docs/graphics/')){
  $decision='keep historical report with archive notice'
  $reason='Main-only G1/G2/G3/4 historical evidence remains available; not a current production implementation or fresh validation claim.'
 } elseif($reasons.ContainsKey($path)){
  $decision='retain reviewed production file';$reason=$reasons[$path]
 } elseif($legacyNew.ContainsKey($path)){
  if($status -ne 'A'){throw "Expected main-only addition: $path"}
  $decision='exclude superseded implementation';$reason=$legacyNew[$path]
 } elseif($path -match '^tests/(Materials|Lighting|Shadows)/'){
  if($status -ne 'A'){throw "Expected old test addition: $path"}
  $decision='exclude superseded test fixture';$reason='This historical suite targets old MaterialData/SceneLightingState/ShadowAmbient APIs. Current tests/Graphics, AssetRuntime and Renderer cover the DiligentFX production contracts. Original suite remains in the retained main parent history.'
 } else {throw "Unreviewed merge path: $path"}
 $ledger+=@{path=$path;status=$status;conflict=$conflicts.Contains($path);decision=$decision;reason=$reason}
}
$ledger | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/source-resolution-ledger.json"
if((GitChecked @('branch','--show-current')) -ne 'main'){throw 'Expected checked-out main'}
if((GitChecked @('rev-parse','MERGE_HEAD')) -ne $production){throw 'Unexpected merge target'}
foreach($item in $ledger){
 if($item.decision -eq 'keep historical report with archive notice'){
  $file=Join-Path $repo $item.path
  $content=[IO.File]::ReadAllText($file)
  $notice="> Historischer G1/G2/G3/4-Bericht vom frueheren main. Die damalige eigene Renderer-Implementierung wurde durch den [DiligentFX-Neuaufbau](phase-gdx-diligentfx-rebuild.md) und G8/H2/P0 ersetzt. Dieser Bericht beschreibt keine aktuelle Implementierung oder erneute Abnahme. Bei MAIN-INTEGRATION-X als Historie erhalten.`n`n"
  [IO.File]::WriteAllText($file,$notice+$content,[Text.UTF8Encoding]::new($false))
  GitChecked @('add','--',$item.path) | Out-Null
 } elseif($item.decision -eq 'retain reviewed production file'){
  GitChecked @('restore',"--source=$production",'--staged','--worktree','--',$item.path) | Out-Null
 } else {
  GitChecked @('rm','--',$item.path) | Out-Null
 }
}
$unmerged=@(GitChecked @('ls-files','--unmerged'))
if($unmerged.Count){throw 'Unresolved merge entries remain'}
$remaining=@(GitChecked @('diff','--cached','--name-only',$production))
if($remaining.Count -ne 3 -or @($remaining | Where-Object {$_ -notmatch '^docs/graphics/phase-g(1x-material-system-pbr|2x-modern-lighting|34x-shadows-ambient-depth)\.md$'}).Count){throw 'Unexpected merged-tree change from production'}
GitChecked @('diff','--cached','--check',$production) | Out-Null
Write-Output "Reviewed paths: $($ledger.Count); conflicts: $($conflicts.Count); production code/build/test tree unchanged; retained historical reports: $($remaining.Count)."
