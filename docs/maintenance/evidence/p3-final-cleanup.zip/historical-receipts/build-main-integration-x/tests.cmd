@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-main-integration-x\tests-vs.log
if errorlevel 1 exit /b 1
"C:\Program Files\CMake\bin\ctest.exe" --test-dir build-h2x/msvc -C Release -R "^(Renderer\.(StartupOptions|ShaderBytecodeCache|NoLegacyArchitecture)|AssetRuntime\.(NoGrannyDependency|GR2Safety|GR2Compatibility|GR2Golden\.(static|animation)|GR2Preparation|GR2Warmup|GR2Independence|GlTFCharacter)|Graphics\.(Presets|Invalid|LiveApply|MaterialMapping|HDRAtmosphereConfig|WaterConfig|DiligentFXMaterials|DiligentFXModern)|Vegetation\.(ModernContracts|NoLegacyDependency))$" --output-on-failure --output-junit C:/Users/ZiiNAN/Documents/GitHub/m2dev-client-src/build-main-integration-x/fast-tests.xml > build-main-integration-x\fast-tests.log 2>&1
exit /b %errorlevel%
