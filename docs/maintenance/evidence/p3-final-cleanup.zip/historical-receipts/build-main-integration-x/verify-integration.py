import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

out = Path(__file__).resolve().parent
src = out.parent
runtime = src.parent / 'm2dev-client'
sys.path.insert(0, str(src / 'tests/Loading'))
from summarize_trace import read
from verify_shader_cache import process

def data(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest().upper()

def git(repo, *args):
    return subprocess.check_output(['git', '-c', f'safe.directory={repo.as_posix()}', '-C', str(repo), *args], text=True, encoding='utf-8').strip()

assert data(out/'build-exit.json')['ExitCode'] == 0
assert data(out/'tests-exit.json')['ExitCode'] == 0
tests = ET.parse(out/'fast-tests.xml').getroot()
cases = tests.findall('.//testcase')
assert len(cases) == 22 and not tests.findall('.//failure') and not tests.findall('.//skipped')
run = out/'warm'
assert data(run/'fast-gate.json')['status'] == 'PASS'
assert data(run/'exit.json')['ExitCode'] == 0
assert 'phase=ShutdownClean' in (run/'gdxc-lifecycle.log').read_text()
audit = (run/'source-resource-audit.log').read_text()
for key in ('NativePrewarmFailures', 'NativePrewarmLimited', 'GrannyFileReads'):
    assert re.search(r'\b'+key+r'=0\b', audit), key
startup = (run/'renderer-startup.log').read_text()
for expected in ('Vegetation=ziinan', 'GR2Reader=ziinan', 'AnimationRuntime=ziinan', 'Skinning=gpu', 'GR2Prewarm=1', 'Selection=default API=d3d11', 'ExitCode=0'):
    assert expected in startup, expected
rows = data(run/'first-use-analysis.json')['rows']
assert len(rows) == 36
assert all(r['runtime_keys'] == r['clip_misses'] == r['allocation_requests'] == r['late_gr2_parses'] == 0 for r in rows)
loads = read(run/'map-load-trace.tsv')
maps = [l for l in loads if not l['label'].startswith('first-use-')]
assert [l['label'] for l in maps] == ['client-setup', 'A1-cold', 'B1-first-in-session', 'A1-warm']
for load in maps[1:]:
    assert any(c['name'] == 'Production animation prewarm' and c['calls'] >= 1 for c in load['costs'])
assert loads[2]['label'] == 'first-use-player-Idle-1'
assert loads[-3]['label'] == 'first-use-mob-Death-3'
cache = process(run)
assert all(l['misses'] == l['compiles'] == 0 for l in cache['loads'])
assert sum(l['requests'] for l in cache['loads']) == sum(l['hits'] for l in cache['loads']) == 125
before = data(run/'cache-before.json')
after = data(run/'cache-after.json')
assert len(before) == len(after) == 73
assert {x['path']: x['sha256'] for x in before} == {x['path']: x['sha256'] for x in after}
(out/'shader-cache-check.json').write_text(json.dumps(cache, indent=2), encoding='utf-8')

protected = data(out/'protected-before.json')
for item in protected:
    assert sha(runtime/item['path']) == item['sha256'], item['path']
assert len(protected) == 549
receipt = data(out/'deployment.json')
assert sha(runtime/'Metin2_Release.exe') == receipt['newExeSHA256']
assert sha(runtime/'pack/root.pck') == receipt['newRootSHA256']
imports = {}
markers = (b'GrannyReadEntireFile', b'GrannyPlayControlledAnimation', b'GrannyGetVersion', b'CSpeedTreeRT', b'SpeedTreeRT.dll', b'granny2.dll')
for name, binary, report in (
    ('installed', runtime/'Metin2_Release.exe', out/'installed-imports.txt'),
    ('mainRelease', src/'build-h2x/msvc/bin/Release/Metin2_Release.exe', out/'main-release-imports.txt')):
    text = report.read_text(errors='replace')
    dlls = re.findall(r'^\s+(\S+\.dll)\s*$', text, re.MULTILINE|re.IGNORECASE)
    assert dlls and 'd3d11.dll' in [d.lower() for d in dlls]
    forbidden = [d for d in dlls if re.search(r'd3d9|d3dx9|granny|speedtree', d, re.I)]
    payload = binary.read_bytes()
    found = [m.decode() for m in markers if m.lower() in payload.lower()]
    assert not forbidden and not found, (name, forbidden, found)
    imports[name] = dict(sha256=sha(binary), dependencies=dlls, forbiddenImports=forbidden, sdkMarkers=found)
(out/'zero-legacy.json').write_text(json.dumps(imports, indent=2), encoding='utf-8')

initial = data(out/'initial-git.json')
repositories = {}
for name, repo, feature, mode in (
    ('source', src, 'codex/g56-hdr-atmosphere', 'normal merge'),
    ('runtime', runtime, 'codex/g56-hdr-colors', 'fast-forward')):
    assert git(repo, 'branch', '--show-current') == 'main'
    assert git(repo, 'status', '--porcelain=v1') == ''
    main = git(repo, 'rev-parse', 'main')
    branch = git(repo, 'rev-parse', feature)
    subprocess.run(['git', '-c', f'safe.directory={repo.as_posix()}', '-C', str(repo), 'merge-base', '--is-ancestor', branch, main], check=True)
    assert git(repo, 'rev-parse', 'origin/main') == initial[name]['originMain']
    changes = git(repo, 'diff', '--name-only', feature, 'main').splitlines()
    if name == 'source':
        assert sorted(changes) == sorted(['docs/graphics/phase-g1x-material-system-pbr.md', 'docs/graphics/phase-g2x-modern-lighting.md', 'docs/graphics/phase-g34x-shadows-ambient-depth.md'])
        parents = git(repo, 'show', '-s', '--format=%P', main).split()
        assert parents == [initial[name]['main'], branch]
    else:
        assert main == branch and changes == []
    repositories[name] = dict(path=str(repo), main=main, originalFeatureHead=initial[name]['head'], feature=feature, featureHeadBeforeMerge=branch, integration=mode, workingTree='clean', previousMain=initial[name]['main'], originMain=initial[name]['originMain'], log=git(repo, 'log', '--oneline', '--decorate', '-10').splitlines())

ledger = data(out/'source-resolution-ledger.json')
result = dict(status='PASS', repositories=repositories, reviewedMergePaths=len(ledger), conflicts=sum(bool(x['conflict']) for x in ledger), releaseBuild='PASS', tests=dict(passed=len(cases), total=len(cases), names=[x.attrib['name'] for x in cases]), runtime=dict(executable=str(runtime/'Metin2_Release.exe'), sha256=receipt['newExeSHA256'], exit=data(run/'exit.json'), maps=[dict(label=l['label'], milliseconds=l['total_ms']) for l in maps[1:]], motionWindows=len(rows), maxRuntimeMotionMs=max(r['runtime_motion_max_ms'] for r in rows), prewarmMs=next(c['inclusive_ms'] for c in maps[1]['costs'] if c['name']=='Production animation prewarm'), shaderRequests=125, shaderHits=125, shaderCompiles=0, persistentEntries=73, protectedFilesUnchanged=len(protected), zeroCounters=data(run/'fast-gate.json')['zero_keys'], zeroLegacy='PASS', scope='Original installed client; short automated offline world/actor smoke; no network login or manual visual acceptance'), oldBranches='retained', push=False)
(out/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')

lines=['# MAIN-INTEGRATION-X — Abschluss', '', '**Fast Gate: PASS. Kein Push. Alte Branches erhalten.**', '', '| Repository | main HEAD | Feature-HEAD vor Integration | Integration | Working tree |', '|---|---|---|---|---|']
for name, repo in repositories.items():
    lines.append(f"| {name.upper()} | `{repo['main']}` | `{repo['featureHeadBeforeMerge']}` | {repo['integration']} | clean |")
lines += ['', '## Ausgangslage und Dokumentationscommits', '', f"Source vor Aufräumen: `{repositories['source']['originalFeatureHead']}`. Zwei Dateien Kategorie C; Commit `6f14053` sichert die P0-L3-Analyse und vorhandene P1-Baseline. Keine neue P1-Arbeit.", '', f"Runtime vor Aufräumen: `{repositories['runtime']['originalFeatureHead']}`. Drei Dateien Kategorie C; Commit `d54637a4` sichert den Production-Bericht und zwei kleine historische Deployment-Receipts. Keine EXEs, Caches, Logs, Backups oder Buildoutputs hinzugefügt.", '', 'Vor beiden Integrationsschritten waren beide Arbeitsverzeichnisse sauber. Fetch von origin in beiden Repositories erfolgreich; lokale main und origin/main waren jeweils identisch. Source-Divergenz: 3 Commits nur auf main, 16 nur auf dem Production-Branch. Runtime: 0 nur auf main, 8 nur auf dem Production-Branch.', '', '## Source-Merge', '', 'Die drei früheren main-Commits (`1835e66`, `fdcffdd`, `ea1142c`) implementierten den alten eigenen G1/G2/G3/4-Material-, Licht- und Schattenstack. Der dokumentierte G-DX-Neuaufbau ab G0 ersetzt diesen durch DiligentFX. Alle 95 Merge-Abweichungen wurden klassifiziert, einschließlich 25 Textkonflikten und automatisch zusammengeführter Altpfade. Keine unabhängigen Änderungen außerhalb dieses ersetzten Stacks gefunden.', '', '41 aktuelle Dateien beibehalten; 15 obsolete Implementierungsdateien und 36 daran gebundene Test-/Fixture-Dateien nicht reaktiviert; drei historische Berichte mit Archivhinweis erhalten. Einzelbegründungen stehen in `source-resolution-ledger.json`. Beide Eltern sind im normalen Merge erhalten; kein Rebase, Squash oder History-Rewrite. Gesamter Tree gegenüber dem Production-Branch: ausschließlich diese drei historischen Berichte zusätzlich. Source, Tests, Buildkonfiguration und alle Milestone-/Performance-Funktionen unverändert.', '', 'Whitespace: neuer Dokumentationsanteil und finaler Working tree bestehen die Prüfung. Gegen den früheren main meldet Git zwei bereits im Production-Branch enthaltene leere Schlusszeilen (`docs/performance/p0l2-runtime-shaders.md`, `src/EterGrnLib/Material.cpp`); diese wurden nicht als neuer Codeeingriff verändert.', '', '## Frischer Fast Gate', '', '- Release-Build auf Source-main: PASS (Exit 0); 16 gezielte Buildtargets einschließlich UserInterface und ausgewählter Tests.', '- Ausgewählte schnelle Release-Tests: **22/22 PASS**. Grafiksettings, Materialmapping, DiligentFX-Material/Modern-GPU, HDR-/Wasserkonfiguration, Shadercache, GR2-Safety/Compatibility/Goldens/Preparation/Warmup/Independence, GLB-Character, Vegetation und Zero-Legacy. Keine vollständige historische Testsuite.', f"- Normaler installierter Client gestartet: `{runtime/'Metin2_Release.exe'}`. Frischer Prozess PID {result['runtime']['exit']['PID']}, Exit 0 und ShutdownClean. A1 vollständig geladen; Player/Mob Idle, Walk, Run, Attack, Damage, Death jeweils dreimal; B1 und Rückkehr A1.", '- Diligent ERROR/FATAL = 0; GPU fallback = 0; CPU deformation calls/vertices = 0; alle vom vorhandenen Fast-Gate geprüften Shutdown-Ressourcen = 0.', f"- Production-Animation-Prewarm aktiv: {result['runtime']['prewarmMs']:.4f} ms bei A1; NativePrewarmFailures/Limited = 0. 36 Motion-Fenster ohne neue Runtime-Keys, Clip-Misses, Key-Allokationen oder späte GR2-Parses.", '- Persistenter Shadercache aktiv: 125/125 Disk-Cache-Hits, 0 Misses/Compiles, 73 Einträge vor/nach dem Prozess hashgleich. Isolierte Kopie des vorhandenen Produktionscaches; Standardcache unberührt.', '- Zero Legacy: frische Source-Prüfungen plus DLL-/SDK-Markerprüfung der installierten und neu gebauten Release-EXE bestanden; kein D3D9/D3DX9, Granny oder SpeedTree im Productionpfad.', '', 'Der Smoke verwendet den unveränderten bestehenden Offline-Starteintrag im normalen installierten Client. Temporärer Root-Paketvergleich: 342 Einträge, ausschließlich prototype.py unterschiedlich; anschließend originales Produktionspaket wiederhergestellt. **Kein Netzwerklogin und keine neue manuelle Sichtabnahme.** Der frisch gebaute Release wurde nicht neu deployed, da Code/Buildkonfiguration unverändert und die Aufgabe den bestehenden Deploymentstand erhält.', '', '## Dateiintegrität', '', f"Installierte EXE: `{receipt['newExeSHA256']}`. Root-Paket: `{receipt['newRootSHA256']}`. Beide unverändert gegenüber dem Aufgabenbeginn. 549 vor dem Smoke geschützte Dateien nachher SHA256-identisch, einschließlich vorhandener Logs, Einstellungen, anderer Pakete und Root-Assetquellen. Temporäre Smoke-Ausgaben archiviert und aus dem Client entfernt.", '', 'Beim Checkout des alten Runtime-main war renderer-startup.log dort noch versioniert und wurde durch den späteren Fast-Forward entfernt. Das anfänglich beobachtete 340-Byte-Protokoll wurde aus einer bestehenden hashidentischen Sicherung wiederhergestellt; die ursprünglichen Grafikkonfigurationsbytes ebenfalls (ausschließlich von Git geänderte Zeilenenden). Beleg: runtime-log-preservation.json. Git ist nach Indexaktualisierung in beiden Checkouts clean.', '', '## Finale Logs (je -10)', '']
for name, repo in repositories.items():
    lines += [f'### {name.upper()}', '', '```text', *repo['log'], '```', '']
lines += ['## Lokale Belege', '', '`initial-git.json`, `document-classification.json`, `source-merge-preview.txt`, `source-resolution-ledger.json`, `source-merge.log`, `build-release.log`, `build-exit.json`, `fast-tests.log`, `fast-tests.xml`, `warm/fast-gate.json`, `warm/first-use-analysis.json`, `shader-cache-check.json`, `zero-legacy.json`, `protected-before.json`, `result.json`.', '', '**STOP nach MAIN-INTEGRATION-X. Kein Push, keine Branchlöschung, keine weitere Roadmap-Arbeit.**', '']
(out/'MAIN-INTEGRATION-X.md').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps(dict(status='PASS', source=repositories['source']['main'], runtime=repositories['runtime']['main'], tests=len(cases), runtimePID=result['runtime']['exit']['PID'], protectedFilesUnchanged=len(protected), cacheHits=125, report=str(out/'MAIN-INTEGRATION-X.md')), indent=2))
