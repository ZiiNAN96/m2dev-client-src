from pathlib import Path

def edit(name, old, new, count):
    p=Path(name)
    with p.open(encoding='utf-8',newline='') as f:s=f.read()
    newline='\r\n' if '\r\n' in s else '\n'
    s=s.replace('\r\n','\n')
    assert s.count(old)==count,(name,old,s.count(old),count)
    s=s.replace(old,new)
    with p.open('w',encoding='utf-8',newline='') as f:f.write(s.replace('\n',newline))

# Proxy owners decouple rendering from the player's legacy 3x3 query indices.
p='src/GameLib/MapOutdoorRenderSTP.cpp'
edit(p,'CTerrain * pTerrain;\n\tif (!GetTerrainPointer(ucTerrainNum, &pTerrain))',
       'CTerrain * pTerrain=pTerrainPatchProxy->terrainOwner;\n\tif (!pTerrain&&!GetTerrainPointer(ucTerrainNum, &pTerrain))',2)
# Only the within-patch budget test changes; the original Classic loops stay intact.
with Path(p).open(encoding='utf-8') as f:s=f.read()
start=s.index('void CMapOutdoor::__SoftwareTransformPatch_RenderPatchSplat(')
end=s.find('\nvoid ',start+5)
piece=s[start:end]
old='if (m_iRenderedSplatNum >= m_iSplatLimit)'
assert piece.count(old)==1,piece.count(old)
piece=piece.replace(old,'if (m_iRenderedSplatNum >= m_iSplatLimit&&!(m_stableWorld&&Renderer::GetGraphicsRuntimeConfig().style==Graphics::GraphicsStyle::Modern))')
s=s[:start]+piece+s[end:]
with Path(p).open('w',encoding='utf-8',newline='') as f:f.write(s.replace('\n','\r\n'))

