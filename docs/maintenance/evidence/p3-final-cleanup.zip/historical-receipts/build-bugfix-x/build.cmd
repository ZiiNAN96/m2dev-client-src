@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-bugfix-x\evidence\vs.log
if errorlevel 1 exit /b 1
cmake --build build-h2x/msvc --config Release --target UserInterface --parallel 6 > build-bugfix-x\evidence\build-%1.log 2>&1
exit /b %errorlevel%
