@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-bugfix-x\evidence\vs-gate.log
if errorlevel 1 exit /b 1
cmake --build build-h2x/msvc --config Release --target UserInterface VegetationModernTest VegetationRuntimeTest VegetationModernGpu TerrainTextureCpuTest TerrainGpuTest --parallel 6 > build-bugfix-x\evidence\build-gate.log 2>&1
if errorlevel 1 exit /b 1
ctest --test-dir build-h2x/msvc -C Release --output-on-failure -R "^(Vegetation\.(ModernContracts|Contracts|AllLegacyTypes|ModernGpu)|Renderer\.(TerrainTextureCpu|ProductionGpu))$" > build-bugfix-x\evidence\tests-release.log 2>&1
exit /b %errorlevel%
