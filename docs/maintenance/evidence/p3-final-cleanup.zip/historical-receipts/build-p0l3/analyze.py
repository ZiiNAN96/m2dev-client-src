import json,re,collections,pathlib
root=pathlib.Path('build-p0l3');loads=json.load(open('build-p0l/l3-analysis/summary.json'));cold=loads[1]
phases={'Shaders / PSOs','Shader graphics resources'}
subnames=['Actors / GPU Skinning','Static World','Vegetation','Shadows + shared composition','Terrain','PBR helpers','SSAO','HDR','Bloom','Tone Mapping','Sky / Atmosphere','Water','SSR','Effects','UI/Text','Shared PostFXContext','Shared/unattributed overhead']
def subsystem(name):
 s=name.lower(); d=s.split(' | ')[0]
 if d=='actors':return subnames[0]
 if d=='static-world':return subnames[1]
 if d=='vegetation':return subnames[2]
 if d.startswith('shadow') or (d=='unclassified' and ('compositevs' in s or 'compositeps' in s or 'direct shadow / indirect ao' in s)):return subnames[3]
 if d=='terrain' or (d=='unclassified' and ('terrain lod' in s or 'original splat pass' in s)):return subnames[4]
 if d=='brdf-ibl':return subnames[5]
 if d in ('ssao','ssao-first','screenspaceambientocclusion'):return subnames[6]
 if 'tone' in s:return subnames[9]
 if d in ('bloom','bloom-first'):return subnames[8]
 if d in ('atmosphere-tables','sky-atmosphere'):return subnames[10]
 if d=='water':return subnames[11]
 if d in ('ssr','screenspacereflection','g7-ssr-first'):return subnames[12]
 if 'effect' in s:return subnames[13]
 if d in ('postfxcontext','postfx-ssao-first'):return subnames[15]
 return subnames[16]
groupmap={
 'shader load':['shader-source-build','shader-source-include'],
 'shader compile':['shader-compilation'],
 'shader object creation':['shader-create','shader-native-object'],
 'PSO creation':['pso-creation'],
 'SRB':['srb-creation'],
 'DiligentFX own initialization':['fx-constructor','fx-initialize','fx-resources','fx-pipelines','fx-total'],
 'cache lookup':['native-shader-cache-lookup','shader-session-lookup','pso-session-lookup'],
 'graphics resources':['CreateBuffer','CreateTexture','CreateSampler'],
 'waits':['mutex-wait','shader-completion-wait']}
lookup={k:g for g,ks in groupmap.items() for k in ks}
cc=[c for c in cold['costs'] if c['phase'] in phases]
breakdown=collections.Counter(); kinds={}; subs={s:collections.Counter() for s in subnames}
for c in cc:
 k=c['kind']; g=lookup.get(k,'other'); ex=c['exclusive_ms'];breakdown[g]+=ex
 if k not in kinds:kinds[k]={'calls':0,'exclusive_ms':0,'inclusive_ms':0,'max_ms':0}
 z=kinds[k];z['calls']+=c['calls'];z['exclusive_ms']+=ex;z['inclusive_ms']+=c['inclusive_ms'];z['max_ms']=max(z['max_ms'],c['max_ms'])
 su=subs[subsystem(c['name'])];su['total_ms']+=ex;su[g]+=ex
 if k in ('shader-create','pso-creation','srb-creation','shader-compilation'):su[k+' calls']+=c['calls']
for s in subnames:
 for typ in ['l3-shader-key','l3-bytecode-key','l3-pso-key']:
  ee=[e for e in cold['events'] if e['kind']==typ and subsystem(e['name'].split(' | ',1)[1])==s]
  subs[s][typ+' requests']=sum(e['count'] for e in ee);subs[s][typ+' unique']=len({e['name'].split(' | ')[0] for e in ee})
 for typ in ['l3-shader-created','native-shader-cache-hit','native-shader-cache-miss','mesh-shader-hit','mesh-shader-miss','mesh-pso-hit','mesh-pso-miss','l3-fx-pso-hit','l3-fx-pso-miss']:
  subs[s][typ]=sum(e['count'] for e in cold['events'] if e['kind']==typ and subsystem(e['name'])==s)
stages={}
for c in cc:
 if c['kind']=='shader-compilation':
  stage=re.search(r'stage=(\d+)',c['name'])[1];z=stages.setdefault(stage,collections.Counter());z['count']+=c['calls'];z['exclusive_ms']+=c['exclusive_ms'];z['inclusive_ms']+=c['inclusive_ms']
counts=[]
for a in loads:
 ec=collections.Counter();kc=collections.Counter()
 for e in a['events']:ec[e['kind']]+=e['count']
 for c in a['costs']:kc[c['kind']]+=c['calls']
 uq={t:len({e['name'].split(' | ')[0] for e in a['events'] if e['kind']==t})for t in ['l3-shader-key','l3-pso-key','l3-bytecode-key']}
 counts.append({'label':a['label'],'total_ms':a['total_ms'],'block_ms':sum(a['phases'].get(p,0) for p in phases),'events':ec,'calls':kc,'unique':uq})
keys={}
for e in cold['events']:
 if e['kind']=='l3-shader-key':
  h,n=e['name'].split(' | ',1);z=keys.setdefault(h,{'count':0,'names':[]});z['count']+=e['count'];z['names'].append({'name':n,'count':e['count']})
dups=[v for v in keys.values() if v['count']>1]
result={'block_ms':sum(breakdown.values()),'breakdown':breakdown,'kinds':kinds,'stages':stages,'subsystems':subs,'counts':counts,'duplicate_inputs':dups,'top10':sorted((c for c in cc if c['kind']=='shader-compilation'),key=lambda c:c['exclusive_ms'],reverse=True)[:10]}
assert abs(result['block_ms']-sum(cold['phases'].get(p,0) for p in phases))<.001
assert abs(sum(s['total_ms'] for s in subs.values())-result['block_ms'])<.001
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print('BREAKDOWN',json.dumps(breakdown,indent=2));print('STAGES',stages)
for s,z in sorted(subs.items(),key=lambda i:-i[1]['total_ms']):print(s,dict(z))
print('DUPLICATES',json.dumps(dups,indent=2))
