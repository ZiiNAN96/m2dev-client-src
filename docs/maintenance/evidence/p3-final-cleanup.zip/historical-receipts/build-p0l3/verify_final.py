import pathlib,json,hashlib,subprocess
p=pathlib.Path('build-p0l3');root=pathlib.Path.cwd();runtime=root.parent/'m2dev-client'
def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-c','safe.directory='+str(repo),*args],cwd=repo,text=True,encoding='utf-8').strip()
results={}
for name in ['original-before','gr2-before']:
 arr=json.load(open(p/(name+'.json'),encoding='utf-8-sig'));checked=[]
 for q in arr:
  actual=sha(q['Path']);assert actual==q['Hash'].lower(),q['Path'];checked.append({'path':q['Path'],'sha256':actual})
 results[name.replace('before','unchanged')]=checked
arr=json.load(open(p/'source-backup/manifest.json',encoding='utf-8-sig'))
for q in arr:assert sha(root/q['path'])==q['sha256'],q['path']
results['temporary_files_restored']=arr
for label,repo in [('source',root),('runtime',runtime)]:
 assert not git(repo,'diff','--stat');assert not git(repo,'diff','--cached','--stat');subprocess.run(['git','-c','safe.directory='+str(repo),'diff','--check'],cwd=repo,check=True)
 results[label]={'branch':git(repo,'branch','--show-current'),'head':git(repo,'rev-parse','HEAD'),'status':git(repo,'status','--short')}
assert results['source']['head']=='611cd5086e85fc8a558598fa46658e17e5266b7f'
assert results['source']['status']=='?? docs/performance/p0l3-shader-pso-breakdown.md'
report=root/'docs/performance/p0l3-shader-pso-breakdown.md'
assert all(v==v.rstrip() for v in report.read_text(encoding='utf-8').splitlines())
for path in ['build-p0l3','build-p0l/l3-analysis']:
 assert git(root,'check-ignore',path)
for path in (root/'build-h2x/msvc/src/Renderer/shader-load-audit').glob('*.cpp'):
 s=path.read_text(encoding='utf-8');assert 'l3-' not in s and 'ResourceScope' not in s and 'shader-native-object' not in s
results['builds']={'diagnostic_release_exit':0,'restored_checkpoint_release_exit':0,'restored_exe_sha256':sha(root/'build-h2x/msvc/bin/Release/Metin2_Release.exe')}
results['report']={'path':str(report),'sha256':sha(report)}
results['fast_gate']=json.load(open('build-p0l/l3-analysis/fast-gate.json'))
(p/'final-state.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source':results['source'],'runtime':results['runtime'],'gr2_verified':len(results['gr2-unchanged']),'restored_files':len(arr),'original_files_verified':len(results['original-unchanged']),'status':'PASS'},indent=2))
