"""TEMPORARY P0-L3 measurements only; restore exact backups after the one run."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
files=['src/Renderer/ShaderLoadAudit.h','src/Renderer/FirstUseAudit.h',
       'src/Renderer/DiligentModernRenderer.cpp','src/Renderer/DiligentWater.cpp',
       'buildtool/PrepareShaderLoadAudit.py','buildtool/PrepareDiligentFX.py']
backup=root/'build-p0l3/source-backup'
backup.mkdir(exist_ok=False)
manifest=[]
for relative in files:
    data=(root/relative).read_bytes();target=backup/relative
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    manifest.append(dict(path=relative,sha256=hashlib.sha256(data).hexdigest()))
(backup/'manifest.json').write_text(json.dumps(manifest,indent=2))
def edit(relative,callback):
    p=root/relative;text=p.read_text(encoding='utf-8-sig');text=callback(text)
    p.write_text(text,encoding='utf-8',newline='\n')
def once(t,a,b):
    assert t.count(a)==1,(a,t.count(a))
    return t.replace(a,b)
def header(t):
    t=once(t,'    return result;','    result+=" flags="+std::to_string(unsigned(ci.CompileFlags))+" compiler="+std::to_string(unsigned(ci.ShaderCompiler))+" source="+(ci.ByteCode?"binary":"HLSL");\n    return result;')
    t=once(t,'shaderInputs.emplace(Hash(ci),name);','shaderInputs.emplace(Hash(ci),name);\n    MapLoadTrace::Count("l3-shader-key",Hash(ci)+" | "+name);')
    t=once(t,'pipelineInputs.emplace(Hash(ci),name);','pipelineInputs.emplace(Hash(ci),name);\n    MapLoadTrace::Count("l3-pso-key",Hash(ci)+" | "+name);')
    t=once(t,'    auto [it,inserted]=bytecodes.emplace','    MapLoadTrace::Count("l3-shader-created",name);\n    Diligent::XXH128State h;h.UpdateRaw(data,size);const auto digest=h.Digest();\n    MapLoadTrace::Count("l3-bytecode-key",std::to_string(digest.HighPart)+":"+std::to_string(digest.LowPart)+" | "+name);\n    auto [it,inserted]=bytecodes.emplace')
    t+=r'''
// TEMPORARY P0-L3, active only inside the existing explicit perf capture.
namespace ShaderLoadAudit {
inline bool InShaderScope() {
    if(!MapLoadTrace::state.active)return false;
    for(const auto& frame:MapLoadTrace::state.stack)
        if(frame.key.rfind("Shaders / PSOs\t",0)==0)return true;
    return false;
}
class ResourceScope : public MapLoadTrace::Scope {
public:
    ResourceScope(const char* type,const char* name):MapLoadTrace::Scope(
        InShaderScope()?"Shader graphics resources":"Graphics resources detail",Name(name),type){}
};
inline bool Lookup(bool hit,const char* kind,const char* name) {
    if(MapLoadTrace::state.active){MapLoadTrace::Count(std::string("l3-")+kind+"-request",Name(name));
        MapLoadTrace::Count(std::string("l3-")+kind+(hit?"-hit":"-miss"),Name(name));}
    return hit;
}
template<class T,class... Args> auto Make(const char* name,Args&&... args) {
    Domain owner(name);Scope timing("fx-constructor",Name(name));
    MapLoadTrace::Count("l3-fx-constructor",name);
    return std::make_unique<T>(std::forward<Args>(args)...);
}
}
'''
    return t.replace('#include <sstream>','#include <sstream>\n#include <memory>')
edit(files[0],header)
edit(files[1],lambda t:once(t,'p0lScope_("Shaders / PSOs",name,category,enabled)',
    'p0lScope_("Shaders / PSOs",ShaderLoadAudit::Name(name),category,enabled)'))
def modern(t):
    t=once(t,'shadowPass?"shadow":draw.auxiliary||draw.instances?"vegetation":"PBR"',
        'shadowPass?"shadow":draw.skinned?"actors":draw.auxiliary||draw.instances?"vegetation":"static-world"')
    for typ,label in [('PostFXContext','PostFXContext'),('ScreenSpaceAmbientOcclusion','SSAO'),('Bloom','Bloom'),
                      ('ShadowMapManager','ShadowMapManager'),('DiligentAtmosphere','Sky-atmosphere'),('DiligentWater','Water')]:
        needle='std::make_unique<'+typ+'>('
        assert needle in t,needle
        replacement='ShaderLoadAudit::Make<'+typ+'>("'+label+'",'
        t=t.replace(needle,replacement).replace('("'+label+'",)','("'+label+'")')
    return t
edit(files[2],modern)
edit(files[3],lambda t:once(t,'std::make_unique<ScreenSpaceReflection>(',
    'ShaderLoadAudit::Make<ScreenSpaceReflection>("SSR",'))
def core(t):
    marker='    output=destination/Path(relative).name'
    extra=r'''
    # TEMPORARY P0-L3 measurement-only additions to generated copies.
    if relative.endswith('RenderDeviceD3D11Impl.cpp'):
        for method,param in [('CreateBuffer','BuffDesc'),('CreateTexture','TexDesc'),('CreateSampler','SamplerDesc')]:
            start=text.index('void RenderDeviceD3D11Impl::'+method+'(')
            brace=text.index('\n{',start)+2
            name='nullptr' if method=='CreateSampler' else param+'.Name'
            text=text[:brace]+'\n    ShaderLoadAudit::ResourceScope l3Resource("'+method+'",'+name+');'+text[brace:]
    if relative.endswith('ShaderD3D11Impl.cpp'):
        text=replace(text,'    std::lock_guard<std::mutex> Lock{m_d3dShaderCacheMtx};',
            '    ShaderLoadAudit::Scope l3Mutex("mutex-wait",ShaderLoadAudit::Name(m_Desc.Name));\n    std::lock_guard<std::mutex> Lock{m_d3dShaderCacheMtx};\n    l3Mutex.Stop();')
        text=replace(text,'    auto* pd3d11Device = GetDevice()->GetD3D11Device();',
            '    ShaderLoadAudit::Scope l3Native("shader-native-object",ShaderLoadAudit::Name(m_Desc.Name));\n    auto* pd3d11Device = GetDevice()->GetD3D11Device();')
        text=replace(text,'    GetStatus(/*WaitForCompletion = */ true);',
            '    ShaderLoadAudit::Scope l3Wait("shader-completion-wait",ShaderLoadAudit::Name(m_Desc.Name));\n    GetStatus(/*WaitForCompletion = */ true);')
'''
    return once(t,marker,extra+'\n'+marker)
edit(files[4],core)
def fx(t):
    marker='    output = destination / relative'
    extra=r'''
    # TEMPORARY P0-L3: constructors timed at caller; component init/resources here.
    component=Path(relative).stem
    if relative.endswith('.cpp') and component in ('PostFXContext','ScreenSpaceAmbientOcclusion','Bloom','ScreenSpaceReflection','ShadowMapManager'):
        text='#include "Renderer/ShaderLoadAudit.h"\n'+text
        for method,kind in [('PrepareResources','fx-resources'),('PrepareShadersAndPSO','fx-pipelines'),('Initialize','fx-initialize')]:
            needle=component+'::'+method+'('
            if needle not in text:continue
            start=text.index(needle);brace=text.index('\n{',start)+2
            insertion='\n    ShaderLoadAudit::Domain l3Domain("'+component+'");\n    ShaderLoadAudit::Scope l3Scope("'+kind+'",ShaderLoadAudit::Name("'+method+'"));'
            if method=='Initialize':insertion+='\n    MapLoadTrace::Count("l3-fx-initialize","'+component+'");'
            text=text[:brace]+insertion+text[brace:]
        # Existing logical PSO requests, including already initialized techniques.
        text=text.replace('if (!RenderTech.IsInitializedPSO())',
            'if (!ShaderLoadAudit::Lookup(RenderTech.IsInitializedPSO(),"fx-pso","'+component+'"))')
'''
    return once(t,marker,extra+'\n'+marker)
edit(files[5],fx)
(root/'build-p0l3/instrumented-hashes.json').write_text(json.dumps([
    dict(path=p,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in files],indent=2))
print('Temporary diagnostic changes:',len(files),'files; exact backups preserved')
