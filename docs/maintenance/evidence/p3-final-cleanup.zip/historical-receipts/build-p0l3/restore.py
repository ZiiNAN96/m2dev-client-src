"""Restore only this investigation's byte-backed temporary edits, with drift checks."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
saved=json.loads((root/'build-p0l3/source-backup/manifest.json').read_text())
instrumented={x['path']:x['sha256'] for x in json.loads((root/'build-p0l3/instrumented-hashes.json').read_text())}
for entry in saved:
    path=root/entry['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==instrumented[entry['path']],entry['path']
for entry in saved:
    path=root/entry['path'];data=(root/'build-p0l3/source-backup'/entry['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==entry['sha256']
    path.write_bytes(data)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
(root/'build-p0l3/instrumentation-restored.json').write_text(json.dumps(dict(restored=True,files=saved),indent=2))
print('Restored exact checkpoint bytes:',len(saved),'files')
