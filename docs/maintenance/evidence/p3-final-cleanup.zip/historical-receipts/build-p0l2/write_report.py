import json
import sys
from collections import defaultdict
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tests/Loading'))
from summarize_shader_trace import category

before=json.loads((root/'build-p0l/l2-before/shader-summary.json').read_text())
after=json.loads((root/'build-p0l/l2-after/shader-summary.json').read_text())
raw=json.loads((root/'build-p0l/l2-before/summary.json').read_text())
b,a=before[1],after[1]
receipt=json.loads((root/'build-p0l2/deployment/receipt.json').read_text(encoding='utf-8-sig'))
zero=dict(count=0,inclusive_ms=0,exclusive_ms=0,max_ms=0)
def op(load,kind):return load['operations'].get(kind,zero)
def saved(x,y):return x-y,100*(x-y)/x
def table(headers,rows):return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in rows)
metrics=[('A1 Cold TOTAL',b['total_ms'],a['total_ms']),
         ('Shader / PSO: gesamte exklusive Phase',b['shader_pso_ms'],a['shader_pso_ms']),
         ('HLSL-Kompilierung inkl. Include-Callbacks',op(b,'shader-compilation')['inclusive_ms'],op(a,'shader-compilation')['inclusive_ms']),
         ('Eigene CreateShader-Aufrufe (P0-L-Messumfang)',op(b,'cpu')['inclusive_ms'],op(a,'cpu')['inclusive_ms'])]
rows=[]
for name,x,y in metrics:
    delta,pct=saved(x,y);rows.append([name,f'{x:.3f}',f'{y:.3f}',f'{delta:.3f}',f'{pct:.2f}%'])
text='''# P0-L2 - Shader / PSO Cold-Load

Stand: 2026-09-17. Genau ein funktionaler Fix: identische Modern-Vertexshader
werden im bestehenden Renderer pro Geometrie-/Tangent-/Instancing-Kombination
geteilt. Alle Pixelshader, PSO-Varianten, Grafikoptionen und Qualitaetsstufen
bleiben erhalten. Der komplette GR2-Ordner ist gegen den P0-L-Ausgangsstand
hashidentisch (13 Dateien; `build-p0l2/gr2-before.json`). Kein Commit, kein Push.

## Gemessener Effekt

Frisch gemessener, bereits GR2-optimierter P0-L-Stand gegen denselben Stand mit
Vertexshader-Wiederverwendung. Je ein neuer Prozess, identische Original-Packs,
Konfiguration, Kamera, drei Actors und die Route Client -> A1 -> B1 -> A1.
Cold bezeichnet einen neuen Prozess; der Windows-Dateicache wurde nicht geleert.

'''+table(['Messung (ms)','BEFORE','AFTER','Einsparung ms','Einsparung %'],rows)
text+='''
Die zuvor genannten ca. 1,248 s erfassten nur eigene CreateShader-Aufrufe.
Jetzt sind auch interne DiligentFX-Aufrufe erfasst: vor dem Fix 80 statt nur 36
Shader, danach 77 statt 33. Die alte Zahl wurde nicht als Baseline uebernommen.
Die gesamte Shader-/PSO-Phase enthaelt ausserdem Initialisierung, Audit- und
Diagnosekosten. Inklusive Untergruppen duerfen nicht addiert werden.

Dies ist ein einzelnes Vorher/Nachher-Paar, kein statistischer Benchmark.
Die beobachtete TOTAL-Differenz ist groesser als die direkt gemessene Shader-
Ersparnis. Insbesondere schwankt die unveraenderte GR2-Dekompression zwischen
1223,804 und 1171,967 ms. Die gesamte TOTAL-Differenz wird deshalb nicht allein
dem Fix zugeschrieben. Es wurde nichts vor den Messstart verschoben.

## Zerlegung der A1-Cold-Baseline

CPU-Wallclock; keine GPU-Ausfuehrungszeiten. `Summe exklusiv` zieht gemessene
Kinder ab. `Max einzeln` ist die inklusive Dauer eines einzelnen Aufrufs.
Include-Laden passiert innerhalb D3DCompile; native Shader-Cache-Lookups innerhalb
der PSO-Erstellung. Die Tabellen zeigen diese Verschachtelung explizit.

'''
kind_labels=[('shader-source-build','Shader-Source zusammenstellen / eingebettete Hauptquelle'),
             ('shader-source-include','Shader-Includes laden (eingebettete FX-Quellen)'),
             ('shader-compilation','D3DCompile / HLSL-Kompilierung'),
             ('shader-create','CreateShader: Kompilierung + Reflection / Objekt'),
             ('native-shader-cache-lookup','Diligent nativer Bytecode-Objektcache: Lookup inkl. Lock'),
             ('shader-session-lookup','Modern Mesh-Shader-Variantentabelle: Lookup'),
             ('pso-session-lookup','Modern Mesh-PSO-Tabelle: Lookup'),
             ('pso-creation','PSO-Erstellung (Graphics + Compute)'),
             ('srb-creation','SRB-Erstellung / Initialisierung statischer Ressourcen'),
             ('fx-total','DiligentFX / Adapter-Erstinitialisierung'),
             ('audit-shader-key','Diagnose: vollstaendiger Shader-Eingabehash'),
             ('audit-pso-key','Diagnose: PSO-Descriptor-/Bytecodehash'),
             ('audit-bytecode','Diagnose: exakter Bytecodevergleich')]
text+=table(['Operation','Count','Summe inkl. ms','Summe exkl. ms','Max einzeln ms'],
    [[label,op(b,k)['count'],f"{op(b,k)['inclusive_ms']:.3f}",f"{op(b,k)['exclusive_ms']:.3f}",f"{op(b,k)['max_ms']:.3f}"] for k,label in kind_labels])
text+='''
Ein persistenter Compile-/Render-State-Cache wird nicht abgefragt: Lookup 0,
Hit/Miss **nicht anwendbar**, da kein solcher Cache konfiguriert ist. Der native
Diligent-Cache speichert D3D11-Shaderobjekte innerhalb eines IShader; er vermeidet
keine erneute HLSL-Kompilierung fuer ein anderes IShader-Objekt.

Gemessene existierende Tabellen im A1-Cold: nativer Shader-Cache 13 Hits / 82
Misses; Modern-Mesh-Shader-Varianten 4 / 6; Modern-Mesh-PSOs 542 / 10. Nachher:
16 / 79, 4 / 6 und 542 / 10. Zusaetzlich werden nach dem Fix drei ModernVS neu
erzeugt und drei passuebergreifend wiederverwendet. Hit/Miss-Werte zaehlen die
instrumentierten Tabellen; eine nicht gemessene Tabelle wird nicht als 0 ausgegeben.

## Renderbereiche (A1 Cold)

Shaderzeiten sind inklusive Compiler-Include-Callbacks. Die Zeile Shadow
enthaelt auch Schattenvarianten von Vegetation und Terrain, damit jede
Kompilierung genau einmal zugeordnet wird. UI/Legacy/Effects verwendet gemeinsame
Renderer; es wurde keine isolierte Voll-UI-Abnahme ausgefuehrt.

'''
order=['PBR / IBL','Shadow','Vegetation','Terrain','Water / SSR','SSAO / PostFX','HDR / Bloom / Tone','Sky / atmosphere','Shadow / AO composition','UI / legacy / effects']
text+=table(['Bereich','Shader N vorher','Compile ms vorher','Max ms vorher','Shader N nachher','Compile ms nachher'],
    [[c,b['categories'].get(c,{}).get('shader-compilation',zero)['count'],
      f"{b['categories'].get(c,{}).get('shader-compilation',zero)['inclusive_ms']:.3f}",
      f"{b['categories'].get(c,{}).get('shader-compilation',zero)['max_ms']:.3f}",
      a['categories'].get(c,{}).get('shader-compilation',zero)['count'],
      f"{a['categories'].get(c,{}).get('shader-compilation',zero)['inclusive_ms']:.3f}"] for c in order])
rows=[]
for c in order:
    for kind,label in [('pso-creation','PSO'),('srb-creation','SRB')]:
        v=b['categories'].get(c,{}).get(kind,zero)
        rows.append([c,label,v['count'],f"{v['inclusive_ms']:.3f}",f"{v['max_ms']:.3f}"])
text+='\n'+table(['Bereich','Operation','Count vorher','Summe ms','Max einzeln ms'],rows)
cache_counts=defaultdict(lambda:defaultdict(int))
for event in raw[1]['events']:
    if event['kind'] in ('native-shader-cache-hit','native-shader-cache-miss','mesh-shader-hit','mesh-shader-miss','mesh-pso-hit','mesh-pso-miss'):
        cache_counts[category(event['name'])][event['kind']]+=event['count']
rows=[]
for c in order:
    counts=cache_counts[c];timing=b['categories'].get(c,{}).get('native-shader-cache-lookup',zero)
    mesh=lambda prefix:f"{counts[prefix+'-hit']} / {counts[prefix+'-miss']}" if c in ('PBR / IBL','Shadow','Vegetation') else 'n/a'
    rows.append([c,f"{counts['native-shader-cache-hit']} / {counts['native-shader-cache-miss']}",
                 f"{timing['inclusive_ms']:.3f}",f"{timing['max_ms']:.3f}",mesh('mesh-shader'),mesh('mesh-pso')])
text+='\nVorhandene gemessene Caches, BEFORE (n/a = diese Modern-Mesh-Tabelle gilt dort nicht):\n\n'+table(
    ['Bereich','Native Shader Hits / Misses','Lookup ms','Max ms','Mesh-Shader Hits / Misses','Mesh-PSO Hits / Misses'],rows)
text+='''
Die 48 PSOs enthalten einen Compute-PSO fuer die Atmosphaere. Der bisherige
P0-L-Zaehler `CreateGraphicsPipelineState=24` erfasste nur eigene Graphics-Aufrufe.
SRBs koennen mapabhaengige Texturen enthalten und deshalb trotz bestehendem PSO
neu entstehen. Die gemessenen SRB-Kosten sind hier kein relevanter Engpass.

DiligentFX-/Adapter-Erstinitialisierung, BEFORE (Kinder bereits in obigen Zeilen):

'''+table(['Block','Count','Gesamt inkl. ms','Eigenanteil exkl. ms','Max ms'],
    [[v['name'],v['calls'],f"{v['inclusive_ms']:.3f}",f"{v['exclusive_ms']:.3f}",f"{v['max_ms']:.3f}"] for v in b['fx_initialization']])
text+='''
Vollstaendige Operationen pro Bereich inklusive Source, Cache-Lookup und
Maximalwerten liegen in `build-p0l/l2-before/shader-summary.json` und
`build-p0l/l2-after/shader-summary.json`. Die unverkuerzte Shaderliste mit Makros
steht im [Runtime-Inventar](p0l2-runtime-shaders.md).

## Nachgewiesene Doppelarbeit und Auswahl des einen Fixes

In A1 Cold sind drei ModernVS-Bytecodes im Schattenpass exakt gleich dem
bereits kompilierten Farbpass: rigid (6508 Bytes), skin (8456 Bytes) und
instanced vegetation (8656 Bytes). Vergleich vollstaendiger Bytes, nicht nur
Shadernamen oder Hashes. Der Skinning-VS braucht dabei zweimal rund 306 ms.
Dies ist der groesste direkt nachgewiesene vermeidbare Compile-Block in A1 Cold.

'''
duplicates=[v for v in b['shaders'] if v['name'].startswith('shadow | ModernVS')]
text+=table(['Doppelt kompilierter VS','Count','Compile ms','Max ms'],
    [[('skin' if 'GDX_SKIN=1' in v['name'] else 'vegetation' if 'GDX_AUX=1' in v['name'] else 'rigid'),v['calls'],f"{v['inclusive_ms']:.3f}",f"{v['max_ms']:.3f}"] for v in duplicates])
text+=f"\nVorher gemessene Summe dieser drei Duplikate: {sum(v['inclusive_ms'] for v in duplicates):.3f} ms.\n"
text+='''
Fix in `DiligentModernRenderer::Impl::MeshShaders`:

- Vorhandenes Vertexshader-Array behaelt passspezifische Referenzen; diese zeigen
  auf denselben Vertexshader fuer identische Geometrie, Tangents und Instancing.
- Nur Passbits werden aus dem Vertex-Key entfernt (`shaderIndex - pass * 3`).
  GDX_SKIN, GDX_AUX, GDX_TANGENT und H2_INSTANCED bleiben im Key.
- Der Vollstaendigkeitscheck prueft den Pixelshader des jeweiligen Passes.
  Dadurch funktioniert auch ein zuerst angeforderter Schatten-/Forward-Pass.
- Pixelshader bleiben passspezifisch; Blend, Depth, Cull, Mirroring, Layout und
  Render-Target-Formate der PSOs sind unveraendert.
- Ownership bleibt beim bestehenden Modern-Renderer; Referenzen werden beim
  Renderer-Shutdown beziehungsweise Style-Wechsel freigegeben.

Der fokussierte CPU-Compilervergleich kompiliert alle 36 bestehenden Kombinationen
mit HLSL-Preamble und Include-Quellen der gepinnten Diligent-Version sowie denselben
Produktionsflags. 24 exakte Passvergleiche bestanden, inklusive Reflection-Daten
im Bytecode (`build-p0l2/equivalence.txt`). Kein Shadercode wurde geaendert.

Weitere Befunde, bewusst unveraendert: A1 hat 22 wiederholte identische
Shader-Inputs, vor allem FullScreenTriangleVS in FX, sowie einen identischen
PostFXContext::CopyTextureDepth-PSO. Beim Client-Setup entstehen 30 identische
Shader-Inputs und 24 identische PSO-Deskriptoren ueber gemeinsame Legacy-/Effect-
Rendererinstanzen. Diese Setup-Kosten liegen ausserhalb des A1-Timers.
Kein zweiter Cache-/PSO-/Threading-Fix wurde implementiert.

Die PSO-Duplikatsuche verwendet Diligents XXH128/HashCombiner auf den vollstaendigen
Graphics-/Compute-CreateInfos: Pipeline-/Resource-Layout, Blend, Depth/Stencil,
Rasterizer, Input-Layout, Formate, Topologie, Samples, Signaturen und Shaderbytecode.
Sie dient ausschliesslich der Diagnose und steuert keine Wiederverwendung.

## Laufzeit-Kompilierung und vorhandene Cache-Infrastruktur

48 Shader werden im Client-Setup aus eingebetteten Quellen kompiliert (BEFORE
1621,573 ms, AFTER 1571,711 ms). A1 erzeugt danach die oben aufgeschluesselten
80/77 Shader. Modern/Fx-Ressourcen werden beim ersten benoetigten Welt-/Renderpass
angelegt. Die Quellen werden beim Build eingebettet, aber nicht zu DXBC vorkompiliert.
Die Laufzeitkompilierung bedient die vorhandenen Geometrie-, Pass- und FX-Makros;
es gibt derzeit kein ausgeliefertes passendes Bytecodearchiv.

Gepinnte Infrastruktur geprueft:

- Core `b036337d68be2353c9950a85929acf796b9a6d50`, FX
  `cb380ac52100672b5762f595acfb6609e0ecc248`.
- `IBytecodeCache` / `CreateBytecodeCache` ist vorhanden. Der Key verarbeitet
  Source/Includes, Makros, Entry, Stage, CompileFlags, Compiler und Sprachversionen.
  Eine Produktionsintegration braeuchte zusaetzlich kontrollierte Persistenz,
  Versionierung und Fehlerbehandlung. Sie wurde nicht neu gebaut.
- `IRenderStateCache` und FX-`pStateCache` existieren, sind aber nicht verdrahtet.
  `DILIGENT_NO_ARCHIVER=ON`, `ARCHIVER_SUPPORTED=FALSE`,
  `RENDER_STATE_CACHE_SUPPORTED=FALSE`; die FX-Attribute bleiben nullptr.
- Der interne D3D11-Shaderobjektcache hilft wiederholten PSOs desselben IShader,
  erkennt jedoch keinen sourcegleichen, separat kompilierten IShader.

Fuer den gewaehlten Fix reicht die vorhandene Session-Variantentabelle. Kein
persistenter Cache, kein Precompile-System, keine Parallelisierung und keine
Compiler-/Optimierungsflags wurden eingefuehrt oder geaendert.

## Lifecycle und Synchronisation

'''
rows=[]
for old,new in zip(before,after):
    rows.append([old['label'],f"{old['total_ms']:.3f}",f"{new['total_ms']:.3f}",
                 f"{op(old,'shader-compilation')['count']} / {op(new,'shader-compilation')['count']}",
                 f"{op(old,'pso-creation')['count']} / {op(new,'pso-creation')['count']}",
                 f"{op(old,'srb-creation')['count']} / {op(new,'srb-creation')['count']}"])
text+=table(['Phase','TOTAL vorher ms','TOTAL nachher ms','Compile N vor/nach','PSO N vor/nach','SRB N vor/nach'],rows)
text+='''
ModernRenderer gehoert zum Backend. Mesh-/Terrain-Shader, PSO-Tabellen, Atmosphere,
Water, PostFX, SSAO und Bloom bleiben beim normalen Mapwechsel bestehen.
`ResetFrame` leert Draw-/Caster-Listen, nicht Pipeline-Caches. Map-Teardown tauscht
mapabhaengige Geometry/Texturen/Vegetation und deren Bindings aus. Resize kann
Fenster-/History-Ressourcen erneuern; Classic/Modern-Wechsel und Shutdown duerfen
den Renderer freigeben. Diese Regeln wurden nicht veraendert.

A1 -> B1 benoetigt vier neue PSOs (zwei Effect- und zwei Terrain-Varianten), keine
Kompilierung. B1 -> A1 braucht weder Shader noch PSO neu. Keine wiederholte
gesamte Renderer-Initialisierung durch Mapwechsel nachgewiesen.

Der Compiler wird synchron und seriell auf dem Main Thread aufgerufen. Keine
asynchrone Compilation ist in diesen eigenen/FX-CreateInfos angefordert.
Das Compile-Warten ist damit CPU-Arbeit innerhalb D3DCompile, kein GPU-Fence-Wait.
Der gemessene native Cache-Lock inklusive Lookup summiert sich auf 0,177 ms.

Im untersuchten Shader-/PSO-Erstellungspfad keine WaitForIdle-/Flush-/Fence-Waits.
`DiligentD3D11Backend::Shutdown` behaelt Flush + WaitForIdle. Screenshot-WaitForIdle
liegt nach dem stabilen Messendpunkt. Water::ReadPeak hat einen WaitForIdle nur
hinter `waterTestReadback`; dieser Testpfad ist im Probe aus. Keine Synchronisation
wurde entfernt. Present bleibt als getrennte Synchronisationsphase erhalten.

## FAST GATE und Auslieferung

- Release/UserInterface: PASS. Vorhandene Python/zlib-PDB-Linkwarnungen sind keine
  Rendererfehler; der finale Build endet mit Exit 0.
- Je einmal A1 Cold -> B1 -> A1 Warm, drei Actors, kurzer Smoke, 189 Frames: PASS.
- Je sauberer nativer Exit 0; keine Python-Fehler oder Renderer-Failure-Eintraege.
- Diligent ERROR/FATAL = 0, GPU fallback = 0, CPU deformation = 0.
- Alle 30 geprueften Shutdown-/Fehlerzaehler = 0, zusaetzlich Modern/Water-Renderer
  sowie Terrain-/Object-Ressourcen freigegeben. Details in `fast-gate.json`.
- Ein kurzer Blick auf beide A1-Aufnahmen zeigt Terrain, Actors und Vegetation
  weiterhin vorhanden; keine lange Visualpruefung oder manuelle Produktabnahme.
- Keine grosse Suite, kein Content-Test, kein Netzwerk-Login/Relog.
- Quell- und Originalclient-Repository getrennt geprueft; kein Commit/Push.

'''
text+=f'''Der exakt getestete Release wurde in den normalen `m2dev-client` kopiert.
SHA256: `{receipt['releaseSHA256']}`.
Der vorherige P0-L-Release ist unter `build-p0l2/deployment/backup/Metin2_Release.exe`
gesichert. 97 Pack-/Config-/Debug-Dateien blieben hashidentisch. Beleg:
`build-p0l2/deployment/receipt.json` und im Originalclient
`docs/p0l2-shader-loading-deployment.json`. **Client neu starten.**

## Reproduktion / Belege

- Baseline: `build-p0l/l2-before/` (map-load-trace.tsv, summary.json,
  shader-summary.json, fast-gate.json, hashes.json, Screenshots und native Logs).
- Nachher: `build-p0l/l2-after/`, gleicher Umfang und gleiche Root-Pack-Quelle.
- Release-Logs: `build-p0l/build-l2-baseline-final.log`,
  `build-p0l/build-l2-after.log`.
- Getrennte opt-in Messpunkte in generierten Kopien von drei gepinnten Core-
  Dateien; der DiligentCore-Checkout bleibt sauber. Der FX-SRB-Messpunkt wird
  im vorhandenen PrepareDiligentFX-Schritt eingebaut. Normale Starts aktivieren
  die Messung nicht. COST-Zeilen haben jetzt zusaetzlich `max_ms` als letzte Spalte.
- Befehle fuer eine gezielte Wiederholung stehen in `tests/Loading/README.md`.

P0-L2 abgeschlossen. STOP nach genau einem Shader-Fix.
'''
(root/'docs/performance/p0l2-shader-loading.md').write_text(text,encoding='utf-8')

inventory='''# P0-L2 - Runtime-Shader-Inventar

Erfasst direkt um D3DCompile in der frischen BEFORE-Baseline. Alle Werte in ms;
Count zaehlt Aufrufe, Max den teuersten Einzelaufruf. Gleiche Zeilen innerhalb
einer Phase sind aggregiert. Quellen/Includes sind eingebettet; der Zeitpunkt
ist vorhandene Renderer-/FX-Erstinitialisierung ohne Compile-Bytecodecache.
Der Vergleichsbericht steht in [P0-L2](p0l2-shader-loading.md).

'''
for load in before[:2]:
    inventory+=f"## {load['label']}\n\n"
    rows=[]
    for v in sorted(load['shaders'],key=lambda v:(category(v['name']),v['name'])):
        parts=v['name'].split(' | ')
        name=parts[1]+' / '+parts[2]+(' / '+parts[3] if parts[3] else '')
        rows.append([category(v['name']),name,v['calls'],f"{v['inclusive_ms']:.3f}",f"{v['max_ms']:.3f}",f'`{parts[4]}`'])
    inventory+=table(['Bereich','Entry / Source','Count','Summe ms','Max ms','Stage / Makros'],rows)+'\n'
(root/'docs/performance/p0l2-runtime-shaders.md').write_text(inventory,encoding='utf-8')
result=dict(metrics=[dict(name=n,before_ms=x,after_ms=y,saved_ms=x-y,saved_percent=100*(x-y)/x) for n,x,y in metrics],
            shader_compilations_before=80,shader_compilations_after=77,
            bytecode_equivalence='36 compilations, 24 exact comparisons PASS',gr2_files_unchanged=13,
            release_sha256=receipt['releaseSHA256'],single_fix='ModernVS pass-independent session reuse')
(root/'build-p0l2/result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
