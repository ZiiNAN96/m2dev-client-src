from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
for path in (root/'src/Renderer').glob('Diligent*.cpp'):
    text=path.read_text(encoding='utf-8-sig')
    text,n=re.subn(r'([\w.]+(?:\[[\w]+\])?)->CreateShaderResourceBinding\(([^;]+)\);',r'ShaderLoadAudit::CreateSRB(\1,\2);',text)
    if n and '#include "ShaderLoadAudit.h"' not in text:
        text='#include "ShaderLoadAudit.h"\n'+text
    if path.name=='DiligentModernRenderer.cpp':
        for marker,addition in [
            ('Pipeline& GetPipeline(const ModernMeshSubmission& draw,bool shadowPass,bool forwardPass) {','\n        ShaderLoadAudit::Domain p0lDomain(shadowPass?"shadow":draw.auxiliary||draw.instances?"vegetation":"PBR");'),
            ('void DrawTerrain(const ModernTerrainSubmission& item,bool shadowPass,const float4x4& lightVP) {','\n        ShaderLoadAudit::Domain p0lDomain(shadowPass?"shadow-terrain":"terrain");'),
            ('    if(useAO){','\n        FirstUseAudit p0lAO("fx-total","SSAO-first",!s.ao);')]:
            assert text.count(marker)==1, marker
            text=text.replace(marker,marker+addition)
    if path.name=='DiligentWater.cpp':
        marker='void MakePipeline(Pipeline& result,const char* pixel,TEXTURE_FORMAT format,bool geometry=false) {'
        assert text.count(marker)==1
        text=text.replace(marker,marker+'\n        ShaderLoadAudit::Domain p0lDomain("water");')
    if n or path.name=='DiligentModernRenderer.cpp':path.write_text(text,encoding='utf-8',newline='\n')
