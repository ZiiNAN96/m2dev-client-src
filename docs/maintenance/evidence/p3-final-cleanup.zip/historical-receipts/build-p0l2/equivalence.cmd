@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l2\vs-equivalence.log
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /O2 /EHsc /I src tests\Loading\mesh_vertex_equivalence.cpp /Fe:build-p0l2\mesh_vertex_equivalence.exe /Fo:build-p0l2\mesh_vertex_equivalence.obj /link d3dcompiler.lib > build-p0l2\equivalence-build.log 2>&1
if errorlevel 1 exit /b 1
build-p0l2\mesh_vertex_equivalence.exe build-deps\DiligentCore build-h2x\msvc\src\Renderer\fx-subset > build-p0l2\equivalence.txt 2>&1
exit /b %errorlevel%
