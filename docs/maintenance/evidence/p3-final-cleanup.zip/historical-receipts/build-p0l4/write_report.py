import json,pathlib
p=pathlib.Path('build-p0l4');r=json.load(open(p/'comparison.json'));a=r['empty']['loads'][1];b=r['warm']['loads'][1];f=r['final_breakdown']['loads'][1]
raw=json.load(open('build-p0l/l4-final-breakdown/summary.json'))[1]
exe=json.load(open(p/'validated-binary.json',encoding='utf-8-sig'))['Hash']
text=[]
def add(v=''):text.append(v)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('| '+' | '.join('---' for _ in headers)+' |')
 for row in rows:add('| '+' | '.join(map(str,row))+' |')
 add()
def n(v):return f'{v:.4f}'
add('''# P0-L4 – Persistent Versioned Shader Bytecode Cache

Stand: 2026-09-17. **Technisches GO.** Ausschließlich ein persistenter, versionierter Shader-Bytecodecache; keine Folgeoptimierung.

Basis: `611cd5086e85fc8a558598fa46658e17e5266b7f` (`perf(loading): reduce GR2 and shader initialization costs`). Der vorhandene, uncommitted P0-L3-Bericht bleibt bytegleich erhalten und wird nicht in den P0-L4-Commit aufgenommen.

## EMPTY CACHE / PERSISTENT WARM CACHE – neuer Prozess

Gleicher finaler Release-Build, originale Packs und unveränderte Grafikoptionen. A1 ist in beiden Fällen der erste Mapload des jeweiligen Prozesses. Das ist kein Vergleich mit einem warmen Mapload derselben Session.
''')
table(['A1-Messung','Empty cache','Persistenter Warm-Cache'],[
 ('Prozess-ID',r['empty']['pid'],r['warm']['pid']),('A1 total ms',n(a['total_ms']),n(b['total_ms'])),
 ('Shader/PSO/FX-Block ms',n(a['shader_block_ms']),n(b['shader_block_ms'])),
 ('Shader requests',a['requests'],b['requests']),('Cache hits',a['hits'],b['hits']),('Cache misses',a['misses'],b['misses']),
 ('Runtime compiles',a['compiles'],b['compiles']),('Compile time ms',n(a['compile_ms']),n(b['compile_ms'])),
 ('Cache read/validation time ms',n(a['read_ms']),n(b['read_ms'])),('Cache key time ms',n(a['key_ms']),n(b['key_ms'])),
 ('Cache write time ms',n(a['write_ms']),n(b['write_ms'])),('Bytes loaded from cache',a['bytes_loaded'],b['bytes_loaded'])])
add(f'''**DIFFERENCE: {n(r['difference']['ms_saved'])} ms gespart, {r['difference']['percent_saved']:.2f} % kürzer.**
Shaderkompilierung: **{n(r['difference']['compile_ms_saved'])} ms und 55 Aufrufe eingespart**; bekannte Shader im neuen Prozess: **77/77 Hits, 0 Misses, 0 Compiles**.

Der isolierte Cache war vor Test A leer. Die 22 Hits in A1 Empty sind identische Anfragen, die bereits im selben Prozess in die Dateischicht geschrieben wurden. Die 77 IShader-Anfragen und getrennten PSOs bleiben bestehen; es werden keine weiteren Shaderobjekte/Varianten zusammengelegt.

Der erstmalige Aufbau kostet in A1 **220.7490 ms Schreiben einschließlich Flush/Close/atomarem Replace**. Dieser Aufwand ist vollständig in der Empty-Zeit enthalten. Der beobachtete Vorteil von 1.521 s besteht daher nicht nur aus 1.241 s vermiedener Kompilierung: zusätzlich entfallen Cache-Schreibvorgänge, außerdem unterscheiden sich andere Ladeanteile um rund 56 ms. Keine Garantie einer schnelleren ersten Installation mit leerem Cache. Gegenüber P0-L3s historischem 3587-ms-Lauf ist der Empty-Lauf hier langsamer; das wird nicht als Cache-Gewinn umgedeutet.

Ein Messpaar, keine statistische Benchmarkserie. Windows-Dateicache nicht geleert; „cold“ bezeichnet den ersten Mapload eines neuen Prozesses. Der Compiler wird bei Hits nachweislich nicht aufgerufen, unabhängig davon, ob Windows die Cachedateien noch im RAM hat. Der Endpunkt bleibt MapLoadTrace stable-present: drei aufeinanderfolgende World-Presents bis 50 ms ohne neue Load-/Upload-/Compile-Aktivität. CPU-Wandzeit, keine GPU-Ausführungszeit.

Clientstart vor A1 separat:
''')
table(['Fenster','Gesamt ms','Requests','Hits / Misses','Compiles','Compile ms'],[(label,n(v['total_ms']),v['requests'],f"{v['hits']} / {v['misses']}",v['compiles'],n(v['compile_ms'])) for label,v in [('Empty client-setup',r['empty']['loads'][0]),('Warm client-setup',r['warm']['loads'][0])]])
add('''Damit trifft der Warm-Prozess über Clientstart und A1 insgesamt 125/125 bekannte Anfragen. 73 Cachedateien, 368420 Bytes einschließlich Header. Sämtliche Dateien bleiben über Warm-Smoke und Schlussmessung SHA256-identisch; keine temporären Dateien übrig.

## Vorhandene Infrastruktur und Implementierung

Die gepinnte Diligent-Core-Version bietet `IBytecodeCache` mit In-Memory-Map und Load/Store-Serialisierung, aber keine Dateiablage, atomare Veröffentlichung, Compiler-DLL-Identität, Stage-/Payload-Prüfsumme oder vorgeschaltete Größen-/DXBC-Validierung für beschädigte Dateien. Ihr Gesamtarchiv ist deshalb keine passende fertige Persistenz für die geforderten unabhängig reparierbaren Einträge. Es gab keinen angebundenen persistenten Produktcache.

Die kleine Dateischicht verwendet den vorhandenen Diligent-XXH128-ShaderCreateInfo-Hasher für Source, rekursive Includes und Descriptors. Kein zweiter In-Memory-Shader-/PSO-Cache; die vorhandenen Session-Caches bleiben unverändert. `ShaderBytecodeCache::Compile` sitzt direkt vor dem bestehenden FXC-Aufruf im generierten `ShaderD3DBase.cpp`. Dadurch erfasst sie sowohl unsere Shader als auch intern von DiligentFX erzeugte Shader. DiligentFX und der DiligentCore-Vendor-Checkout werden nicht editiert. Der Build-Hook prüft den erwarteten gepinnten Aufruf exakt und bricht bei nicht passender Integrationsstelle die Konfiguration ab.

HIT: validierten DXBC-Blob zurückgeben, danach normaler Diligent-IShader-/PSO-Pfad. MISS: exakt denselben D3DCompile-Aufruf mit unveränderten Parametern/Flags ausführen; nur erfolgreichen, validierten Bytecode speichern. DXC ist nicht Gegenstand dieser D3D11/FXC-Integration; alle 125 gemessenen Source-Anfragen benutzen den abgedeckten Pfad. Mitgelieferter Bytecode nimmt unverändert Diligents vorhandenen ByteCode-Pfad.

### Schlüssel und automatische Invalidierung

Der 128-Bit-Schlüssel umfasst:

- vollständige ShaderCreateInfo-Identität einschließlich Source und Include-Inhalten, EntryPoint, Stage, Macros, Sprache, Versions-/Reflection-Optionen und CompileFlags;
- den tatsächlich zusammengesetzten Compilertext einschließlich generiertem HLSL-Preamble, seine Länge und zusätzliche FXC-Macros;
- effektives Zielprofil und effektive FXC-Flags, einschließlich Debug-/Release-Unterschied und Matrixlayout;
- Backend/Compilerfamilie `D3D11/FXC` und Hash der tatsächlich geladenen D3DCompile-DLL; falls diese Identität nicht sicher ermittelt werden kann, wird der Cache umgangen;
- eigene Cache-Version und Formatversion, beide derzeit 1;
- DiligentCore-Pin `b036337d68be2353c9950a85929acf796b9a6d50` plus automatisch erzeugte SHA256-Fingerprints der relevanten Core-Compiler-/HLSL-/Hasher-Implementierungen.

Normale Änderungen von Source, Includes, Defines, EntryPoint oder Compilerkontext führen zu einem anderen Dateinamen/MISS. Keine manuelle Löschung nötig. Dateiname und Shader-Anzeigename allein sind keine Identität. Ein Versionswechsel lässt alte Einträge unbenutzt; keine zusätzliche Eviction-/Cleanup-Optimierung eingeführt.

### Format und Schreibsicherheit

Pro Schlüssel genau eine `.shadercache`-Datei. Explizit Little Endian, ohne C++-Struct-Padding:

| Offset | Inhalt |
| --- | --- |
| 0–7 | Magic `M2DXBC01` |
| 8–11 | Formatversion uint32 |
| 12–15 | Shader-Stage uint32 |
| 16–31 | Cache-Key XXH128 |
| 32–39 | Bytecode-Größe uint64 |
| 40–55 | DXBC-Prüfsumme XXH128 |
| ab 56 | vollständiger DXBC-Blob |

Beim Lesen: exakte Dateilänge, maximal 16 MiB Bytecode, Header/Key/Stage/Version, Payload-Prüfsumme, DXBC-Containergrenzen und D3DReflect-Stage/-ShaderModel prüfen. Ungültige/truncated Dateien ergeben MISS, normale Kompilierung und Ersatz des Eintrags. Keine Diligent-Fehlerdiagnose für erwartbare Cachekorruption. Fehlender/unzugänglicher/nicht beschreibbarer Cache ist keine Startvoraussetzung.

Beim Schreiben: exklusive neue Tempdatei mit Prozess-ID und atomarer Sequenz im selben Verzeichnis; vollständiger Header und Payload; FlushFileBuffers; Close; MoveFileEx(REPLACE_EXISTING | WRITE_THROUGH). Ein Leser sieht den bisherigen vollständigen Eintrag oder den neuen vollständigen Eintrag. Eigene fehlgeschlagene Tempdateien werden entfernt; nach einem harten Prozessabbruch verbleibende Tempdateien werden nie als Eintrag gelesen. Gleichzeitige Prozesse veröffentlichen unabhängig vollständig geschriebene Dateien.

### Ablage und Zähler

Standard: `%LOCALAPPDATA%/ZiiNAN/m2dev-client/cache/shaders/`, außerhalb des Source-/Runtime-Git-Checkouts. Ein absoluter Override ist mit `--shader-cache-dir=...` oder `M2_SHADER_CACHE_DIR` möglich; Kommandozeile hat Vorrang. Relative/unauflösbare Pfade führen zum normalen Compilerpfad, nicht zu einem Cache im aktuellen Source-Verzeichnis. Testcache: `build-p0l4/runtime-cache`, bereits durch `/build-*/` ignoriert. Keine zusätzliche `.gitignore`-Regel und keine Runtime-Repository-Änderung erforderlich.

Requests/Hits/Misses/Runtime-Compiles, Byteanzahl, Key-/Read-/Write-/Compilezeit, invalid/write-failure sowie Bytecode-Hashes laufen ausschließlich über den vorhandenen opt-in MapLoadTrace. Kein neues dauerhaftes Datei-Log oder Log-Spam im normalen Betrieb. Read-Zeit umfasst Öffnen, Lesen, Prüfung und Diagnose-Eigenarbeit, nicht nur physische Disk-I/O.

## INVALIDATION / Robustheit – PASS

Der gezielte native `ShaderBytecodeCacheTest` benutzt den tatsächlichen `CompileD3DBytecode`-Produktpfad:

1. Frisch kompilieren, dann HIT; vollständige Bytefolgen müssen identisch sein.
2. Genau ein Macro für einen Shader ändern: MISS und andere Bytefolge. Unveränderter zweiter Shader weiterhin HIT. Änderung zurücknehmen: ursprünglicher Shader wieder HIT.
3. Source, Include-Inhalt, EntryPoint und CompileFlags separat prüfen; Includes wiederherstellen und ursprünglichen HIT nachweisen.
4. Magic, Formatversion, Stage, Key, Größe, Checksumme und Payload einzeln beschädigen; Header und Payload abschneiden; ungültiges DXBC sogar mit neu passender äußerer Prüfsumme prüfen. Jeweils normale Kompilierung, bytegleiche Reparatur, danach HIT.
5. Cachepfad auf eine reguläre Datei richten: Lesen/Schreiben nicht möglich, Shader kompiliert trotzdem erfolgreich.
6. Gleichzeitige Anfragen auf einen noch nicht vorhandenen Eintrag: gültige atomare Veröffentlichung, danach bytegleicher HIT, keine verbliebenen Tempdateien.

Fixture-Änderungen betreffen ausschließlich isolierte Testshader und Dateien unter dem Buildverzeichnis. Keine Production-Shaderlogik oder temporäre Production-Versionänderung bleibt zurück. Test-Exit 0; `build-p0l4/cache-test-final.log`.

## Bytecode-Gleichheit

Alle 73 unterschiedlichen Eingabeschlüssel liefern in Empty-, Warm- und Schlussprozess dieselben DXBC-Prüfsummen. Die frisch gespeicherten 73 Dateien wurden zusätzlich vor/nach Warm-Läufen SHA256-verglichen. Der native Cache-Test vergleicht vollständige Bytefolgen. Repräsentative Production-Shader:
''')
table(['Shader','Bytecode Bytes','SHA256 des DXBC','Fresh = cached'],[(k,v['bytes'],v['dxbc_sha256'],'PASS') for k,v in r['representative_bytecode'].items()])
add('''Kurze Sichtkontrolle der beiden A1-Bilder: Terrain, Vegetation und drei Actors vorhanden, kein erkennbarer Shader-/Material-Ausfall. Kein pixelidentischer Screenshotvergleich dynamischer Animationen und keine vollständige manuelle Produktabnahme behauptet. Shader-, Material-, PSO- und Qualitätslogik bleiben unverändert.

## FAST GATE – PASS

- Release-Client und gezielter nativer Cache-Test gebaut, Exit 0. Bestehende Python/zlib-PDB-Linkerwarnungen; keine finalen Buildfehler.
- Empty A1 und Warm A1 in unterschiedlichen Prozessen bestanden.
- Warm-Prozess A1 → B1 → A1 bestanden. B1 391.4862 ms, A1 derselben Session warm 216.1933 ms; beide ohne Shaderrequests/Compiles.
- Invalidierung, Korruption, unzugängliches Cacheverzeichnis und Bytecode-Gleichheit bestanden.
- Alle 30 bestehenden Fehler-/Fallback-/Shutdown-Ressourcenprüfungen 0, insbesondere Diligent ERROR/FATAL, GPU fallback und CPU deformation. Zusätzlich Modern/Water/SSR-Fallbackprüfungen 0; Python-Fehlerlog leer. Alle drei akzeptierten Prozesse Exit 0.
- Keine volle Testsuite, kein GCC/LP64 (keine portable Core-Schnittstelle verändert), keine lange Visualprüfung, kein Netzwerklogin.

Die ersten beiden Diagnoseversuche `l4-empty-a1` / `l4-warm-process` wurden aus dem Ergebnis ausgeschlossen: die Umgebungsvariable kam im nativen Windows-Start nicht an, sodass der Standardcache verwendet wurde. Danach explizite CLI-Pfadübergabe ergänzt, Release und gezielten Test erneut gebaut/ausgeführt und Empty/Warm frisch wiederholt. Der tatsächlich verwendete Pfad wird jetzt in jedem Trace geprüft; für den Vergleich zählen ausschließlich `l4-final-empty` und `l4-final-warm`. Der Standardcache aus den Vorversuchen wurde nicht gelöscht.

## Neue vollständige Load-Breakdown nach technischem GO
''')
add(f'''Genau **ein** zusätzlicher Prozess für die Schlussmessung: PID **{r['final_breakdown']['pid']}**, A1 Cold **{n(f['total_ms'])} ms**, 77/77 Hits, 0 Misses, 0 Compiles, Shaderblock **{n(f['shader_block_ms'])} ms**. Dieser Lauf ersetzt nicht nachträglich das A/B-Messpaar oben.

Exklusive Phasen; Summe entspricht A1 total:
''')
table(['Phase','ms exklusiv','% A1'],[(k,n(v),f'{100*v/raw["total_ms"]:.3f}')for k,v in sorted(raw['phases'].items(),key=lambda v:-v[1])]+[('Gesamt',n(raw['total_ms']),'100.000')])
add('Top 10 einzelner exklusiver Kostenposten; verschachtelte inklusive Zeiten werden nicht addiert:\n')
table(['#','Posten','Aufrufe','ms exklusiv','% A1'],[(i+1,c['name'].replace('|','/'),c['calls'],n(c['exclusive_ms']),f'{100*c["exclusive_ms"]/raw["total_ms"]:.3f}')for i,c in enumerate(sorted(raw['costs'],key=lambda c:-c['exclusive_ms'])[:10])])
add('''**Größter verbleibender Posten: GR2-Section-Dekompression, 1227.4106 ms, rund 52.23 % des A1-Loads.** Nur berichtet; weder GR2 noch Animation, Asset Runtime, Terrain oder Vegetation weiter optimiert.

## Reproduktion, Nachweise und Scope
''')
add(f'Alle drei akzeptierten Prozesse verwenden dieselbe Release-EXE, SHA256 `{exe}`.\n')
add('''Die Testskripte erstellen private Clients mit Originalpacks, Originalkonfiguration und Offline-Mapprobe. Modern Preset 4, Shadows 4, AO 2, Water 3, Vegetation 2, Textures 1, HDR/Bloom/ModernSky an, ViewDistance 25600, Fog aus. Der Originalclient wurde nicht deployed oder ersetzt; seine Release-EXE und vorhandenen Deployment-Belege sind hashgleich geblieben. Daher ist dies ein technisches natives Gate, keine Behauptung einer neuen Abnahme im installierten Originalclient.

Gezielte Reproduktion mit neuen Evidenznamen und einem noch nicht vorhandenen absoluten Cachepfad:

```powershell
# In der vorhandenen VS-x64-Umgebung, Release:
cmake --build build-h2x/msvc --config Release --target UserInterface ShaderBytecodeCacheTest --parallel 6
ctest --test-dir build-h2x/msvc -C Release -R '^Renderer.ShaderBytecodeCache$' --output-on-failure
# Native Clientstarts benötigen wie bisher den normalen autorisierten Windows-Start.
tests/Loading/run_shader_cache_probe.ps1 -Name cache-empty -CacheDirectory C:/absolute/isolated-cache
tests/Loading/run_shader_cache_probe.ps1 -Name cache-warm -CacheDirectory C:/absolute/isolated-cache -ShaderLifecycle
python.exe tests/Loading/verify_probe.py build-p0l/cache-empty --a1-only
python.exe tests/Loading/verify_probe.py build-p0l/cache-warm --shader-lifecycle
python.exe tests/Loading/verify_shader_cache.py build-p0l/cache-empty build-p0l/cache-warm --output build-p0l4/comparison.json
```

Nach GO genau ein weiterer `run_shader_cache_probe.ps1` ohne ShaderLifecycle; `verify_probe.py --a1-only`, `summarize_trace.py` und `verify_shader_cache.py --breakdown <Pfad>` ergänzen die Abschlussprüfung. Keine existierenden Caches müssen gelöscht werden.

Lokale Belege, absichtlich nicht gestagt: `build-p0l4/build-release.log`, `cache-test-final.log`, `comparison.json`, `cache-after-final-empty.json`, `preservation.json`, `validated-source.json`, `validated-binary.json`; unter `build-p0l/l4-final-empty`, `l4-final-warm`, `l4-final-breakdown` jeweils `cache-run.json`, `exit.json`, `fast-gate.json`, `map-load-trace.tsv`, `summary.json`, `hashes.json` und native Logs. Frühere verworfene Versuche bleiben getrennt erhalten.

Source-Scope: `src/Renderer/ShaderBytecodeCache.{h,cpp}`, `buildtool/ShaderBytecodeCache.cmake`, `PrepareShaderBytecodeCache.py`, ein Include in `Diligent.cmake`, fokussierte Loading-Tests und deren CMake-/Probe-Anbindung. Keine GR2-/Asset-/Terrain-/Vegetations-/Textur-/Shaderlogik-/Materiallogik-/DiligentFX-Änderung. Alle 13 GR2-Quelldateien und der P0-L3-Bericht bytegleich geprüft. Runtime-Repository bleibt auf `548c43b4` mit seinen zwei vorbestehenden untracked Deployment-Belegen.

Commit bei diesem GO: **`perf(shaders): add persistent bytecode cache`**, ausschließlich die genannten Source-/Testdateien und dieser Bericht. Kein Cache, Buildoutput, Log, Screenshot oder Backup im Commit. **Kein Push. STOP nach Commit; keine GR2-Folgeoptimierung und kein P1.**
''')
# Ensure every printed cost comes from the final trace rather than a guessed value.
top=max(raw['costs'],key=lambda c:c['exclusive_ms'])
text=[v.replace('1227.4106 ms',f'{top["exclusive_ms"]:.4f} ms') for v in text]
assert abs(sum(raw['phases'].values())-raw['total_ms'])<.001
path=pathlib.Path('docs/performance/p0l4-persistent-shader-cache.md')
path.write_text('\n'.join(text),encoding='utf-8',newline='\n');print(path,path.stat().st_size)
