import hashlib
import json
import re
import sys
from pathlib import Path

out=Path(__file__).resolve().parent
src=out.parent
runtime=src.parent/'m2dev-client'
sys.path.insert(0,str(src/'tests/Loading'))
from summarize_trace import read

def data(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.file_digest(path.open('rb'),'sha256').hexdigest().upper()

deployment=data(out/'deployment.json')
assert sha(runtime/'Metin2_Release.exe')==deployment['newExeSHA256']
assert sha(src/'build-h2x/msvc/bin/Release/Metin2_Release.exe')==deployment['newExeSHA256']
assert sha(out/'backup/Metin2_Release.exe')==deployment['oldExeSHA256']
assert sha(runtime/'pack/root.pck')==deployment['newRootSHA256']
assert sha(out/'backup/pack/root.pck')==deployment['oldRootSHA256']
protected=data(out/'protected-before.json')
expected={'Metin2_Release.exe':deployment['newExeSHA256'],'pack/root.pck':deployment['newRootSHA256']}
checked=[]
for item in protected:
    path=item['path'].replace('\\','/')
    target=expected.get(path,item['sha256'])
    assert sha(runtime/path)==target, path
    checked.append(dict(path=path,sha256=target,changed=path in expected))
(out/'protected-after.json').write_text(json.dumps(checked,indent=2))
cache=data(out/'shader-cache-check.json')
assert cache['status']=='PASS'
assert data(out/'empty/cache-after.json')==data(out/'warm/cache-before.json')==data(out/'warm/cache-after.json')
all_uses=[]
for name in ('empty','warm'):
    d=out/name
    assert data(d/'fast-gate.json')['status']=='PASS'
    assert data(d/'exit.json')['ExitCode']==0
    assert 'phase=ShutdownClean' in (d/'gdxc-lifecycle.log').read_text()
    audit=(d/'source-resource-audit.log').read_text()
    for key in ('NativePrewarmFailures','NativePrewarmLimited','GrannyFileReads'):
        assert re.search(r'\b'+key+r'=0\b',audit),key
    rows=data(d/'first-use-analysis.json')['rows']
    assert len(rows)==36
    assert all(r['runtime_keys']==r['clip_misses']==r['allocation_requests']==r['late_gr2_parses']==0 for r in rows)
    all_uses.extend(rows)
    loads=read(d/'map-load-trace.tsv')
    assert [l['label'] for l in loads if not l['label'].startswith('first-use-')]==['client-setup','A1-cold','B1-first-in-session','A1-warm']
    assert loads[2]['label']=='first-use-player-Idle-1' and loads[-3]['label']=='first-use-mob-Death-3'
    for load in loads:
        if load['label'] in ('A1-cold','B1-first-in-session','A1-warm'):
            assert any(c['name']=='Production animation prewarm' and c['calls']>=1 for c in load['costs'])

warm=read(out/'warm/map-load-trace.tsv')
a1=warm[1]
assert a1['total_ms']<3000, 'STOP: production load regression'
animation_jobs=[e for e in a1['events'] if e['kind']=='animation-jobs']
worker_peaks=[e for e in a1['events'] if e['kind']=='animation-worker-peak']
assert sum(e['bytes'] for e in animation_jobs)==646
assert max(int(e['name']) for e in worker_peaks)==4
first=[dict(actor=r['actor'],motion=r['motion'],runtime_ms=r['runtime_motion_max_ms'],runtime_keys=r['runtime_keys']) for r in data(out/'warm/first-use-analysis.json')['rows'] if r['use']==1 and r['motion'] in ('Attack','Damage','Death')]
result=dict(status='GO',deployment=deployment,protectedUnchanged=len(checked)-2,replaced=len(expected),shaderCache=dict(status='PASS',entries=len(data(out/'warm/cache-after.json')),requests=sum(l['requests'] for l in cache['warm']['loads']),hits=sum(l['hits'] for l in cache['warm']['loads']),compiles=sum(l['compiles'] for l in cache['warm']['loads']),hashesUnchanged=True),a1LoadMs=a1['total_ms'],firstPresentMs=a1['first_present_ms'],prewarmMs=next(c['inclusive_ms'] for c in a1['costs'] if c['name']=='Production animation prewarm'),animationJobs=646,maxAnimationWorkers=4,firstUse=first,maxRuntimeMotionMs=max(r['runtime_motion_max_ms'] for r in all_uses),maps=[dict(label=l['label'],ms=l['total_ms']) for l in warm if l['label'] in ('A1-cold','B1-first-in-session','A1-warm')],zeroLegacy=data(out/'zero-legacy.json'),fastGate='PASS: both original-client processes, all required zero counters, clean exits',scope='Original-client offline production-path smoke; no network login or manual visual acceptance')
assert result['zeroLegacy']['status']=='PASS'
(out/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
