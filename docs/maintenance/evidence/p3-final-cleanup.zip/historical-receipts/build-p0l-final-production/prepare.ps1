$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$evidence=$PSScriptRoot
$audit="$source/build-h2x/msvc/tests/AssetRuntime/Release/PackContentAudit.exe"
$maker="$source/build-h2x/msvc/bin/Release/PackMaker.exe"
if(Test-Path "$evidence/backup"){throw 'Fresh backup required'}
New-Item -ItemType Directory -Path "$evidence/backup","$evidence/production-pack","$evidence/smoke-pack","$evidence/smoke-source" | Out-Null
$tracked=@{}
foreach($repo in @($source,$runtime)){
    $tracked[$repo]=@{branch=(& git -c "safe.directory=$($repo.Replace('\','/'))" -C $repo branch --show-current);head=(& git -c "safe.directory=$($repo.Replace('\','/'))" -C $repo rev-parse HEAD);status=@(& git -c "safe.directory=$($repo.Replace('\','/'))" -C $repo status --porcelain=v1)}
}
$tracked | ConvertTo-Json -Depth 5 | Set-Content "$evidence/git-before.json"
# Preserve installed files and every small runtime file the original client may write.
$mutable=@(Get-ChildItem -LiteralPath $runtime -File)+@(Get-ChildItem -LiteralPath "$runtime/config","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)
$mutable+=Get-Item -LiteralPath "$runtime/pack/root.pck"
$before=@()
foreach($file in $mutable){
    $relative=[IO.Path]::GetRelativePath($runtime,$file.FullName)
    $destination=Join-Path "$evidence/backup" $relative
    New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $destination
    $hash=(Get-FileHash -LiteralPath $file.FullName).Hash
    if((Get-FileHash -LiteralPath $destination).Hash -ne $hash){throw "Backup mismatch: $relative"}
    $before+=@{path=$relative;sha256=$hash;bytes=$file.Length}
}
$before | ConvertTo-Json -Depth 4 | Set-Content "$evidence/backup-manifest.json"
$protected=@(Get-ChildItem -LiteralPath "$runtime/pack","$runtime/config","$runtime/assets/root","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)+@(Get-ChildItem -LiteralPath $runtime -File)
$protected | ForEach-Object {@{path=[IO.Path]::GetRelativePath($runtime,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json -Depth 4 | Set-Content "$evidence/protected-before.json"
& $maker --input "$runtime/assets/root" --output "$evidence/production-pack" *> "$evidence/production-package.log"
if($LASTEXITCODE -ne 0){throw 'Production packaging failed'}
& $audit compare "$runtime/pack/root.pck" "$evidence/production-pack/root.pck" "$evidence/production-pack-diff.tsv" 'playersettingmodule.py' > "$evidence/production-pack-diff.log"
if($LASTEXITCODE -ne 0){throw 'Unexpected production pack delta'}
& $audit source "$evidence/production-pack/root.pck" "$runtime/assets/root" "$evidence/production-pack-source.tsv" > "$evidence/production-pack-source.log"
if($LASTEXITCODE -ne 0){throw 'Production pack does not match committed Python source'}
Copy-Item -LiteralPath "$runtime/assets/root" -Destination "$evidence/smoke-source/root" -Recurse
# Use the already accepted probe with its complete production prewarm enabled.
$entry=[IO.File]::ReadAllText("$source/tests/Loading/map_load_probe.py")
$animation=[IO.File]::ReadAllText("$source/tests/Loading/animation_first_use.py").Replace('LOAD_PREWARM = False','LOAD_PREWARM = True')
$entry=$entry.Replace('window = World()', $animation+"`nwindow = FirstUseWorld()")
$entry=$entry.Replace("('A1-warm', 'metin2_map_a1', 13000, 9500),",'')
$entry=$entry.Replace("('B1-warm', 'metin2_map_b1', 94300, 27100)","('A1-warm', 'metin2_map_a1', 13000, 9500)")
# Keep this deployment smoke short and avoid writing screenshots in the user client.
$entry=$entry.Replace("ok, path = grp.SaveScreenShotToPath('p0l-' + VIEWS[self.index][0] + '-')", "ok, path = True, 'disabled-for-production-smoke'")
$indented=($entry -split "`n" | ForEach-Object {"    $_"}) -join "`n"
$wrapped="import builtins, traceback`ntry:`n$indented`nexcept Exception:`n    with builtins.old_open('p0l-failure.log', 'w') as failure:`n        failure.write(traceback.format_exc())`n    import app`n    app.Exit()`n"
[IO.File]::WriteAllText("$evidence/smoke-source/root/prototype.py",$wrapped,[Text.UTF8Encoding]::new($false))
& $maker --input "$evidence/smoke-source/root" --output "$evidence/smoke-pack" *> "$evidence/smoke-package.log"
if($LASTEXITCODE -ne 0){throw 'Smoke packaging failed'}
& $audit compare "$evidence/production-pack/root.pck" "$evidence/smoke-pack/root.pck" "$evidence/smoke-pack-diff.tsv" 'prototype.py' > "$evidence/smoke-pack-diff.log"
if($LASTEXITCODE -ne 0){throw 'Unexpected temporary smoke pack delta'}
Write-Output 'Backup, protected hashes, production pack, and temporary smoke entry prepared.'
