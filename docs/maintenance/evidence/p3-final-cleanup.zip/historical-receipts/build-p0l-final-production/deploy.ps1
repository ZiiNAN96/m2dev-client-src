$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$before=Get-Content "$PSScriptRoot/protected-before.json" -Raw | ConvertFrom-Json
foreach($file in $before){if((Get-FileHash -LiteralPath (Join-Path $runtime $file.path)).Hash -ne $file.sha256){throw "Concurrent runtime change: $($file.path)"}}
if(Test-Path "$PSScriptRoot/deployment.json"){throw 'Already deployed'}
$built="$source/build-h2x/msvc/bin/Release/Metin2_Release.exe"
$old=(Get-FileHash "$runtime/Metin2_Release.exe").Hash
$new=(Get-FileHash $built).Hash
if((Get-FileHash "$PSScriptRoot/backup/Metin2_Release.exe").Hash -ne $old){throw 'EXE backup mismatch'}
if((Get-Item $built).LastWriteTime -lt (Get-Item "$PSScriptRoot/build.cmd").LastWriteTime){throw 'Build must be freshly generated'}
$sourceHead=(& git -C $source rev-parse HEAD)
$runtimeHead=(& git -c "safe.directory=$($runtime.Replace('\','/'))" -C $runtime rev-parse HEAD)
if($sourceHead -ne '80f77391fe28e533c20e1e686525c7f444c6c2ca' -or $runtimeHead -ne 'fabe77373bd561fb2f512449915ad5ab3c1fef62'){throw 'Approved commit changed'}
$oldRoot=(Get-FileHash "$runtime/pack/root.pck").Hash
$newRoot=(Get-FileHash "$PSScriptRoot/production-pack/root.pck").Hash
Copy-Item -LiteralPath $built -Destination "$runtime/Metin2_Release.exe" -Force
Copy-Item -LiteralPath "$PSScriptRoot/production-pack/root.pck" -Destination "$runtime/pack/root.pck" -Force
if((Get-FileHash "$runtime/Metin2_Release.exe").Hash -ne $new -or (Get-FileHash "$runtime/pack/root.pck").Hash -ne $newRoot){throw 'Installed files mismatch'}
$receipt=@{deployedAt=(Get-Date).ToString('o');sourceCommit=$sourceHead;pythonCommit=$runtimeHead;runtime=$runtime;oldExeSHA256=$old;newExeSHA256=$new;backupExeSHA256=(Get-FileHash "$PSScriptRoot/backup/Metin2_Release.exe").Hash;oldRootSHA256=$oldRoot;newRootSHA256=$newRoot;replaced=@('Metin2_Release.exe','pack/root.pck');backup="$PSScriptRoot/backup";protectedFiles=$before.Count;build='MSBuild UserInterface Rebuild Release x64; exit 0'}
$receipt | ConvertTo-Json -Depth 5 | Set-Content "$PSScriptRoot/deployment.json"
$receipt | ConvertTo-Json -Depth 5
