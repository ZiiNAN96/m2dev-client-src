@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l7c\vs.log
if errorlevel 1 exit /b 1
cmake --build build-h2x/msvc --config Release --target UserInterface GR2PreparationTest GR2SafetyTest GR2CompatibilityTest GR2GoldenTest GR2WarmupTest --parallel 6 > build-p0l7c\build-release.log 2>&1
exit /b %errorlevel%