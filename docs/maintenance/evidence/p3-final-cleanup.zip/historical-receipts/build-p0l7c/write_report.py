import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

root=Path.cwd()
sys.path.insert(0,str(root/'tests/Loading'))
from analyze_first_use import analyze
from summarize_trace import read
from animation_loading import analyze_animations

names=['l7c-reference','l7c-before','l7c-before-prewarm','l7c-after','l7c-unprepared']
data={name:analyze(root/'build-p0l'/name) for name in names}
for name in names:
    subprocess.run([sys.executable,'tests/Loading/verify_probe.py',str(root/'build-p0l'/name),'--shader-lifecycle','--animation-first-use'],check=True,stdout=subprocess.DEVNULL)
for name in names:
    for ref,row in zip(data['l7c-reference']['rows'],data[name]['rows']):
        assert (ref['actor'],ref['motion'],ref['use'],ref['path'])==(row['actor'],row['motion'],row['use'],row['path'])
        assert not row['late_gr2_parses'] and not any(e['name'].lower().endswith('.gr2') for e in row['late_file_requests'])

invariants=('gr2-parse','gr2-payload-crc','gr2-section-compressed','gr2-section-expanded','gr2-models','gr2-meshes','gr2-skeletons','gr2-animations','gr2-request','gr2-lookup-hit','gr2-lookup-miss','gr2-CopyVertices','gr2-CopyIndices','shader-cache-bytecode','animation-registration','animation-actor-reference')
def maps(name):
    return [l for l in read(root/'build-p0l'/name/'map-load-trace.tsv') if not l['label'].startswith('first-use-')]
reference=maps('l7c-reference')
for name in names[1:]:
    for a,b in zip(reference,maps(name)):
        assert a['label']==b['label']
        for kind in invariants:
            volume=lambda load:sorted((e['name'],e['count'],e['bytes']) for e in load['events'] if e['kind']==kind)
            assert volume(a)==volume(b),(name,a['label'],kind)
        assert not b['counters'].get('shader-runtime-compile',0) and not b['counters'].get('shader-cache-miss',0)
animation=analyze_animations(root/'build-p0l/l7c-after')[1]
assert animation['metrics']['parses']==animation['metrics']['unique']==693
assert animation['concurrency']['peak']==4

def row(name,actor,motion,use=1):
    return next(r for r in data[name]['rows'] if (r['actor'],r['motion'],r['use'])==(actor,motion,use))
def cold(name):
    return next(m['total_ms'] for m in data[name]['maps'] if m['label']=='A1-cold')
after=data['l7c-after']['rows']
original=2228.6578
l7=1337.3896
final=cold('l7c-after')
remaining=original-final
death=row('l7c-unprepared','player','Death')
stages=death['stages']
parts=[]
def add(text): parts.append(text.strip()+'\n')
add(f'''# P0-L7C – Animation First-Use Stall Closure

17.09.2026: **First-Use-Closure PASS; FINAL NO-GO wegen Ladezeit-Trade-off. Kein Staging, kein Commit, kein Push. HEAD bleibt 873d989.**

ROOT CAUSE: `Document::BoundClip` erstellt beim ersten Playback noch die immutable `RuntimeAnimationClip`-Keys für Clip/Skeleton/Trackgruppe/Loop-Rand. `ReadAnimation` beim Map Load hat lediglich Quellkurven/Knoten/Controls geparst. Die teure adaptive Spline-Konvertierung liegt in `GR2::BindAnimation` → `ConvertCurve`; neue Datei-Decodes sind nicht die Ursache. Player Death erzeugt **225.456 Keys**, mit **71,816 ms** Runtime-Vorbereitung im instrumentierten P0-L7-Before. Das erklärt den zuvor beobachteten 79,3-ms-Frame derselben Phase; es ist keine nachträgliche exakte Zerlegung des historischen Einzel-Frames.

SELECTED FIX: Genau eine funktionale Änderung erweitert die bestehende lokale Motion-Auswahl in `CActorInstance::PrewarmMotions` um **Damage und Death**. Sie erzeugt ihre realen Runtime-Strukturen über `PrepareGR2Animation`, einschließlich tatsächlichem GENERAL-Fallback, im bestehenden Loading-Prewarm. Kein künstliches Playback, keine weiteren Animationsgruppen, keine Kurven-/Qualitätsänderung, kein zusätzlicher Pool, keine Änderung an P0-L7-Parallelisierung oder Cache-Lebensdauer.

FIRST USE AFTER: Alle 36 Einsätze (2 Actors × 6 Motions × 3 Wiederholungen) haben **0 neue Runtime-Keys, 0 Clip-Misses, 0 gemessene Key-Vektorvergrößerungen und 0 späte GR2-Reads/Parses**. Maximaler einzelner `Instance::SetMotion` **{max(r['runtime_motion_max_ms'] for r in after):.4f} ms**. Gesamter Hintergrund-/Actor-/Effekt-Update maximal **{max(r['max_update_ms'] for r in after):.4f} ms**. Die normalen Probe-Frameabstände von rund 18–19 ms enthalten Frame-Pacing; sie sind nicht einmalige Animationskosten.

A1 COLD FINAL: **{final:.3f} ms**, gegenüber dem veröffentlichten P0-L7-Wert **{l7:.3f} ms** also **+{final-l7:.3f} ms**. Gegenüber der ursprünglichen seriellen Messung {original:.3f} ms verbleiben rechnerisch nur **{remaining:.3f} ms / {100*remaining/(original-l7):.1f} % des damaligen Gewinns**. Diese historischen Werte hatten allerdings den produktiven Prewarm ausgelassen. Darum weder behaupten, der kleine Closure-Fix koste allein 784 ms, noch daraus einen automatischen GO ableiten.

## Messumfang und korrigierte Ladegrenze

Der alte Offline-Probe und der rohe First-Use-Vergleich rufen `PrewarmVisibleActors` nicht auf. Im Produkt tut `PythonNetworkStream::PrepareGamePhase` dies innerhalb eines aktiven GPU-Frames bei noch sichtbarem LoadingWindow. Die bisherige lokale Auswahl deckt Idle/Walk/Run/Attack/Combos ab, aber **nicht Damage/Death**; umgebende Actors haben bereits eine breitere Common-Motion-Auswahl. Ein gezielter zusätzlicher Before-Lauf mit der bestehenden produktiven Grenze bestätigt: Attack und die Mob-Motions sind dort schon warm; Player Damage/Death bleiben kalt.

Der korrigierte After-Probe ruft denselben bestehenden `chrmgr.PrewarmVisibleActors(True)` vor dem World-Render auf. Er führt kein Prewarm durch Playback ein. Die zusätzliche Vorbereitung ist im A1-Cold-Timer enthalten, nicht außerhalb der Messgrenze versteckt. Die native Ladevorbereitung selbst dauert Before **701,909 ms**, After **832,766 ms**. Der Differenzbetrag **130,857 ms** betrifft die gezielte Erweiterung plus Run-to-Run-Streuung, nicht den gesamten zuvor fehlenden Block.

Private Release-Testclients mit Originalpacks, unverändert gefülltem Shadercache und privatem Root-Pack. Cold bedeutet frischer Prozess; der OS-Dateicache ist nicht kontrolliert. Jede Probe: A1 Cold → B1 → A1 Warm → Messungen → Exit, jeweils etwa 20 s. Keine Benchmarkschleife, kein Netzwerklogin, keine vollständige Suite, keine manuelle visuelle Abnahme behauptet. Jede Motion wird im vollständig geladenen letzten A1 dreimal unmittelbar nacheinander gestartet, ohne Instance-/Assetcache-Reset. Ein 0,35-s-Fenster misst den Beginn; die gesamte Clip-Zeitachse wird zusätzlich durch den Posevergleich abgedeckt.

Die real registrierten Zufallsvarianten werden nur im Test auf Subindex 0 gepinnt. Native erfolgreiche `animation-use`-Events und Race/Motion-Registrierungen beweisen für **alle Läufe** denselben Clip pro Actor/Motion/Wiederholung. Idle ist durch das normale Erzeugen der Actors schon gebunden; seine „First Use“ ist der erste explizite Testeinsatz, keine künstlich kalte Idle-Bindung.

## Serielle Referenz gegen P0-L7

**P0-L7 REGRESSION: no – keine verursachte oder systematische Verschlechterung des First-Use-Stalls nachgewiesen.** Der serielle HEAD-873d989-Referenzclient zeigt dieselbe `GR2 animation preparation`-Phase: Player Attack 42,493 ms und Death 70,100 ms; P0-L7 42,686 / 71,816 ms. Wiederholungen liegen nahe null. Ein zweiter unvorbereiteter Kontrolllauf mit finaler Diagnose zeigt Attack 41,639 / Death 72,021 ms und Mob Attack 45,569 ms gegenüber 47,946 ms seriell. Der erste instrumentierte Mob-Attack-Wert 53,925 ms ist somit kein stabiler Parallelisierungsaufschlag. Das sind begrenzte Einzelmessungen mit Diagnosekosten, kein statistischer Nichtunterlegenheitsnachweis.

Der serielle Referenz-Build ist die gesicherte L7-Before-EXE von HEAD 873d989 mit damaliger grober Trace-Diagnostik; sie besitzt keine feinen L7C-Untertimer. Im privaten Python-Source greift dort der vorhandene `hasattr`-Kompatibilitätspfad. Die Split-Timer messen ausschließlich `first-use-*`-Fenster; keine neue allgemeine Profiling-Infrastruktur.

## First / Second / Third Use

Je Feld: **First / Second / Third**, Millisekunden inklusive nativer `GR2 animation preparation` (Cache-Lookup + ggf. Konvertierung). Kein Python-Sleep/Render/Pacing enthalten. 0,0000 ist die Trace-Auflösung bzw. kein Dokument-Lookup beim unverändert laufenden Idle.

| Actor | Motion | Seriell HEAD | P0-L7 roh | Closure, produktiver Prewarm |
| --- | --- | ---: | ---: | ---: |''')
for actor in ('player','mob'):
    for motion in ('Idle','Walk','Run','Attack','Damage','Death'):
        values=[' / '.join(f"{row(name,actor,motion,u)['runtime_preparation_ms']:.4f}" for u in (1,2,3)) for name in ('l7c-reference','l7c-before','l7c-after')]
        add('| '+' | '.join([actor,motion]+values)+' |')
add('''## Frames und exklusive Animationskosten

Framewerte sind das Maximum des gesamten Beobachtungsfensters; `SetMotion max` umfasst den nativen einzelnen Kontrollwechsel einschließlich Cache-Lookups, ohne normale Render-/Posearbeit. Diese Trennung verhindert, den ungefähr 18-ms-Takt des Harness als First-Use-Stall zu bewerten.

| Actor | Motion | Frame Before ms | Frame After ms | SetMotion max After ms | Update max After ms |
| --- | --- | ---: | ---: | ---: | ---: |''')
for actor in ('player','mob'):
    for motion in ('Idle','Walk','Run','Attack','Damage','Death'):
        b=row('l7c-before',actor,motion); a=row('l7c-after',actor,motion)
        add(f"| {actor} | {motion} | {b['max_frame_ms']:.3f} | {a['max_frame_ms']:.3f} | {a['runtime_motion_max_ms']:.4f} | {a['max_update_ms']:.4f} |")
add(f'''## Spike-Zerlegung

Letzte unvorbereitete Kontrolle mit **derselben finalen EXE** wie After, nur ohne Lade-Prewarm: Player Death Frame **{death['max_frame_ms']:.4f} ms**, native Runtime-Vorbereitung **{death['runtime_preparation_ms']:.4f} ms**. Die funktionale Änderung greift ausschließlich in der Ladevorbereitung. Dieser Lauf dient der getrennten Runtime-/Skeleton-Lookup-Diagnose und behauptet keinen Produktfehler trotz ausgeführtem Prewarm.

| Stufe | Inklusive ms im 0,35-s-Fenster | Exklusive ms | Max. einzelner Aufruf ms | Aufrufe |
| --- | ---: | ---: | ---: | ---: |''')
for name in ('actor animation cache lookup','instance animation cache lookup','clip and skeleton cache lookup','AnimationRuntime lookup','skeleton and track group lookup','track to bone mapping','spline to runtime keyframes','keyframe allocations and relocation','clip binding and sampler initialization','pose buffer initialization','pose evaluation','bone matrix generation','GPU skinning binding preparation','GPU skinning palette preparation','attachment update','runtime motion state'):
    s=stages.get(name,dict(inclusive_ms=0,exclusive_ms=0,max_ms=0,calls=0))
    add(f"| {name} | {s['inclusive_ms']:.4f} | {s['exclusive_ms']:.4f} | {s['max_ms']:.4f} | {s['calls']} |")
for s in death['waits']+[c for c in death['other_window_costs'] if c['name']=='GR2 animation preparation']:
    label='other preparation / cache publication' if s['name']=='GR2 animation preparation' else s['name']
    add(f"| {label} | {s['inclusive_ms']:.4f} | {s['exclusive_ms']:.4f} | {s.get('max_ms',0):.4f} | {s['calls']} |")
add(f'''- `ConvertCurve` erzeugt {death['runtime_keys']:,} Keys; die gemessenen **{death['allocation_requests']} Key-Vektorvergrößerungen** summieren sich auf **{death['allocation_bytes']:,} angeforderte Kapazitätsbytes**. Das ist eine kumulative Kapazität, kein Peak-RAM-Wert. Diese Timer enthalten Allocate/Relocation sowie geringe Diagnosekosten. Andere temporäre Speicherarbeit (Knotzeit-Vektor, Track-Vektor, Validierungs-Bitset, Shared-Clip) verbleibt im jeweiligen Elternscope; kein vollständiger globaler Allocator-Trace wird behauptet.
- Eine separate Pose-Sampler-Initialisierung bzw. zusätzliche Index-/Sampling-Tabelle existiert hier **nicht**: `SampleTrack` sucht mit `upper_bound` direkt in den immutable Keys. Der Timer „clip binding and sampler initialization“ misst tatsächlich `RuntimeAnimationClip::Initialize`: validierte Tracks, Keywerte und Skeleton-BindingId. Deshalb kein erfundener separater Sampler-Zeitwert. Posebuffer entstehen beim Instance-Bau; im First-Use-Fenster **0 Aufrufe** ihrer Initialisierung.
- Hierarchie-/Palettenmatrizen sind von Pose-Sampling getrennt gemessen. Pose-/GPU-/Attachment-Werte summieren sich über alle vorhandenen Actors und Frames; sie sind keine zusätzlichen einmaligen Death-Kosten. Inklusive und verschachtelte Unterkosten dürfen nicht addiert werden.
- Late GR2 file access / decompression / parsing: **0 / 0 / 0** in sämtlichen 180 Beobachtungsfenstern. Die Bindung benutzt bereits gehaltene Modell-/Animationsdokumente.
- GPU/resource creation beim kontrollierten ersten Death: **{sum(death['gpu_resource_calls'].values())}**. Synchronisierung besteht aus dem separat vorhandenen Present-Timer, kein neuer Worker-/Clip-Wait. Sonstige Render-/Pacing-/Dateikosten bleiben vollständig in `other_window_costs` des JSON erhalten; sie werden nicht der Key-Konvertierung zugerechnet.

## Late File IO und Ressourcen

Es gibt keine späten Zugriffe auf bereits geladene GR2-Animationsassets. Normale Motion-Events laden bei Bedarf Sound bzw. den Fußstaub-Effekt. Diese kleinen, separaten Zugriffe werden nicht verschwiegen oder als Animation-Decode umgedeutet. Beispiel After:

| Actor / Motion / Use | Datei | Logische gelesene Bytes |
| --- | --- | ---: |''')
for r in after:
    if r['use']==1 and r['motion'] in ('Walk','Attack','Damage','Death'):
        for e in r['late_reads']:
            add(f"| {r['actor']} / {r['motion']} / 1 | `{e['name']}` | {e['bytes']} |")
walk=row('l7c-after','player','Walk')
add(f'''Player Walk erzeugt einmal die Staubtextur (`CreateTexture`: **0,0608 ms**); kein Shader/PSO wird dafür kompiliert. Der gesamte Dateizugriff dieses Fensters beträgt **{sum(c['exclusive_ms'] for c in walk['late_io_costs']):.4f} ms**, bei zwei Dateien. Dateipfade/Bytes und aggregierte I/O-Dauern je Fenster sind im JSON erhalten; die existierenden I/O-Timer ordnen die Dauer nicht jeder einzelnen Datei zu. Sounds/Effekte sind außerhalb des beauftragten Animations-Fixes geblieben.

## A1 Cold und Ladezeit-Trade-off

| Messung | A1 Cold ms | Bedeutung |
| --- | ---: | --- |
| Historisch vor P0-L7 | {original:.3f} | seriell, Offline-Probe ohne produktiven Prewarm |
| Historisch nach P0-L7 | {l7:.3f} | parallel, derselbe unvollständige Probe |
| Neue serielle Referenz | {cold('l7c-reference'):.3f} | identische First-Use-Testabfolge, ohne Prewarm |
| P0-L7 roh, vor Closure | {cold('l7c-before'):.3f} | feine First-Use-Diagnose, ohne Prewarm |
| P0-L7 mit bestehendem produktiven Prewarm | {cold('l7c-before-prewarm'):.3f} | Attack/Mob warm, lokales Damage/Death noch kalt |
| Closure mit vollständigem Prewarm | {final:.3f} | alle angeforderten First Uses warm |
| Finale EXE, unvorbereitete Diagnosekontrolle | {cold('l7c-unprepared'):.3f} | bestätigt erhaltene P0-L7-Ladeparallelisierung |

Der faire Vergleich innerhalb der **gleichen produktiven Ladegrenze** wächst von {cold('l7c-before-prewarm'):.3f} auf {final:.3f} ms, also **{final-cold('l7c-before-prewarm'):.3f} ms**. Ein serieller Gesamtstart mit produktivem Prewarm wurde nicht zusätzlich gemessen; daraus wird kein neuer vollständiger Produkt-Speedup extrapoliert. Die absolute Vorgabe ungefähr 1337 ms ist mit der nun vollständig erfassten Vorbereitung verfehlt. Daher **kein FINAL GO und kein Commit**, obwohl die First-Use-Schließung funktioniert. Keine zweite Optimierung an Binding, Auswahl, Hintergrund-Scheduling oder anderen Ladebereichen begonnen.

P0-L7 bleibt unverändert aktiv: **{animation['concurrency']['animation-jobs']} Animations-Dateijobs**, Peak **{animation['concurrency']['peak']}**, {animation['metrics']['parses']} Animations-Parses vor dem Spiel, unveränderte Requests/Cachehits/Bytes/CRCs/Registrierungen. Finaler B1-Start **{data['l7c-after']['maps'][2]['total_ms']:.3f} ms**, A1 Warm **{data['l7c-after']['maps'][3]['total_ms']:.3f} ms**.

## Korrektheit und FAST GATE

- **PASS Release Build** des finalen C++-Baums; keine Debug-/GCC-/Vollsuite. Bestehende Drittanbieter-Linkerhinweise, kein Buildfehler im finalen Build.
- **PASS 903 Dateien / 7224 Sections / 60.042.028 Bytes** seriell vs. parallel bytegleich; komplette relevante IR identisch, einschließlich 217 Modelle, 281 Meshes, 282 Materialien, 217 Skeletons, 729 Bones und 693 Animationen. 903 halbierte Inputs sauber abgelehnt.
- **PASS 13 reale Modell-/Clip-Paare**, alle Runtime-Keys/BindingIds/Zielbones/Dauern/Loop-Ränder identisch, **234 Posen exakt gleich**. Der erweiterte Test bereitet den echten Clip über `PrepareGR2Animation` vor und fordert beim ersten `SetMotion` ausdrücklich **keinen erneuten BindAnimation-Aufruf**. Kein Scheduling-abhängiger ID-Wechsel.
- **PASS 7/7 gezielte GR2-Tests**: Compatibility, Golden static/animation, Preparation, Warmup, Safety, Independence. Warmup prüft immutable Vorbereitung/Playbackzustand, geteilte Dokument-Lebensdauer und allokationsfreie warme Motion-/Poseaufrufe.
- **PASS 36/36 finale Motion-Einsätze**: Idle/Walk/Run/Attack/Damage/Death je Player/Mob und je First/Second/Third. Native Pfadidentität bestätigt; maximale einzelne Runtime-Motion-Kosten deutlich unter 8,33 ms, keine neue Key-Konvertierung.
- **PASS A1 → B1 → A1 und Exit 0**, finale `syserr.txt` leer. Diligent ERROR/FATAL **0**, GPU fallback **0**, CPU deformation **0**, alle geprüften Shutdown-Ressourcen **0**. Derselbe Ressourcen-Gate besteht auch für die vier Vergleichsläufe.
- **PASS native Daten-Invarianten** zwischen allen fünf Läufen für Maploads: gleiche GR2-Requests/Cachehits/Parses, CRCs/Sectionbytes, Modell-/Skeleton-/Animationscounts, Kopierbytes, Registrierungen und Shaderbytecodes. Shader misses/runtime compiles **0**.
- **PASS Erhaltungsprüfung:** sieben geschützte Dateien (einschließlich Original-EXE, Original-root.pck, fremde Doku, Area.cpp und Decoder) und alle 73 gefüllten Shadercache-Dateien hashgleich. Kein Deployment in den Originalclient. Runtime-Python bleibt die vorhandene L7-Änderung.
- **FINAL PERFORMANCE GATE: NO-GO.** Der vollständige Ladepreis bleibt deutlich außerhalb des beauftragten P0-L7-Zielbereichs. Dieser Blocker wird nicht durch den bestanden funktionalen First-Use-/Ressourcen-Gate ersetzt.

## Reproduzierbare lokale Evidenz

Build/Test: `build-p0l7c/build-release.log`, `corpus-runtime.log`, `focused-tests.log`, `preservation-after.json`, `shader-after.json`. Anfangsstand gesichert in `p0l7-start.diff` und `p0l7-start-hashes.json`.

Je Probe unter `build-p0l/<Name>/`: `map-load-trace.tsv`, `animation-first-use.json`, `first-use-analysis.json`, `fast-gate.json`, `exit.json`, `source-resource-audit.log`, `p0l-smoke.log`, private EXE und Pack-Manifest. Diese Build-/Trace-/Cache-/Testclient-Dateien bleiben ungestagt.

| Probe | Release-EXE SHA256 |
| --- | --- |''')
for name in names:
    add(f"| `{name}` | `{hashlib.sha256((root/'build-p0l'/name/'Metin2_Release.exe').read_bytes()).hexdigest().upper()}` |")
add('''Analyse: `python tests/Loading/analyze_first_use.py build-p0l/l7c-after --expect-prepared`; Ressourcen-Gate: `python tests/Loading/verify_probe.py build-p0l/l7c-after --shader-lifecycle --animation-first-use`. Vorbereitung über `prepare_probe.ps1 -ShaderLifecycle -AnimationFirstUse -LoadPrewarm`; Kontrolllauf lässt nur `-LoadPrewarm` weg. Alle CLI-Evidenznamen müssen für native Wiederholung frisch sein.

## Git / STOP

Source-Branch `codex/g56-hdr-atmosphere`, HEAD **873d989**; Runtime-Branch `codex/g56-hdr-colors`, HEAD **548c43b4**. Keine Änderungen zurückgesetzt, keine fremden Dateien angefasst, Index leer. **Commit-Hash: keiner**, weil FINAL GO nicht erreicht ist. Kein Push. STOP nach dieser einen Closure und ihrer Dokumentation; keine weitere Ladeoptimierung/P1.
''')
report=re.sub(r'(?m)(^\|[^\n]*\n)\n(?=\|)',r'\1','\n'.join(parts))
(root/'docs/performance/p0l7c-animation-first-use.md').write_text(report,encoding='utf-8')
result=dict(first_use='PASS',correctness='PASS',data_invariants='PASS',resources='PASS',final='NO-GO',cold_ms=final,raw_l7_cold_ms=l7,cold_growth_ms=final-l7,reason='Corrected full loading boundary exceeds requested P0-L7 cold-load target; existing prewarm omitted from historical probe',commit=None)
(root/'build-p0l7c/closure-gate.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
