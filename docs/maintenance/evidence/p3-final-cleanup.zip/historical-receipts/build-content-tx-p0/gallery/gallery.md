# CONTENT-TX-P0: A1 Grass-Proof

Gleiche Kamera, Modern/High, A1-Environment, feste Wind-/Himmelzeit. C ersetzt nur A1-Slot 005.

## A - Originaltextur + bisheriges 3D-Gras

![A](A.jpg)

## B - Originaltextur ohne 3D-Gras

![B](B.jpg)

## C - Neue Grass-Textur ohne 3D-Gras

![C](C.jpg)
