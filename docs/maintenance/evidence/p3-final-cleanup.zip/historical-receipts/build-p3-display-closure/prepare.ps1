param([string]$Name='baseline')
$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
if($Name -notmatch '^[a-z0-9-]+$'){throw 'Invalid run name'}
$target=Join-Path $PSScriptRoot $Name
if(Test-Path -LiteralPath $target){throw 'Fresh run required'}
New-Item -ItemType Directory -Path "$target/test-root","$target/pack","$target/log","$target/mark","$target/upload" | Out-Null
Copy-Item -LiteralPath "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe" -Destination "$target/Metin2_Release.exe"
Copy-Item -LiteralPath "$runtime/config" -Destination "$target/config" -Recurse
Copy-Item -LiteralPath "$source/build-p3-main-production/normal-source/root" -Destination "$target/test-root/root" -Recurse
$changed=git -C $runtime diff --name-only -- assets/root
if($LASTEXITCODE -ne 0){throw 'Cannot inspect runtime diff'}
foreach($path in $changed){Copy-Item -LiteralPath "$runtime/$path" -Destination "$target/test-root/root/$([IO.Path]::GetFileName($path))" -Force}
$entry=[IO.File]::ReadAllText("$source/tests/Graphics/p3_display_closure_entry.py")
$indented=($entry -split "`n" | ForEach-Object {"    $_"}) -join "`n"
$wrapped="import builtins, traceback`ntry:`n$indented`nexcept Exception:`n    with builtins.old_open('closure-failure.log', 'w') as failure:`n        failure.write(traceback.format_exc())`n    import app`n    app.Exit()`n"
[IO.File]::WriteAllText("$target/test-root/root/prototype.py",$wrapped,[Text.UTF8Encoding]::new($false))
foreach($package in Get-ChildItem -LiteralPath "$runtime/pack" -File){if($package.Name -ne 'root.pck'){New-Item -ItemType HardLink -Path "$target/pack/$($package.Name)" -Target $package.FullName | Out-Null}}
New-Item -ItemType Junction -Path "$target/bgm" -Target "$runtime/bgm" | Out-Null
& "$source/build-h2x/msvc/bin/Release/PackMaker.exe" --input "$target/test-root/root" --output "$target/pack" *> "$target/package.log"
if($LASTEXITCODE -ne 0){throw 'Packaging failed'}
Copy-Item -LiteralPath "$source/build-p3-main-production/shader-cache" -Destination "$target/shader-cache" -Recurse
[IO.File]::AppendAllText("$target/config/graphics.cfg","`nRESOLUTION_WIDTH 1024`nRESOLUTION_HEIGHT 768`nDISPLAY_MODE 0`nSTYLE 1`nFRAME_RATE_LIMIT 0`nVSYNC 0`n")
Get-FileHash -LiteralPath "$target/Metin2_Release.exe","$target/pack/root.pck" | ConvertTo-Json | Set-Content "$target/hashes.json"
Write-Output $target
