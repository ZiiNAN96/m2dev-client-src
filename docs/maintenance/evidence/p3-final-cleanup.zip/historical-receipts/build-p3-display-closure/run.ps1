param([string]$Name='closure-final',[ValidateSet('closure','restart','manual')][string]$Case='closure')
$ErrorActionPreference='Stop'
if($Name -notmatch '^[a-z0-9-]+$'){throw 'Invalid run name'}
$run=Join-Path $PSScriptRoot $Name
if(Test-Path "$run/exit.json"){throw 'Run already complete'}
[IO.File]::WriteAllText("$run/closure-case.txt",$Case)
$windowStyle=if($Case -eq 'manual'){'Normal'}else{'Hidden'}
$arguments='--renderer-diagnostics --shader-cache-dir="'+$run+'\shader-cache"'
$p=Start-Process -FilePath "$run/Metin2_Release.exe" -WorkingDirectory $run -ArgumentList $arguments -WindowStyle $windowStyle -PassThru
$p.Id | Set-Content "$run/pid.txt"
@{PID=$p.Id;Path="$run/Metin2_Release.exe";Arguments=$arguments} | ConvertTo-Json | Set-Content "$run/launch.json"
$p.WaitForExit()
@{ExitCode=$p.ExitCode;PID=$p.Id} | ConvertTo-Json | Set-Content "$run/exit.json"
Get-Content "$run/closure-failure.log" -ErrorAction SilentlyContinue
Get-Content "$run/closure-run.jsonl" -Tail 1 -ErrorAction SilentlyContinue
