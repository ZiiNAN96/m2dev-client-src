from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parent.parent;d=r/'build-p2'
def load(p):return json.loads((d/p).read_text(encoding='utf-8-sig'))
before=load('before/summary.json');after=load('after/summary.json')
assert before.keys()==after.keys() and len(after)==10
settings=None
for name,data in [('before',before),('after',after)]:
 assert load(name+'/fast-gate.json')['completed']==10
 meta=(d/name/'p1-meta.txt').read_text(encoding='utf-8')
 assert 'dropped=0 detailsDropped=0 VSync=0 uncapped=1 legacy_fixed_simulation_ticks=1' in meta
 assert 'dropped=0' in (d/name/'p1-gpu-meta.txt').read_text(encoding='utf-8')
 events=[json.loads(x) for x in (d/name/'p1-run.log').read_text(encoding='utf-8').splitlines()]
 for e in events:
  if e['event']=='prepare':
   if settings is None:settings=e['settings']
   assert e['settings']==settings
 for key,v in data.items():
  assert v['gpu_samples']==v['frames'] and v['seconds']>=19
  assert abs(v['game_seconds']/v['wall_seconds']-1)<.002
  assert 59<v['counter_totals']['game_ticks']/v['seconds']<62
  c=v['counter_totals']
  for counter in ['terrain_load','terrain_unload','area_load','area_unload','terrain_rebuild','tree_repeat']:
   assert c[counter]==0,(name,key,counter,c[counter])
 assert data['A1_TRAVERSAL']['counter_totals']['instance_growth']==before['A1_TRAVERSAL']['counter_totals']['instance_growth']==3
 assert data['A1_TRAVERSAL_REPEAT']['counter_totals']['instance_growth']==0
 assert data['A1_TRAVERSAL_REPEAT']['counter_totals']['instance_create']==0
assert before['A1_TRAVERSAL_REPEAT']['counter_totals']['pack_read']==30
for key in ['A1_TRAVERSAL_REPEAT','A1_COMBAT']:
 for counter in ['pack_read','texture_create']:assert after[key]['counter_totals'][counter]==0
for key in after:assert after[key]['cpu_active']['avg']<before[key]['cpu_active']['avg'],key
assert (d/'production-build.exit').read_text(encoding='utf-8-sig').strip()=='0'
assert re.search(r'100% tests passed(?:, 0 tests failed)? out of 3', (d/'tests.log').read_text(encoding='utf-8'))
assert load('release-smoke/fast-gate.json')['completed']==2
assert not (d/'release-smoke/p1-meta.txt').exists()
production_events=[json.loads(x) for x in (d/'release-smoke/p1-run.log').read_text(encoding='utf-8').splitlines()]
fps=[e['render_fps'] for e in production_events if e['event']=='end']
assert all(50<=x<=65 for x in fps),fps
assert not (r/'src/Renderer/RuntimePerf.h').exists()
assert not (r/'src/Renderer/RuntimePerfGpu.h').exists()
for item in load('original-manifest.json'):
 p=r/item['path'];expected=d/'production'/item['path']
 wanted=hashlib.sha256(expected.read_bytes()).hexdigest() if expected.exists() else item['sha256']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==wanted,item['path']
integrity=load('integrity.json');assert not integrity['changed'] and integrity['root_changed']==['prototype.py']
for name in ['before','after']:
 line=next(x for x in (d/name/'p2-texture-memory.tsv').read_text().splitlines() if 'effects=1' in x)
 assert 'finalTextures=0 finalPayloadBytes=0' in line
lines=(d/'after/effect-renderer.log').read_text(encoding='utf-8').splitlines()
assert 0<len(lines)<=256 and not any(x.startswith('ERROR') for x in lines)
result=dict(status='PASS',release='PASS',tests='PASS (3/3, finaler normaler Release)',runtime_integrity=f'PASS ({integrity["protected_files"]} Dateien)',normal_release_fps=fps,after_frames=sum(v['frames'] for v in after.values()),before_frames=sum(v['frames'] for v in before.values()),effect_log_lines=len(lines),settings=settings)
(d/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
