from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'entry.py').read_text(encoding='utf-8')
s=s.replace('width,height=systemSetting.GetWidth(),systemSetting.GetHeight()',
'''assert not hasattr(app,'RuntimePerf'), 'Temporary profiling API remains in production build'
app.RuntimePerf=lambda stage: None
width,height=systemSetting.GetWidth(),systemSetting.GetHeight()''')
s=s.replace("'P2 isolated uncapped profiling'","'P2 final Release smoke'")
s=s.replace("emit(dict(event='end',stage=self.index,", "emit(dict(event='end',render_fps=app.GetRenderFPS(),update_fps=app.GetUpdateFPS(),stage=self.index,")
(r/'production-entry.py').write_text(s,encoding='utf-8')
print('Production smoke entry ready; asserts the profiling API is absent')
