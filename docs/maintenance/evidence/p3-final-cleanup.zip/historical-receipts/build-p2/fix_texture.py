from pathlib import Path
r=Path(__file__).resolve().parent.parent
rel='src/EffectLib/EffectRenderBridge.cpp'
def transform(s):
 s=s.replace('#include "EterLib/StaticObjectTextureLoader.h"\n','')
 s=s.replace('std::unordered_map<const void*,std::string> textureNames;\nstd::unordered_map<std::string,std::weak_ptr<TerrainTexture>> textures;',
 '''// Native effect images own decoded pixels and uploader-specific GPU textures.
// This lookup is only used synchronously within the current effect frame.
std::unordered_map<const void*,CGraphicImage*> textureImages;''')
 s=s.replace('serial=effectFrameSerial; textureNames.clear();\n    for(auto it=textures.begin();it!=textures.end();) if(it->second.expired()) it=textures.erase(it); else ++it;',
             'serial=effectFrameSerial; textureImages.clear();')
 s=s.replace('textureNames[texture]=image->GetFileName();','textureImages[texture]=image;')
 old='''        auto found=textureNames.find(bound.Identity());
        if(found==textureNames.end()) { Report("unresolved native texture",true); return; }
        auto& owned=owner->textures[found->second];
        if(!owned) {
            auto& shared=textures[found->second]; owned=shared.lock();
            if(!owned) { owned=LoadStaticObjectTextureFile(found->second.c_str(),*effectRenderer); shared=owned; }
            if(owned) Report("texture "+found->second,false);
        }
        if(!owned) { Report("texture upload "+found->second,true); return; }
        texture=owned;'''
 new='''        auto found=textureImages.find(bound.Identity());
        if(found==textureImages.end()) { Report("unresolved native texture",true); return; }
        const std::string filename=found->second->GetFileName();
        auto& owned=owner->textures[filename];
        if(!owned) {
            // Reuse the already decoded native image instead of reopening its pack
            // whenever a short-lived particle instance drops its last weak handle.
            // The image cache is invalidated by device/resource destruction and
            // distinguishes uploader lifetimes, including recreation at one address.
            owned=found->second->GetAssetTexture(*effectRenderer);
            if(owned) Report("texture "+filename,false);
        }
        if(!owned) { Report("texture upload "+filename,true); return; }
        texture=owned;'''
 assert old in s;s=s.replace(old,new)
 assert 'textureNames' not in s and 'std::weak_ptr' not in s
 return s
for src,dst in [(r/'build-p2/original'/rel,r/'build-p2/production'/rel),(r/rel,r/rel)]:
 s=transform(src.read_text(encoding='utf-8'));dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(s,encoding='utf-8',newline='\r\n')
print('Effect image lifetime fixed in profiling and clean production copies')
