from pathlib import Path
r=Path(__file__).resolve().parent.parent
rel='src/Renderer/DiligentModernRenderer.cpp'
bindings=[('ObjectVS','VERTEX','ModernObject'),('ObjectPS','PIXEL','ModernObject'),('Lighting','PIXEL','ModernLighting'),('BRDF','PIXEL','PreintegratedBRDF'),('Irradiance','PIXEL','IrradianceMap'),('SkyIrradiance','PIXEL','SkyIrradiance'),('SkyEnvironment','PIXEL','SkyEnvironment'),('IBLSampler','PIXEL','IBLSampler'),('Composite','PIXEL','Composite'),('ShadowMap','PIXEL','ShadowMap'),('ShadowSampler','PIXEL','ShadowSampler'),('ScreenAO','PIXEL','ScreenAO'),('Palette','VERTEX','SkinningPalette'),('BaseMap','PIXEL','BaseMap'),('NormalMap','PIXEL','NormalMap'),('RoughnessMap','PIXEL','RoughnessMap'),('MetallicMap','PIXEL','MetallicMap'),('AOMap','PIXEL','AOMap'),('EmissiveMap','PIXEL','EmissiveMap'),('MaterialSampler','PIXEL','MaterialSampler'),('CameraAlpha','PIXEL','CameraAlphaTexture'),('CameraAlphaSampler','PIXEL','CameraAlphaSampler')]
def transform(s):
 old='    std::map<unsigned,Pipeline> pipelines;'
 cache='''    // A mesh SRB owns its bindings. Resolve optional shader variables once,
    // then only change resources whose identity differs from the current binding.
    enum class MeshBinding {'''+','.join(x[0] for x in bindings)+''',Count};
    struct MeshPipeline : Pipeline {
        struct Binding {IShaderResourceVariable* variable{};IDeviceObject* resource{};};
        std::array<Binding,static_cast<size_t>(MeshBinding::Count)> bindings{};
        void InitializeBindings() {
'''
 for id,stage,name in bindings:
  cache+=f'            bindings[static_cast<size_t>(MeshBinding::{id})].variable=srb->GetVariableByName(SHADER_TYPE_{stage},"{name}");\n'
 cache+='''        }
        void Bind(MeshBinding slot,IDeviceObject* resource) {
            auto& binding=bindings[static_cast<size_t>(slot)];
            if(binding.variable&&binding.resource!=resource) {
                binding.variable->Set(resource);binding.resource=resource;
            }
        }
        void UnbindAssets() {
            // Preserve the existing map-change lifetime boundary, and invalidate
            // the cache together with the SRB so the next draw always rebinds.
            for(auto slot:{MeshBinding::BaseMap,MeshBinding::NormalMap,MeshBinding::RoughnessMap,
                MeshBinding::MetallicMap,MeshBinding::AOMap,MeshBinding::EmissiveMap,
                MeshBinding::Palette,MeshBinding::ScreenAO,MeshBinding::ShadowMap,MeshBinding::CameraAlpha})Bind(slot,nullptr);
        }
    };
    std::map<unsigned,MeshPipeline> pipelines;'''
 assert old in s;s=s.replace(old,cache)
 s=s.replace('    Pipeline& GetPipeline(', '    MeshPipeline& GetPipeline(')
 old='Require(bool(result.srb),"G-DX mesh SRB");return result;'
 assert old in s;s=s.replace(old,'Require(bool(result.srb),"G-DX mesh SRB");result.InitializeBindings();return result;')
 old='for(auto stage:{SHADER_TYPE_VERTEX,SHADER_TYPE_PIXEL})Set(pipeline.srb,stage,"ModernObject",objectCB);'
 assert old in s;s=s.replace(old,'pipeline.Bind(MeshBinding::ObjectVS,objectCB);pipeline.Bind(MeshBinding::ObjectPS,objectCB);')
 for id,stage,name in bindings[2:]:
  s=s.replace(f'Set(pipeline.srb,SHADER_TYPE_{stage},"{name}",',f'pipeline.Bind(MeshBinding::{id},',1)
 old='''        const char* names[]{"BaseMap","NormalMap","RoughnessMap","MetallicMap","AOMap","EmissiveMap"};
        for(unsigned i=0;i<6;++i)Set(pipeline.srb,SHADER_TYPE_PIXEL,names[i],item.textures[i]?item.textures[i].RawPtr():item.textures[0].RawPtr());'''
 new='''        constexpr MeshBinding maps[]{MeshBinding::BaseMap,MeshBinding::NormalMap,MeshBinding::RoughnessMap,
            MeshBinding::MetallicMap,MeshBinding::AOMap,MeshBinding::EmissiveMap};
        for(unsigned i=0;i<6;++i)pipeline.Bind(maps[i],item.textures[i]?item.textures[i].RawPtr():item.textures[0].RawPtr());'''
 assert old in s;s=s.replace(old,new)
 old='''    for(auto& pair:s.pipelines)for(auto stage:{SHADER_TYPE_VERTEX,SHADER_TYPE_PIXEL})
        for(const char* name:{"BaseMap","NormalMap","RoughnessMap","MetallicMap","AOMap","EmissiveMap","SkinningPalette","ScreenAO","ShadowMap","CameraAlphaTexture"})Impl::Set(pair.second.srb,stage,name,nullptr);'''
 assert s.count(old)==2;s=s.replace(old,'    for(auto& pair:s.pipelines)pair.second.UnbindAssets();')
 return s
for src,dst in [(r/'build-p2/original'/rel,r/'build-p2/production'/rel),(r/rel,r/rel)]:
 s=transform(src.read_text(encoding='utf-8'));dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(s,encoding='utf-8',newline='\r\n')
print('Mesh bindings optimized in profiling and clean production copies')
