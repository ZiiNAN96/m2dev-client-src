from pathlib import Path
r=Path(__file__).resolve().parent.parent
rel='src/EffectLib/EffectRenderBridge.cpp'
def transform(s):
 s=s.replace('#include <set>','#include <set>\n#include <vector>')
 old='std::ofstream diagnostics;'
 new='''struct EffectDiagnostics {
    std::ofstream stream;
    std::vector<std::string> pending;
    ~EffectDiagnostics() { Flush(); }
    void Flush() {
        if(pending.empty()) return;
        if(!stream.is_open()) stream.open("effect-renderer.log",std::ios::trunc);
        for(const auto& line:pending) stream << line << '\\n';
        pending.clear();stream.flush();
    }
    void Record(const std::string& key,bool error) {
        // Report caps unique messages at 256. Successful first-use diagnostics
        // must not stall rendering on file I/O; errors still flush immediately.
        pending.push_back(error ? "ERROR "+key : key);
        if(error) Flush();
    }
} diagnostics;'''
 assert old in s;s=s.replace(old,new)
 old='''    if(!diagnostics.is_open()) diagnostics.open("effect-renderer.log",std::ios::trunc);
    diagnostics << (error ? "ERROR " : "") << key << std::endl;'''
 assert old in s;s=s.replace(old,'    diagnostics.Record(key,error);')
 return s
for p in [r/'build-p2/production'/rel,r/rel]:
 p.write_text(transform(p.read_text(encoding='utf-8')),encoding='utf-8',newline='\r\n')
print('Bounded success diagnostics deferred to shutdown; errors still flush')
