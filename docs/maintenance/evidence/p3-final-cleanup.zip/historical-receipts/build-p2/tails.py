from pathlib import Path
import csv,json,statistics
r=Path(__file__).resolve().parent
def st(a):
 a.sort();return dict(avg=statistics.fmean(a),p95=a[int((len(a)-1)*.95)],p99=a[int((len(a)-1)*.99)],maximum=a[-1])
result={}
for name in ['before','after']:
 groups={};previous=None
 for row in csv.DictReader((r/name/'p1-frames.csv').open(encoding='utf-8')):
  row={k:float(v) for k,v in row.items()};s=int(row['stage'])
  if s not in (3,7,9):previous=row;continue
  if not previous or previous['stage']!=s:previous=row;continue
  g=groups.setdefault(s,dict(ft=[],cpu=[],present=[],tick=[],top=[]))
  cpu=sum(v for k,v in previous.items() if k.startswith('cpu_') and k not in ('cpu_sleep','cpu_present'))
  ft=row['interval_ms'];g['ft'].append(ft);g['cpu'].append(cpu);g['present'].append(previous['cpu_present'])
  item={k:previous[k] for k in ['serial','cpu_present','wall_ms','cpu_other','game_ticks','cpu_effects','cpu_shadows','cpu_static_world']};item.update(ft=ft,cpu=cpu,outside=ft-previous['wall_ms'])
  g['top'].append(item);g['top'].sort(key=lambda x:-x['ft']);g['top']=g['top'][:5]
  previous=row
 result[name]={str(k):dict(ft=st(v['ft']),cpu=st(v['cpu']),present=st(v['present']),top=v['top']) for k,v in groups.items()}
(r/'tails.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
