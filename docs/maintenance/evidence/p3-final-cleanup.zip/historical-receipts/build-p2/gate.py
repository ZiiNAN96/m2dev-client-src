from pathlib import Path
import json,re,sys
r=Path(sys.argv[1]);e=json.loads((r/'exit.json').read_text(encoding='utf-8-sig'));assert e['ExitCode']==0,e
assert not (r/'p1-failure.log').exists()
assert (r/'log/syserr.txt').stat().st_size==0
events=[json.loads(x) for x in (r/'p1-run.log').read_text().splitlines()]
assert events[-1]['event']=='completed'
audit=(r/'source-resource-audit.log').read_text()
zero_keys=('DiligentErrors DiligentFatals AllCPUDeformationCalls AllCPUDeformationVertices GPUFallbacks GraphicsSettingsObjects SourceTextures SourceBuffers SkinMeshes BoneRemaps BonePalettes SkinPreparationFailures CollisionResources VegetationAssets VegetationInstances VegetationRenderAssets VegetationGeometry VegetationInstanceBuffers VegetationInstanceBytes VegetationFailures AssetDocuments AnimationInstances MeshBindings GR2ReaderResources RuntimeSkeletons RuntimeAnimationClips IndependentAnimationInstances AnimationRuntimeFailures PrototypeGeometry PrototypePalettes').split()
for key in zero_keys:assert re.search(r'\b'+key+r'=0\b',audit),key
gdx=(r/'gdx-renderer.log').read_text()
for key in ('WaterRenderers','ModernRenderers','ssrFallbacks'):assert re.search(r'\b'+key+r'=0\b',gdx),key
terrain=(r/'terrain-renderer.log').read_text()
for key in ('terrain_vertices','terrain_indices','terrain_textures','object_geometry','object_textures','mount_geometry','mount_textures'):
 found=re.findall(r'\b'+key+r'=(\d+)',terrain)
 if found:assert found[-1]=='0',(key,found[-1])
assert (r/'static-object-adapter.log').read_text().strip().endswith('live_objects=0')
assert (r/'renderer-failure.log').read_text().strip()=='Renderer failure diagnostics enabled'
result=dict(status='PASS',exit=e,completed=events[-1]['stages'],zero_keys=zero_keys)
(r/'fast-gate.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
