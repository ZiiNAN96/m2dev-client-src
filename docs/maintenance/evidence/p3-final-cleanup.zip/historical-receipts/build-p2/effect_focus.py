from pathlib import Path
r=Path(__file__).resolve().parent.parent;d=r/'build-p2/effect-focus-source';d.mkdir(exist_ok=True)
for rel in ['src/Renderer/DiligentEffectRenderer.cpp','src/EffectLib/EffectRenderBridge.cpp']:
 p=r/rel;(d/p.name).write_bytes(p.read_bytes());s=p.read_text(encoding='utf-8')
 if p.name=='DiligentEffectRenderer.cpp':
  s=s.replace('        auto& p=s.pipelines[key];','''        auto& p=s.pipelines[key];const bool p2First=!p.state;
        struct P2Focus {const char* name;bool active;P1::Clock::time_point start;P2Focus(const char* n,bool a):name(n),active(a&&P1::capturing){if(active)start=P1::Clock::now();}~P2Focus(){if(active)P1::DetailEvent("effect-first-draw",name,P1::Ms(P1::Clock::now()-start));}};
        P2Focus p2Total("total draw",p2First);''')
  s=s.replace('{ P1::Add(P1::Uploads);P1::Add(P1::VertexUpdates);','{ P2Focus timing("vertex map and upload",p2First);P1::Add(P1::Uploads);P1::Add(P1::VertexUpdates);')
  s=s.replace('            P1::Add(P1::Uploads);P1::Add(P1::ConstantUpdates);','            P2Focus timing("constant map and upload",p2First);P1::Add(P1::Uploads);P1::Add(P1::ConstantUpdates);')
  for call,label in [('b.context->SetPipelineState(p.state);','bind pipeline'),('b.context->CommitShaderResources(p.bindings,RESOURCE_STATE_TRANSITION_MODE_TRANSITION);','commit resources'),('b.context->Draw(DrawAttribs{count,DRAW_FLAG_VERIFY_ALL});','driver draw')]:
   assert call in s;s=s.replace(call,'{P2Focus timing("'+label+'",p2First);'+call+'}')
 else:
  s=s.replace('    if(!diagnostics.is_open()) diagnostics.open','    const auto p2ReportStart=P1::Clock::now();\n    if(!diagnostics.is_open()) diagnostics.open')
  s=s.replace('<< key << std::endl;','<< key << std::endl;\n    P1::DetailEvent("effect-diagnostic-write",key,P1::Ms(P1::Clock::now()-p2ReportStart));')
 p.write_text(s,encoding='utf-8',newline='\r\n')
print('Isolated first-use probe instrumentation ready; compile only after baseline has exited')
