@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p2\vs-test-run.log
if errorlevel 1 exit /b 1
ctest --test-dir build-h2x/msvc -C Release -R "^(AssetRuntime.EmbeddedMaterial|Graphics.DiligentFXModern|Graphics.DiligentFXMaterials)$" --output-on-failure > build-p2\tests.log 2>&1
exit /b %errorlevel%
