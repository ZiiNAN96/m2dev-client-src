from pathlib import Path
from array import array
from collections import defaultdict,Counter
import csv,json,math,sys,statistics,heapq
r=Path(sys.argv[1])
def percentile(a,p):
 i=(len(a)-1)*p;lo=int(i);return a[lo]+(a[min(lo+1,len(a)-1)]-a[lo])*(i-lo)
def stats(a):
 if not a:return None
 a=sorted(a);return dict(avg=statistics.fmean(a),median=percentile(a,.5),p95=percentile(a,.95),p99=percentile(a,.99),maximum=a[-1],minimum=a[0])
events=[json.loads(x) for x in (r/'p1-run.log').read_text().splitlines()]
labels={e['stage']:e['name'] for e in events if e['event']=='prepare'}
summaries={};serialStage={};top=[];lastStage=None;clock=0;last=None;pending=None
for row in csv.DictReader((r/'p1-frames.csv').open()):
 row={k:float(v) for k,v in row.items()};stage=int(row['stage']);clock+=row['interval_ms']
 if stage<0:lastStage=None;last=None;pending=None;continue
 if lastStage!=stage:last=None;pending=None;lastStage=stage
 if pending is None:pending=defaultdict(float)
 for k,v in row.items():
  if k.startswith('cpu_') or k not in ('serial','stage','presented','interval_ms'):pending[k]+=v
 if not row['presented']:continue
 if last is None:last=clock;pending=None;continue
 if stage not in summaries:summaries[stage]=dict(frames=0,values=defaultdict(lambda:array('d')),sums=defaultdict(float),gpuSums=defaultdict(float),gpuCount=0,top=[])
 s=summaries[stage];s['frames']+=1;ft=clock-last;last=clock
 active=sum(v for k,v in pending.items() if k.startswith('cpu_') and k not in ('cpu_sleep','cpu_present'))
 for k,v in [('frametime',ft),('cpu_active',active),('thread_cpu',pending['thread_cpu_ms'])]:s['values'][k].append(v)
 for k,v in pending.items():s['sums'][k]+=v
 serial=int(row['serial']);serialStage[serial]=stage
 item=dict(serial=serial,scenario=labels[stage],frametime=ft,cpu_active=active,phases={k[4:]:v for k,v in pending.items() if k.startswith('cpu_')},counters={k:v for k,v in pending.items() if not k.startswith('cpu_')})
 s['top'].append(item);s['top']=sorted(s['top'],key=lambda x:-max(x['frametime'],x['cpu_active']))[:12]
 pending=None
for row in csv.DictReader((r/'p1-gpu.csv').open()):
 serial=int(row.pop('serial'));stage=serialStage.get(serial)
 if stage is None:continue
 s=summaries[stage];total=0
 for k,v in row.items():
  v=float(v);s['gpuSums'][k]+=v
  if k.startswith('gpu_'):total+=v
 s['values']['gpu'].append(total);s['gpuCount']+=1
 for item in s['top']:
  if item['serial']==serial:item['gpu']=total
out={}
for i,s in summaries.items():
 n=s['frames'];gn=s['gpuCount'];sums=s['sums'];v=s['values']
 cpu={k[4:]:value/n for k,value in sums.items() if k.startswith('cpu_')}
 counters={k:value for k,value in sums.items() if not k.startswith('cpu_') and k not in ('wall_ms','thread_cpu_ms')}
 gpu={k[4:]:value/gn for k,value in s['gpuSums'].items() if k.startswith('gpu_')}
 metrics={k:value/gn for k,value in s['gpuSums'].items() if not k.startswith('gpu_')}
 counts={k:sum(v for key,v in metrics.items() if key.endswith('_'+suffix)) for k,suffix in [('draws','draws'),('indexed','indexed'),('pso_calls','pso_calls'),('srb_calls','srb_calls'),('maps','maps'),('triangles','triangles')]}
 start=next(e for e in events if e['event']=='start' and e['stage']==i);end=next(e for e in events if e['event']=='end' and e['stage']==i)
 summary=dict(frames=n,seconds=sum(v['frametime'])/1000,fps_avg=1000/statistics.fmean(v['frametime']),fps_median=1000/statistics.median(v['frametime']),cpu=cpu,gpu_phases=gpu,counts=counts,metrics=metrics,counter_totals=counters,counters_average={k:value/n for k,value in counters.items()},gpu_samples=gn,world_delta={k:end['world'][k]-value for k,value in start['world'].items()},world_start=start['world'],world_end=end['world'],vegetation_start=start['vegetation'],vegetation_end=end['vegetation'],game_seconds=end.get('game_seconds'),wall_seconds=end.get('wall_seconds'),top=s['top'])
 summary.update({k:stats(a) for k,a in v.items()});out[labels[i]]=summary
 print(labels[i], 'FPS',round(summary['fps_avg'],1),'FT',*[round(summary['frametime'][k],3) for k in ['median','p95','p99','maximum']], 'CPU',round(summary['cpu_active']['avg'],3),'GPU',round(summary['gpu']['avg'],3),'draws',round(counts['draws'],1),'samples',gn,'/',n,'clock ratio',round(end.get('game_seconds',0)/end.get('wall_seconds',1),5))
 print(' CPU',[(k,round(x,4)) for k,x in sorted(cpu.items(),key=lambda x:-x[1])[:8]])
 print(' events',{k:counters[k] for k in ('pack_read','texture_create','buffer_create','shader_compile','terrain_load','area_load','terrain_rebuild','instance_create','tree_actual','tree_repeat')})
(r/'summary.json').write_text(json.dumps(out,indent=2))
details=list(csv.DictReader((r/'p2-details.tsv').open(),delimiter='\t'))
reads=Counter((labels.get(int(x['stage']),'warmup'),x['name'],x['effect']) for x in details if x['kind']=='pack-read')
(r/'resources.json').write_text(json.dumps([dict(scenario=k[0],path=k[1],effect=k[2],reads=v) for k,v in reads.items()],indent=2))
print('Repeated traversal reads',[(k,v) for k,v in reads.items() if 'REPEAT' in k[0]])
slow=sorted(details,key=lambda x:-float(x['ms']))[:30]
(r/'slow-details.json').write_text(json.dumps(slow,indent=2));print('Slow operations',json.dumps(slow[:10],indent=2))
