from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent.parent;rel='src/GameLib/WeaponTrace.cpp';p=r/rel
b=r/'build-p2/original'/rel;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(p.read_bytes())
m=r/'build-p2/original-manifest.json';items=json.loads(m.read_text());items.append(dict(path=rel,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));m.write_text(json.dumps(items,indent=2))
s=p.read_text(encoding='utf-8');s='#include "Renderer/RuntimePerf.h"\n'+s
s=s.replace('float fElapsedTime = CTimer::Instance().GetCurrentSecond() - m_fLastUpdate;', 'if(P1::uncapped && CTimer::Instance().GetCurrentSecond()==m_fLastUpdate)return;\n    float fElapsedTime = CTimer::Instance().GetCurrentSecond() - m_fLastUpdate;')
p.write_text(s,encoding='utf-8',newline='\r\n')
