from pathlib import Path
p=Path(__file__).resolve().parent.parent/'src/Renderer/DiligentEffectRenderer.cpp'
s=p.read_text(encoding='utf-8')
s=s.replace('struct Counts { uint32_t textures=0; };','struct Counts { uint32_t textures=0,peakTextures=0;uint64_t bytes=0,peakBytes=0;bool effects=false; };')
s=s.replace('    std::shared_ptr<Counts> counts;','    std::shared_ptr<Counts> counts;\n    uint64_t residentBytes=0;')
s=s.replace('~Texture() override { if(counts) --counts->textures; }','~Texture() override { if(counts){--counts->textures;counts->bytes-=residentBytes;} }')
s=s.replace('texture->counts=s.counts; ++s.counts->textures; return texture;','''texture->counts=s.counts; ++s.counts->textures;
        for(const auto& mip:data.mips)texture->residentBytes+=mip.size;
        s.counts->bytes+=texture->residentBytes;s.counts->peakBytes=std::max(s.counts->peakBytes,s.counts->bytes);
        s.counts->peakTextures=std::max(s.counts->peakTextures,s.counts->textures);
        s.counts->effects|=!P1::effectAsset.empty();
        P1::DetailEvent("effect-texture-bytes","",0,texture->residentBytes);return texture;''')
s=s.replace('void DiligentEffectRenderer::Shutdown()\n{\n    auto& s=*m_impl;','''void DiligentEffectRenderer::Shutdown()
{
    auto& s=*m_impl;
    if(s.constants&&P1::enabled){std::ofstream log("p2-texture-memory.tsv",std::ios::app);log<<"effects="<<s.counts->effects<<" peakTextures="<<s.counts->peakTextures<<" peakPayloadBytes="<<s.counts->peakBytes<<" finalTextures="<<s.counts->textures<<" finalPayloadBytes="<<s.counts->bytes<<'\\n';}''')
p.write_text(s,encoding='utf-8',newline='\r\n')
