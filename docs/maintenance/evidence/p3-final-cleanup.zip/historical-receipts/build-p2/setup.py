from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent.parent
d=r/'build-p2'
manifest=[]
def save(rel):
 p=r/rel; b=d/'original'/rel;b.parent.mkdir(parents=True,exist_ok=True)
 if b.exists():assert b.read_bytes()==p.read_bytes(),rel
 else:shutil.copy2(p,b)
 manifest.append(dict(path=rel,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
def edit(rel,fn):
 p=r/rel;s=p.read_text(encoding='utf-8-sig');o=fn(s);assert o!=s,rel;p.write_text(o,encoding='utf-8',newline='\r\n')
old=json.loads((r/'build-p1/instrumented-files.json').read_text())
for i in old:
 p=r/i['path'];assert p.read_text(encoding='utf-8-sig')==(r/'build-p1/before'/i['path']).read_text(encoding='utf-8-sig'),i['path']
 save(i['path']);shutil.copy2(r/'build-p1/instrumentation'/i['path'],p)
for rel in ['src/EterBase/Timer.cpp','src/EterLib/StaticObjectTextureLoader.cpp','src/EffectLib/EffectRenderBridge.cpp','src/Renderer/FirstUseAudit.h']:
 save(rel)
(d/'original-manifest.json').write_text(json.dumps(manifest,indent=2))
for name in ['RuntimePerf.h','RuntimePerfGpu.h']:shutil.copy2(r/'build-p1/instrumentation'/name,r/'src/Renderer'/name)

extra=r'''
// Temporary P2 instrumentation, removed before the normal Release build.
inline const bool uncapped=[] {const auto* e=std::getenv("M2_P2_UNCAPPED");return e&&std::string_view(e)=="1";}();
inline std::string resourcePath,effectAsset;
struct Detail {uint64_t serial;int stage;std::string kind,name,resource,effect;double ms;uint64_t bytes;};
inline std::vector<Detail> details;
inline uint64_t detailsDropped{};
inline void DetailEvent(std::string_view kind,std::string_view name,double ms=0,uint64_t bytes=0){
 if(!capturing)return;
 if(details.size()>=100000){++detailsDropped;return;}
 details.push_back({current.serial,current.stage,std::string(kind),std::string(name),resourcePath,effectAsset,ms,bytes});
}
struct Context {
 std::string& slot;std::string previous;
 Context(std::string& s,const char* v):slot(s),previous(std::move(s)){slot=v?v:"";}
 ~Context(){slot=std::move(previous);}
};
struct DetailScope {
 std::string_view kind,name;Clock::time_point start;bool active;
 DetailScope(std::string_view k,std::string_view n,bool use=true):kind(k),name(n),active(capturing&&use){if(active)start=Clock::now();}
 ~DetailScope(){if(active){auto ms=Ms(Clock::now()-start);if(ms>=.15||kind=="GPU resources"||kind=="Shaders / PSOs"||kind=="texture-load")DetailEvent(kind,name,ms);}}
};
'''
edit('src/Renderer/RuntimePerf.h',lambda s:s.replace('#include <map>','#include <map>\n#include <cstdlib>\n#include <string>')
 .replace('inline void Event(',extra+'\ninline void Event(')
 .replace('std::string_view kind,uint64_t bytes){','std::string_view kind,uint64_t bytes,std::string_view name={}){')
 .replace('if(kind=="CreateBuffer")','if(kind=="pack-read"||kind=="CreateBuffer"||kind=="CreateTexture"||kind=="CreateGraphicsPipelineState"||kind=="shader-runtime-compile")DetailEvent(kind,name,0,bytes);\n    if(kind=="CreateBuffer")')
 .replace('std::ofstream meta("p1-meta.txt");','std::ofstream det("p2-details.tsv");det<<std::setprecision(12)<<"serial\\tstage\\tkind\\tname\\tresource\\teffect\\tms\\tbytes\\n";for(const auto& x:details)det<<x.serial<<\'\\t\'<<x.stage<<\'\\t\'<<x.kind<<\'\\t\'<<x.name<<\'\\t\'<<x.resource<<\'\\t\'<<x.effect<<\'\\t\'<<x.ms<<\'\\t\'<<x.bytes<<\'\\n\';\n    std::ofstream meta("p1-meta.txt");')
 .replace(' VSync=1 existing_frame_pacing_unchanged=1',' detailsDropped="<<detailsDropped<<" VSync="<<!uncapped<<" uncapped="<<uncapped<<" real_time_simulation=1'))
edit('src/UserInterface/PythonApplication.cpp',lambda s:s.replace('size()<30000','size()<400000')
 .replace('CTimer::Instance().UseCustomTime();','if(!P1::uncapped)CTimer::Instance().UseCustomTime();')
 .replace('if (dwCurrentTime > s_uiNextFrameTime)','if (!P1::uncapped && dwCurrentTime > s_uiNextFrameTime)')
 .replace('if (rest > 0 && !bCurrentLateUpdate )','if (!P1::uncapped && rest > 0 && !bCurrentLateUpdate )')
 .replace('TranslateSpecularMatrix(g_specularSpd, g_specularSpd, 0.0f);','TranslateSpecularMatrix(P1::uncapped?g_specularSpd*m_fGlobalElapsedTime/.0165f:g_specularSpd, P1::uncapped?g_specularSpd*m_fGlobalElapsedTime/.0165f:g_specularSpd, 0.0f);'))
edit('src/UserInterface/PythonApplicationModule.cpp',lambda s:s.replace('frames.reserve(30000);','frames.reserve(400000);P1::details.reserve(100000);'))
edit('src/Renderer/DiligentD3D11Backend.cpp',lambda s:s.replace('swapChain->Present(1);','swapChain->Present(P1::uncapped?0:1);'))
edit('src/Renderer/RuntimePerfGpu.h',lambda s:s.replace('if(!capturing)return;Collect();','if(!capturing)return;if(gpuResults.capacity()==0)gpuResults.reserve(400000);Collect();'))
edit('src/EterBase/MapLoadTrace.h',lambda s:s.replace('P1::Event(kind,bytes);','P1::Event(kind,bytes,name);')
 .replace('P1::Scope perf_;','P1::Scope perf_;\n    P1::DetailScope detail_;')
 .replace('|| kind=="shader-compilation"))','|| kind=="shader-compilation")),detail_(phase,name,enabled)'))
edit('src/EterLib/StaticObjectTextureLoader.cpp',lambda s:'#include "Renderer/RuntimePerf.h"\n'+s.replace('    TPackFile file;','    P1::Context resource(P1::resourcePath,filename);P1::DetailScope timing("texture-load",filename?filename:"");\n    TPackFile file;'))
edit('src/EffectLib/EffectRenderBridge.cpp',lambda s:'#include "Renderer/RuntimePerf.h"\n'+s.replace('    if(!Active() || !primitives) return;','    if(!Active() || !primitives) return;\n    P1::Context effectContext(P1::effectAsset,asset);P1::DetailScope effectTiming("effect-submit",asset?asset:"trail");'))
# First-use diagnostics are buffered during capture, so disk logging does not create a fake burst.
edit('src/Renderer/FirstUseAudit.h',lambda s:'#include "RuntimePerf.h"\n'+s.replace('            std::ofstream log("gdxc-first-use.log",std::ios::app);','            if(P1::capturing){P1::DetailEvent(category_,name_,elapsed);return;}\n            std::ofstream log("gdxc-first-use.log",std::ios::app);'))
for name in ['prepare.ps1','run.ps1','gate.py']:
 s=(r/'build-p1'/name).read_text();
 if name=='run.ps1':s=s.replace('$started=Get-Date','$env:M2_P2_UNCAPPED="1"\n$started=Get-Date')
 (d/name).write_text(s)
s=(r/'build-p1/entry.py').read_text().replace('P1 isolated runtime baseline','P2 isolated uncapped profiling')
s=s.replace("settings=settings,origin=self.origin)","settings=settings,origin=self.origin)")
s=s.replace("self.measure_start=now;emit(","self.measure_start=now;self.game_start=app.GetTime();emit(")
s=s.replace("name=STAGES[self.index][0],world=", "name=STAGES[self.index][0],game_seconds=app.GetTime()-getattr(self,'game_start',app.GetTime()),wall_seconds=time.monotonic()-(self.measure_start or time.monotonic()),world=")
(d/'entry.py').write_text(s)
(d/'build.cmd').write_text((r/'build-p1/build.cmd').read_text().replace('build-p1','build-p2'))
# Hash protected production files from the known P1 inventory, freshly at P2 start.
protected=json.loads((r/'build-p1/protected-before.json').read_text(encoding='utf-8-sig'))
for i in protected:i['sha256']=hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()
(d/'protected-before.json').write_text(json.dumps(protected,indent=2))
print('P2 temporary instrumentation ready; production inventory',len(protected))
