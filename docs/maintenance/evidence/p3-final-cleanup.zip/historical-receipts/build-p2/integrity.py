from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent.parent;d=r/'build-p2'
before=json.loads((d/'protected-before.json').read_text())
changed=[i['path'] for i in before if Path(i['path']).suffix!='.log' and hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()!=i['sha256']]
log_changes=[i['path'] for i in before if Path(i['path']).suffix=='.log' and hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()!=i['sha256']]
result=dict(protected_files=sum(Path(i['path']).suffix!='.log' for i in before),changed=changed,generated_log_changes=log_changes,source_branch=subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip())
if len(sys.argv)>1:
 client=d/sys.argv[1];original=r.parent/'m2dev-client/assets/root';private=client/'test-root/root'
 original_files={p.relative_to(original).as_posix():p for p in original.rglob('*') if p.is_file()}
 private_files={p.relative_to(private).as_posix():p for p in private.rglob('*') if p.is_file()}
 assert original_files.keys()==private_files.keys()
 root_changed=[k for k,p in original_files.items() if p.read_bytes()!=private_files[k].read_bytes()]
 result.update(root_files=len(original_files),root_changed=root_changed,exe_sha256=hashlib.sha256((client/'Metin2_Release.exe').read_bytes()).hexdigest())
 assert root_changed==['prototype.py']
assert not changed,result
(d/'integrity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
