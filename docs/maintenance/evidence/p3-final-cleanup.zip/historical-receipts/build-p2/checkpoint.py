from pathlib import Path
import sys,shutil,hashlib,json,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'build-p2';name=sys.argv[1];dest=d/'checkpoints'/name
assert not dest.exists()
paths=set(x['path'] for x in json.loads((d/'original-manifest.json').read_text()))
paths.update(subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines())
manifest=[]
for path in sorted(paths):
 p=r/path
 if not p.is_file():continue
 out=dest/path;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
 manifest.append(dict(path=path,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
(dest/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
print(name,len(manifest),'files archived')
