from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent.parent
manifest=json.loads((r/'build-p2/original-manifest.json').read_text(encoding='utf-8'))
for item in manifest:
 rel=item['path'];original=r/'build-p2/original'/rel
 assert hashlib.sha256(original.read_bytes()).hexdigest()==item['sha256'],rel
 production=r/'build-p2/production'/rel
 shutil.copyfile(production if production.exists() else original,r/rel)
for name in ['RuntimePerf.h','RuntimePerfGpu.h']:
 p=r/'src/Renderer'/name
 assert p.is_file() and (r/'build-p2/checkpoints/before/src/Renderer'/name).is_file()
 p.unlink()
print('Original production timing/logging restored; only three intended optimizations retained')
