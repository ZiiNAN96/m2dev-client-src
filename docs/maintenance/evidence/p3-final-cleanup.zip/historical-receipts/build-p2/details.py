from pathlib import Path
import csv,json,sys
r=Path(sys.argv[1]);rows=list(csv.DictReader((r/'p2-details.tsv').open(encoding='utf-8'),delimiter='\t'))
slow=sorted((x for x in rows if int(x['stage'])>=0 and x['kind']=='effect-submit'),key=lambda x:-float(x['ms']))[:5]
serials={x['serial'] for x in slow}
focus=[x for x in rows if x['serial'] in serials]
(r/'effect-analysis.json').write_text(json.dumps(dict(slow=slow,details=focus),indent=2),encoding='utf-8')
print(json.dumps(dict(slow=slow,details=[x for x in focus if float(x['ms'])>=.05]),indent=2))
