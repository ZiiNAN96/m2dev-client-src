from pathlib import Path
import json,os
r=Path(__file__).resolve().parent.parent
def edit(rel,fn):
 p=r/rel;s=p.read_text(encoding='utf-8');out=fn(s);assert out!=s,rel;p.write_text(out,encoding='utf-8',newline='\r\n')
def app(s):
 s=s.replace('if(!P1::uncapped)CTimer::Instance().UseCustomTime();','CTimer::Instance().UseCustomTime();')
 s=s.replace('CTimer& rkTimer=CTimer::Instance();\n\trkTimer.Advance();', '''CTimer& rkTimer=CTimer::Instance();
    static UINT p2NextUpdate=ELTimer_GetMSec();
    const bool p2Update=!P1::uncapped || static_cast<int>(dwStart-p2NextUpdate)>=0;
    UINT uiFrameTime=rkTimer.GetElapsedMilliecond();
    DWORD updatestart=ELTimer_GetMSec();
    if(p2Update) {
    P1::Add(P1::GameTicks);
    rkTimer.Advance();''')
 s=s.replace('UINT uiFrameTime = rkTimer.GetElapsedMilliecond();','uiFrameTime = rkTimer.GetElapsedMilliecond();\n    if(static_cast<int>(dwStart-p2NextUpdate)>500)p2NextUpdate=dwStart;\n    p2NextUpdate+=uiFrameTime;')
 s=s.replace('DWORD updatestart = ELTimer_GetMSec();','updatestart = ELTimer_GetMSec();')
 s=s.replace('    stallUpdate.Stop();','    stallUpdate.Stop();\n    }')
 s=s.replace('CGrannyMaterial::TranslateSpecularMatrix(P1::uncapped?g_specularSpd*m_fGlobalElapsedTime/.0165f:g_specularSpd, P1::uncapped?g_specularSpd*m_fGlobalElapsedTime/.0165f:g_specularSpd, 0.0f);','if(p2Update)CGrannyMaterial::TranslateSpecularMatrix(g_specularSpd,g_specularSpd,0.0f);')
 return s
edit('src/UserInterface/PythonApplication.cpp',app)
edit('src/Renderer/RuntimePerf.h',lambda s:s.replace('InstanceGrowth,CounterCount','InstanceGrowth,GameTicks,CounterCount').replace('"instance_growth"};','"instance_growth","game_ticks"};').replace('active(capturing&&use){if(active)start=Clock::now();','active(capturing&&use&&(k=="GPU resources"||k=="Shaders / PSOs"||k=="texture-load"||k=="effect-submit"||k=="File access")){if(active)start=Clock::now();').replace('real_time_simulation=1','legacy_fixed_simulation_ticks=1'))
# Exclude verbose per-120-frame file logging during the timed capture, preserving shutdown audits.
rel='src/Renderer/TerrainPresentation.cpp';p=r/rel;b=r/'build-p2/original'/rel;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(p.read_bytes())
m=r/'build-p2/original-manifest.json';items=json.loads(m.read_text());import hashlib
items.append(dict(path=rel,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));m.write_text(json.dumps(items,indent=2))
edit(rel,lambda s:'#include "RuntimePerf.h"\n'+s.replace('if (m_diagnostics && (++m_frame','if (!P1::capturing && m_diagnostics && (++m_frame'))
# Copied P1 sources retain old timestamps; force this exact instrumentation tree to compile.
for item in items:os.utime(r/item['path'],None)
for name in ['RuntimePerf.h','RuntimePerfGpu.h']:os.utime(r/'src/Renderer'/name,None)
print('Fixed simulation tick preserved, detail capture bounded, all instrumented translation units touched')
