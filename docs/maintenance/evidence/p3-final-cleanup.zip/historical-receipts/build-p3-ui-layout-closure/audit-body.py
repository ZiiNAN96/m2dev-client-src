# Appended to the existing native RealGame fixture. No test window coordinates
# replace the product's default Open/Show rules.
import net, uiCommon
world = RealGame(None)
sendEnter = net.SendEnterGamePacket
try:
    net.SendEnterGamePacket = lambda: None
    world.Open()
finally:
    net.SendEnterGamePacket = sendEnter
world.RefreshStatus()
app.SetCamera(5500.0, 22.0, 0.0, 0.0)
interface = world.interface
interface.dlgSystem._SystemDialog__ClickSystemOptionButton()
options = interface.dlgSystem.systemOptionDlg
options.OpenGraphics()
dialog = options.graphicsDialog
mode = 'baseline'
if os.path.exists('closure-case.txt'):
    with builtins.old_open('closure-case.txt') as stream:
        mode = stream.read().strip()

def open_windows():
    interface.OpenCharacterWindowWithState('STATUS')
    if not interface.wndInventory.IsShow():
        interface.ToggleInventoryWindow()
    if interface.wndInventory.wndBelt:
        interface.wndInventory.wndBelt.OpenInventory()
    if not interface.wndInventory.wndCostume:
        interface.wndInventory._InventoryWindow__CostumeButton_Click()
    else:
        interface.wndInventory.wndCostume.Show()
    interface.wndMessenger.Show()
    interface.wndGuild.Open()
    interface.dlgShop.Open(57900)
    interface.OpenSafeboxWindow(3)
    interface.OpenMallWindow(3)
    options.Show()
    dialog.Open()

def panels():
    values = {name: getattr(interface, name) for name in ('wndInventory', 'wndCharacter',
        'wndMessenger', 'wndGuild', 'dlgShop', 'wndSafebox', 'wndMall', 'wndTaskBar',
        'wndMiniMap', 'wndChat', 'wndGameButton', 'wndEnergyBar')}
    values.update(options=options, graphics=dialog, belt=interface.wndInventory.wndBelt,
                  costume=interface.wndInventory.wndCostume, chatSizing=interface.wndChat.btnChatSizing)
    return {name: value for name, value in values.items() if value}

def snapshot(label):
    controls = {}
    for name, window in panels().items():
        controls[name] = dict(local=window.GetLocalPosition(), globalPos=window.GetGlobalPosition(),
                              size=(window.GetWidth(), window.GetHeight()), visible=bool(window.IsShow()))
    inv = interface.wndInventory
    for name in ('board', 'TitleBar', 'Equipment_Base', 'EquipmentSlot', 'ItemSlot', 'Money', 'Money_Slot'):
        if name in inv.ElementDictionary:
            window = inv.GetChild(name)
            controls['inventory.' + name] = dict(local=window.GetLocalPosition(), globalPos=window.GetGlobalPosition(),
                                                size=(window.GetWidth(), window.GetHeight()), visible=bool(window.IsShow()))
    emit('layout', label=label, viewport=(wndMgr.GetScreenWidth(), wndMgr.GetScreenHeight()),
         native=systemSetting.GetDisplayOptions(), controls=controls)
    return controls

class Probe(ui.Window):
    def __init__(self):
        ui.Window.__init__(self, 'TOP_MOST')
        self.done = False
        self.shot = None
        self.steps = self.matrix()
        self.deadline = time.monotonic() + 1
        self.Show()

    def matrix(self):
        open_windows()
        interface.wndChat.OpenChat()
        yield 0.5
        snapshot('initial-open-1024')
        self.shot = 'initial-defaults'
        yield 0.2
        for window in tuple(panels().values()):
            if window not in (interface.wndTaskBar, interface.wndMiniMap, interface.wndChat,
                              interface.wndGameButton, interface.wndEnergyBar, interface.wndChat.btnChatSizing):
                window.Hide()
        dialog.ApplyDisplay(dict(displayMode=1, resolutionWidth=2560, resolutionHeight=1440))
        yield 0.7
        systemSetting.ConfirmDisplaySettings()
        open_windows()
        yield 0.5
        snapshot('closed-resize-open-2560')
        self.shot = 'closed-resize-open'
        yield 0.2
        dialog.ApplyDisplay(dict(displayMode=0, resolutionWidth=1920, resolutionHeight=1080))
        yield 0.7
        dialog.ConfirmDisplay()
        snapshot('open-resize-1920')
        self.shot = 'open-resize'
        yield 0.2
        emit('completed', mode=mode)
        self.done = True
        app.Exit()

    def OnUpdate(self):
        if self.done or time.monotonic() < self.deadline:
            return
        try:
            self.deadline = time.monotonic() + next(self.steps)
        except StopIteration:
            pass
        except Exception:
            with builtins.old_open('closure-failure.log', 'w') as stream:
                stream.write(traceback.format_exc())
            self.done = True
            app.Exit()

    def OnRender(self):
        if self.shot:
            ok, path = grp.SaveScreenShotToPath(self.shot + '-')
            emit('screenshot', ok=ok, path=path)
            self.shot = None

probe = Probe()
app.Loop()
probe.Hide()
world.Close()
log.close()
