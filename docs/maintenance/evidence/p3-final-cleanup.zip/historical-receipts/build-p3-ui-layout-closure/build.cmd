@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p3-ui-layout-closure\vs.log 2>&1
if errorlevel 1 exit /b 1
cmake --build build-h2x/msvc --config Release --target UserInterface FramePacingTest GraphicsSettingsTest DisplayConfigurationTest --parallel 6 > build-p3-ui-layout-closure\build-release.log 2>&1
exit /b %errorlevel%
