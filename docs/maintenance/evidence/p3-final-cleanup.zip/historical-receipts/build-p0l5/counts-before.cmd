@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l5\counts-vs.log
cl /nologo /std:c++20 /O2 /EHsc /MT /I src tests\Loading\gr2_corpus_counts.cpp /Fe:build-p0l5\counts-before.exe /Fo:build-p0l5\counts.obj build-h2x\msvc\src\AssetRuntime\Release\AssetRuntimeGR2.lib build-h2x\msvc\src\AssetRuntime\Release\AssetRuntime.lib build-h2x\msvc\src\AnimationRuntime\Release\AnimationRuntime.lib > build-p0l5\counts-build.log 2>&1
if errorlevel 1 exit /b 1
build-p0l5\counts-before.exe build-p0l5\decoder-files.txt > build-p0l5\counts-before.tsv
exit /b %errorlevel%
