from pathlib import Path
def edit(path, old, new, count=1):
    p=Path(path); s=p.read_text(encoding='utf-8'); assert old in s,(path,old)
    p.write_text(s.replace(old,new,count),encoding='utf-8')
def scope(path, signature, name):
    edit(path,signature,signature+'\n    MapLoadTrace::Scope gr2Detail("Assets","'+name+'");')
edit('src/EterLib/Resource.cpp','void CResource::Load()\n{','void CResource::Load()\n{\n    MapLoadTrace::GR2Context gr2Context(GetFileName());')
edit('src/EterLib/ResourceManager.cpp','    MapLoadTrace::Scope p0lScope("Assets","shared resource lookup","cpu");','    MapLoadTrace::GR2Context gr2Context(c_szFileName?c_szFileName:"");\n    MapLoadTrace::Count("gr2-request",MapLoadTrace::state.gr2Path);\n    MapLoadTrace::Scope p0lScope("Assets","shared resource lookup","cpu");')
edit('src/EterLib/ResourceManager.cpp','\tif (pResource)\t//','    if(!MapLoadTrace::state.gr2Path.empty())MapLoadTrace::Count(pResource?"gr2-lookup-hit":"gr2-lookup-miss",MapLoadTrace::state.gr2Path);\n\tif (pResource)\t//')
edit('src/EterLib/ResourceManager.cpp','    MapLoadTrace::Count("gr2-request",MapLoadTrace::state.gr2Path);','    if(!MapLoadTrace::state.gr2Path.empty())MapLoadTrace::Count("gr2-request",MapLoadTrace::state.gr2Path);')
base='src/AssetRuntime/GR2/'
scope(base+'GR2File.cpp','Ref File::Pointer(Ref ref) const\n{','unused')
edit(base+'GR2File.cpp','    MapLoadTrace::Scope gr2Detail("Assets","unused");','    MapLoadTrace::GR2ReferenceScope gr2Reference;')
edit(base+'GR2File.cpp','    for (const auto& section : header.sections) sections_.push_back(Decompress(section, bytes.subspan(section.offset, section.compressed)));','''    for (std::size_t i=0;i<header.sections.size();++i) {
        const auto& section=header.sections[i];
        MapLoadTrace::Count("gr2-section-compressed",MapLoadTrace::state.gr2Path+"|"+std::to_string(i),section.compressed);
        MapLoadTrace::Count("gr2-section-expanded",MapLoadTrace::state.gr2Path+"|"+std::to_string(i),section.expanded);
        MapLoadTrace::Scope sectionTrace("Assets","GR2 section "+std::to_string(i));
        sections_.push_back(Decompress(section,bytes.subspan(section.offset,section.compressed)));
    }''')
edit(base+'GR2Compression.cpp','    Window low(lowMaximum-1,lowMaximum), high(highMaximum-1,highCount+1);','    MapLoadTrace::Scope setupTrace("Assets","GR2 decoder model setup");\n    Window low(lowMaximum-1,lowMaximum), high(highMaximum-1,highCount+1);')
edit(base+'GR2Compression.cpp','    const auto start=position;','    setupTrace.Stop();\n    MapLoadTrace::Scope loopTrace("Assets","GR2 decoder loop");\n    const auto start=position;')
edit(base+'GR2Compression.cpp','    std::vector<std::byte> result(section.expanded);','    MapLoadTrace::Scope allocateTrace("Assets","GR2 output allocation");\n    std::vector<std::byte> result(section.expanded);\n    allocateTrace.Stop();')
edit(base+'GR2MaterialReader.cpp','#include "GR2Reader.h"','#include "GR2Reader.h"\n#include "EterBase/MapLoadTrace.h"')
scope(base+'GR2MaterialReader.cpp','MaterialAsset ReadMaterial(Types& t,Object source)\n{','GR2 materials')
edit(base+'GR2MeshReader.cpp','    data.vertices.reserve(vertices.size());','    MapLoadTrace::Scope vertexTrace("Assets","GR2 vertex processing");\n    data.vertices.reserve(vertices.size());')
edit(base+'GR2MeshReader.cpp','    const auto topology=t.Child(source,"PrimaryTopology");','    vertexTrace.Stop();\n    MapLoadTrace::Scope indexTrace("Assets","GR2 index processing");\n    const auto topology=t.Child(source,"PrimaryTopology");')
edit(base+'GR2MeshReader.cpp','    for(auto group:t.Array(topology,"Groups")) {','    indexTrace.Stop();\n    for(auto group:t.Array(topology,"Groups")) {')
edit(base+'GR2ModelReader.cpp','            std::vector<AnimationRuntime::SkeletonBone> bones;','            MapLoadTrace::Scope runtimeTrace("Assets","GR2 runtime skeleton");\n            std::vector<AnimationRuntime::SkeletonBone> bones;')
edit(base+'GR2ModelReader.cpp','    return result;\n}\n}', '''    MapLoadTrace::Count("gr2-models",MapLoadTrace::state.gr2Path,result.models.size());
    MapLoadTrace::Count("gr2-animations",MapLoadTrace::state.gr2Path,result.animations.size());
    for(const auto& model:result.models) {
        MapLoadTrace::Count("gr2-meshes",MapLoadTrace::state.gr2Path,model.meshes.size());
        if(model.skeleton)MapLoadTrace::Count("gr2-skeletons",MapLoadTrace::state.gr2Path,model.skeleton->bones.size());
    }
    return result;
}
}''')
edit(base+'GR2AssetProvider.cpp','            return {AssetHandle(std::make_shared<Document>', '            MapLoadTrace::Scope convertTrace("Assets","GR2 document conversion");\n            return {AssetHandle(std::make_shared<Document>')
edit(base+'GR2AssetProvider.cpp','        if(index>=clips_.size() || boundary>3)', '        MapLoadTrace::GR2Context gr2Context(Id());\n        MapLoadTrace::Scope preparationTrace("Assets","GR2 animation preparation");\n        if(index>=clips_.size() || boundary>3)')
for name in ('CopyVertices','CopyIndices'):
    s=Path(base+'GR2AssetProvider.cpp').read_text(); at=s.index('    AssetError '+name); start=s.index('    {',at)+5
    Path(base+'GR2AssetProvider.cpp').write_text(s[:start]+'\n        MapLoadTrace::Scope copyTrace("Assets","GR2 '+name+'");\n        MapLoadTrace::Count("gr2-'+name+'",Id(),destination.size());'+s[start:])
edit('src/EterGrnLib/Model.cpp','#include "StdAfx.h"','#include "StdAfx.h"\n#include "EterBase/MapLoadTrace.h"')
for signature in ('bool CGrannyModel::LoadPNTVertices()\n{','bool CGrannyModel::LoadIndices()\n{','bool CGrannyModel::CaptureStaticObjectSource()\n{','bool CGrannyModel::CaptureActorSource(bool attachment)\n{'):
    scope('src/EterGrnLib/Model.cpp',signature,'GR2 GPU preparation')
