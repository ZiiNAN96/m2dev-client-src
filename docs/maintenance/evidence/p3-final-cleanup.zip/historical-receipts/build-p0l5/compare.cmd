@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l5\compare-vs.log
cl /nologo /std:c++20 /O2 /EHsc /I src /I build-p0l5/reference tests\Loading\gr2_decoder_parity.cpp /Fe:build-p0l5\decoder_parity.exe /Fo:build-p0l5\decoder_parity.obj > build-p0l5\compare-build.log 2>&1
if errorlevel 1 exit /b 1
build-p0l5\decoder_parity.exe build-p0l5\decoder-files.txt > build-p0l5\decoder-parity.txt
exit /b %errorlevel%
