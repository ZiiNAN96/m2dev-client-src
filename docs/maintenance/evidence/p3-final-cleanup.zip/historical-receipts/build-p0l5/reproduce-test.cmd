@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l5\reproduce-vs.log
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\Loading\run_gr2_decoder_parity.ps1 -CorpusList build-p0l5\decoder-files.txt -OutputDirectory build-p0l5\reproduced-parity -Baseline 5563d78 > build-p0l5\reproduced-parity.log 2>&1
if errorlevel 1 exit /b 1
dumpbin /imports build-h2x\msvc\bin\Release\Metin2_Release.exe > build-p0l5\imports.txt
exit /b %errorlevel%
