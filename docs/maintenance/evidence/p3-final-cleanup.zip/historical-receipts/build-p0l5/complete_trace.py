from pathlib import Path
def edit(path,old,new):
    p=Path(path);s=p.read_text();assert old in s,(path,old);p.write_text(s.replace(old,new,1))
p='src/EterLib/ResourceManager.cpp'
line='    if(!MapLoadTrace::state.gr2Path.empty())MapLoadTrace::Count(pResource?"gr2-lookup-hit":"gr2-lookup-miss",MapLoadTrace::state.gr2Path);\n'
edit(p,line,'')
s=Path(p).read_text();at=s.index('CResource * CResourceManager::GetResourcePointer(');needle='\tCResource * pResource = FindResourcePointer(dwFileCRC);';pos=s.index(needle,at)+len(needle)
Path(p).write_text(s[:pos]+'\n'+line+s[pos:])
for path in ('src/GameLib/StaticObjectBridge.cpp','src/GameLib/ActorRenderBridge.cpp','src/EterGrnLib/ModelInstanceUpdate.cpp'):
    s=Path(path).read_text()
    Path(path).write_text('#include "EterBase/MapLoadTrace.h"\n'+s)
edit('src/GameLib/StaticObjectBridge.cpp','        if(!resource.geometry) {','        if(!resource.geometry) {\n            MapLoadTrace::GR2Context gr2Context(model->GetAssetHandle().GetDocument()->Id());\n            MapLoadTrace::Scope gr2Upload("Assets","GR2 GPU submission");')
edit('src/EterGrnLib/ModelInstanceUpdate.cpp','    if(reference && Renderer::startupSkinningMode==Renderer::PrototypeSkinningMode::GPUPrototype) {','    if(reference && Renderer::startupSkinningMode==Renderer::PrototypeSkinningMode::GPUPrototype) {\n        MapLoadTrace::GR2Context gr2Context(m_pModel->GetAssetHandle().GetDocument()->Id());\n        MapLoadTrace::Scope gr2Upload("Assets","GR2 GPU submission");')
for path,expr in [('src/GameLib/ActorRenderBridge.cpp','*source,part,category'),('src/GameLib/ActorRenderBridge.cpp','*source,part,parts.category'),('src/GameLib/StaticObjectBridge.cpp','*source,ActorPart::Body,ActorCategory::Special')]:
    edit(path,'if(!data.geometry) data.geometry=actorRenderer->CreateGeometry('+expr+');','''if(!data.geometry) {
        MapLoadTrace::GR2Context gr2Context(instance->GetModel()->GetAssetHandle().GetDocument()->Id());
        MapLoadTrace::Scope gr2Upload("Assets","GR2 GPU submission");
        data.geometry=actorRenderer->CreateGeometry('''+expr+''');
    }''')
# Save the final optimization; use the old search for the corrected baseline.
p=Path('src/AssetRuntime/GR2/GR2Compression.cpp');s=p.read_text()
Path('build-p0l5/final-compression.cpp').write_text(s)
p.write_text(s.replace('const auto upper=SymbolUpperBound(first,last,value);','const auto upper=std::upper_bound(first,last,value);'))
