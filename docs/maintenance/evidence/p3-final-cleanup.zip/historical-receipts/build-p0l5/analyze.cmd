@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p0l5\analyze-vs.log
cl /nologo /std:c++20 /O2 /EHsc /I src build-p0l5\analyze_decoder.cpp /Fe:build-p0l5\analyze_decoder.exe /Fo:build-p0l5\analyze_decoder.obj > build-p0l5\analyze-build.log 2>&1
if errorlevel 1 exit /b 1
build-p0l5\analyze_decoder.exe build-p0l5\decoder-files.txt > build-p0l5\decoder-analysis.txt
exit /b %errorlevel%
