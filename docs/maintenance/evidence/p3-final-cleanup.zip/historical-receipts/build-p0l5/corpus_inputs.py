import json,struct,zlib
from pathlib import Path
loads=json.loads(Path('build-p0l/l5-before/gr2-pipeline.json').read_text())
wanted={}
for load in loads:
    for a in load['assets']:
        if a['sections']:
            events={e['kind']:e for e in a['events']}
            wanted[a['path']]=(a['file_bytes'],events['gr2-payload-crc']['bytes'])
paths=[];manifest=[]
for line in Path('build-p0l/decoder-files.txt').read_text().splitlines():
    p=Path(line);norm=line.lower().replace('\\','/');key='d:/'+norm[norm.index('ymir work/'):]
    if key not in wanted:continue
    size,crc=wanted[key];data=p.read_bytes()
    assert len(data)==size and struct.unpack_from('<I',data,40)[0]==crc and zlib.crc32(data[32+struct.unpack_from('<I',data,44)[0]:])==crc,key
    manifest.append(dict(path=key,local=str(p),bytes=size,crc=crc))
    paths.append(str(p));del wanted[key]
assert not wanted,wanted
Path('build-p0l5/decoder-files.txt').write_text('\n'.join(paths)+'\n')
Path('build-p0l5/corpus-inputs.json').write_text(json.dumps(manifest,indent=2))
print('Current measured corpus:',len(paths),'all file sizes and validated payload CRCs match production pack reads')
