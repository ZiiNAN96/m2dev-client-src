$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$evidence=$PSScriptRoot
$audit="$source/build-h2x/msvc/tests/AssetRuntime/Release/PackContentAudit.exe"
$maker="$source/build-h2x/msvc/bin/Release/PackMaker.exe"
if(Test-Path "$evidence/backup"){throw 'Fresh backup required'}
if(@(Get-Process -Name 'Metin2*' -ErrorAction SilentlyContinue).Count){throw 'Another client is running'}
New-Item -ItemType Directory -Path "$evidence/backup/pack","$evidence/smoke-pack","$evidence/smoke-source","$evidence/views","$evidence/shader-cache" | Out-Null
$tracked=@{}
foreach($repo in @($source,$runtime)){
 $tracked[$repo]=@{branch=(& git -C $repo branch --show-current);head=(& git -C $repo rev-parse HEAD);status=@(& git -C $repo status --porcelain=v1)}
 if($tracked[$repo].status.Count){throw "Dirty repository: $repo"}
}
if($tracked[$source].head -ne '4b2477db3e2653279a49ba86f0684b987e05d8b7'){throw 'Unexpected source commit'}
$tracked | ConvertTo-Json -Depth 5 | Set-Content "$evidence/git-before.json"
$before=@()
foreach($relative in @('Metin2_Release.exe','pack/root.pck')){
 $file=Get-Item -LiteralPath (Join-Path $runtime $relative)
 $destination=Join-Path "$evidence/backup" $relative
 Copy-Item -LiteralPath $file.FullName -Destination $destination
 $hash=(Get-FileHash -LiteralPath $file.FullName).Hash
 if((Get-FileHash -LiteralPath $destination).Hash -ne $hash){throw "Backup mismatch: $relative"}
 $before+=@{path=$relative;sha256=$hash;bytes=$file.Length;purpose=$(if($relative -eq 'pack/root.pck'){'Temporary smoke entry only; restore exactly'}else{'P2 Release deployment'})}
}
$before | ConvertTo-Json -Depth 4 | Set-Content "$evidence/backup-manifest.json"
$protected=@(Get-ChildItem -LiteralPath "$runtime/pack","$runtime/config","$runtime/assets/root","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)+@(Get-ChildItem -LiteralPath $runtime -File)
$protected | ForEach-Object {@{path=[IO.Path]::GetRelativePath($runtime,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json -Depth 4 | Set-Content "$evidence/protected-before.json"
Copy-Item -LiteralPath "$runtime/assets/root" -Destination "$evidence/smoke-source/root" -Recurse
# Reuse the preserved input of the byte-identical installed P0-L package.
# Current loose checkout has CRLF-only differences; never introduce those into this EXE-only deployment.
if((Get-FileHash "$runtime/pack/root.pck").Hash -ne (Get-FileHash "$source/build-p0l-final-production/production-pack/root.pck").Hash){throw 'Preserved production package is not the installed package'}
Get-ChildItem -LiteralPath "$source/build-p0l-final-production/smoke-source/root" | Copy-Item -Destination "$evidence/smoke-source/root" -Recurse -Force
Copy-Item -LiteralPath "$runtime/assets/root/prototype.py" -Destination "$evidence/smoke-source/root/prototype.py" -Force
& $audit source "$runtime/pack/root.pck" "$evidence/smoke-source/root" "$evidence/normal-staging-source.tsv" > "$evidence/normal-staging-source.log"
if($LASTEXITCODE -ne 0){throw 'Installed package contents must match before the smoke entry replacement'}
Copy-Item -LiteralPath "$evidence/entry.py" -Destination "$evidence/smoke-source/root/prototype.py" -Force
& $maker --input "$evidence/smoke-source/root" --output "$evidence/smoke-pack" *> "$evidence/smoke-package.log"
if($LASTEXITCODE -ne 0){throw 'Smoke packaging failed'}
& $audit compare "$runtime/pack/root.pck" "$evidence/smoke-pack/root.pck" "$evidence/smoke-pack-diff.tsv" 'prototype.py' > "$evidence/smoke-pack-diff.log"
if($LASTEXITCODE -ne 0){throw 'Unexpected temporary smoke pack delta'}
Get-ChildItem -LiteralPath "$source/build-p0l-final-production/shader-cache" -File | Copy-Item -Destination "$evidence/shader-cache"
Write-Output 'Verified backups of EXE and temporary root package; original pack/source match and single-entry smoke delta.'
