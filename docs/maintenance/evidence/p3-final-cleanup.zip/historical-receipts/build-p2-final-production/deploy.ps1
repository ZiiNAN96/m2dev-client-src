$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
if(@(Get-Process -Name 'Metin2*' -ErrorAction SilentlyContinue).Count){throw 'Another client is running'}
if((& git -C $source rev-parse HEAD) -ne '4b2477db3e2653279a49ba86f0684b987e05d8b7' -or @(& git -C $source status --porcelain=v1).Count){throw 'Approved clean source required'}
$log=Get-Content "$PSScriptRoot/build-release.log" -Raw
if($log -notmatch 'UserInterface.vcxproj -> .*Metin2_Release.exe'){throw 'Fresh successful Release build required'}
foreach($item in (Get-Content "$PSScriptRoot/protected-before.json" -Raw | ConvertFrom-Json)){
 if((Get-FileHash -LiteralPath (Join-Path $runtime $item.path)).Hash -ne $item.sha256){throw "Runtime changed: $($item.path)"}
}
$built="$source/build-h2x/msvc/bin/Release/Metin2_Release.exe"
$target="$runtime/Metin2_Release.exe"
$old=(Get-FileHash $target).Hash
$new=(Get-FileHash $built).Hash
if((Get-FileHash "$PSScriptRoot/backup/Metin2_Release.exe").Hash -ne $old){throw 'Backup mismatch'}
if($old -eq $new){throw 'New P2 binary must differ from prior production'}
Copy-Item -LiteralPath $built -Destination $target -Force
if((Get-FileHash $target).Hash -ne $new){throw 'Installed binary mismatch'}
$receipt=@{sourceCommit=(& git -C $source rev-parse HEAD);oldExeSHA256=$old;newExeSHA256=$new;normalRootSHA256=(Get-FileHash "$runtime/pack/root.pck").Hash;deployed=(Get-Date).ToString('o');runtime=$runtime;replaced=@('Metin2_Release.exe');backup="$PSScriptRoot/backup/Metin2_Release.exe"}
$receipt | ConvertTo-Json -Depth 4 | Set-Content "$PSScriptRoot/deployment.json"
$receipt | ConvertTo-Json -Depth 4
