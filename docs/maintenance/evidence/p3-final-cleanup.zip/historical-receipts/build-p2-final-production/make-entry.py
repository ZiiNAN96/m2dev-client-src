from pathlib import Path
import textwrap

out = Path(__file__).resolve().parent
entry = (out.parent / 'build-p2/production-entry.py').read_text(encoding='utf-8')
entry = entry.replace('"""P1 bounded offline baseline; original graphics configuration and frame pacing."""', '"""Short P2 smoke in the installed original Release; production pacing unchanged."""')
entry = entry.replace("app.RuntimePerf=lambda stage: None\n", '')
entry = entry.replace('  app.RuntimePerf(-1)\n', '')
entry = entry.replace('  app.RuntimePerf(self.index if self.measure_start is not None else -1)\n', '')
entry = entry.replace('app.Loop();app.RuntimePerf(-1);', 'app.Loop();')
start, end = entry.index('STAGES='), entry.index("log=builtins.old_open")
entry = entry[:start] + "STAGES=[('A1_IDLE','a1',1,3),('A1_RUN','a1',1,6),('A1_CAMERA','a1',1,8),('A1_COMBAT','a1',1,8),('A1_TRAVERSAL','a1',1,25),('A1_TRAVERSAL_REPEAT','a1',1,25),('B1_IDLE','b1',1,4),('A1_RETURN','a1',1,4)]\n" + entry[end:]
entry = entry.replace("log=builtins.old_open('p1-run.log','w')", "log=builtins.old_open('p2-smoke.log','w')\napp.MapLoadTrace('enable')")
entry = entry.replace(' def next_stage(self):\n', " def next_stage(self):\n  if getattr(self,'tracing',False):\n   app.MapLoadTrace('pop');assert app.MapLoadTrace('end','p2-sanity-complete');self.tracing=False\n")
entry = entry.replace("emit(dict(event='end',render_fps=", "emit(dict(event='end',effect_log_exists=os.path.exists('effect-renderer.log'),render_fps=")
entry = entry.replace("self.last_attack=-1;self.last_effect=-1", "self.last_attack=-1;self.last_effect=-1;self.captured=False;self.tracing=False")
entry = entry.replace("  t=max(0,now-(self.measure_start or now))", "  if self.measure_start is not None and label.startswith('A1_TRAVERSAL') and not self.tracing:\n   assert app.MapLoadTrace('begin',label);app.MapLoadTrace('push','P2 resource sanity');self.tracing=True\n  t=max(0,now-(self.measure_start or now))")
entry = entry.replace("rotation=t*360/25", "rotation=t*360/duration")
capture_dir = str(out / 'views').replace('\\', '/') + '/'
entry = entry.replace('  app.RenderGame();grp.SetInterfaceRenderState()', "  app.RenderGame();grp.SetInterfaceRenderState()\n  label=STAGES[self.index][0]\n  if label in ('A1_IDLE','A1_COMBAT','B1_IDLE') and self.measure_start is not None and time.monotonic()-self.measure_start>1 and not self.captured:\n   self.captured=True;ok,path=grp.SaveScreenShotToPath(" + repr(capture_dir) + "+label+'-');emit(dict(event='view',name=label,ok=ok,path=path))")
wrapped = "import builtins, traceback\ntry:\n" + textwrap.indent(entry, '    ') + "\nexcept Exception:\n    with builtins.old_open('p2-failure.log','w') as failure:failure.write(traceback.format_exc())\n    import app\n    app.Exit()\n"
(out / 'entry.py').write_text(wrapped, encoding='utf-8')
print('Prepared eight-stage production smoke; no profiling API, no pacing overrides.')
