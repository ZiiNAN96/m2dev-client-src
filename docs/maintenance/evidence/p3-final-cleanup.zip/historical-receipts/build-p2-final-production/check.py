from pathlib import Path
import hashlib, json, re, sys

out=Path(__file__).resolve().parent
src=out.parent
runtime=src.parent/'m2dev-client'
run=out/(sys.argv[1] if len(sys.argv)>1 else 'smoke')
def data(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
receipt=data(out/'deployment.json')
assert sha(runtime/'Metin2_Release.exe')==receipt['newExeSHA256']==sha(src/'build-h2x/msvc/bin/Release/Metin2_Release.exe')
assert sha(out/'backup/Metin2_Release.exe')==receipt['oldExeSHA256']
assert sha(runtime/'pack/root.pck')==receipt['normalRootSHA256']==sha(out/'backup/pack/root.pck')
protected=data(out/'protected-before.json')
for file in protected:
    expected=receipt['newExeSHA256'] if file['path']=='Metin2_Release.exe' else file['sha256']
    assert sha(runtime/file['path'])==expected,file['path']
imports=(out/'production-imports.txt').read_text(encoding='utf-8-sig')
dlls=sorted(set(re.findall(r'^\s+([a-zA-Z0-9_.-]+\.dll)\s*$',imports,re.M)))
forbidden=[x for x in dlls if re.search(r'speedtree|granny|^d3d[89]\.dll$|^d3dx',x,re.I)]
namespace={}
exec((src/'tests/Vegetation/audit_removal.py').read_text(encoding='utf-8').split('def audit(')[0],namespace)
binary=(runtime/'Metin2_Release.exe').read_bytes().lower()
markers=[x.decode() for x in namespace['SDK_MARKERS'] if x.lower() in binary]
assert not forbidden and not markers,(forbidden,markers)
legacy=dict(status='PASS',imports=dlls,forbiddenImports=forbidden,sdkMarkers=markers)
(out/'zero-legacy.json').write_text(json.dumps(legacy,indent=2),encoding='utf-8')
gate=(src/'build-p2/gate.py').read_text(encoding='utf-8').replace('p1-failure.log','p2-failure.log').replace('p1-run.log','p2-smoke.log')
sys.argv=[str(out/'check.py'),str(run)]
exec(compile(gate,str(src/'build-p2/gate.py'),'exec'),{})
audit=(run/'source-resource-audit.log').read_text(encoding='utf-8')
for key in ('NativePrewarmFailures','NativePrewarmLimited','GrannyFileReads'):
    assert re.search(r'\b'+key+r'=0\b',audit),key
assert 'phase=ShutdownClean' in (run/'gdxc-lifecycle.log').read_text(encoding='utf-8')
events=[json.loads(line) for line in (run/'p2-smoke.log').read_text(encoding='utf-8').splitlines()]
ends=[e for e in events if e['event']=='end']
assert [e['name'] for e in ends]==['A1_IDLE','A1_RUN','A1_CAMERA','A1_COMBAT','A1_TRAVERSAL','A1_TRAVERSAL_REPEAT','B1_IDLE','A1_RETURN']
assert all(not e['effect_log_exists'] for e in ends)
assert all(58<=e['render_fps']<=62 and 58<=e['update_fps']<=62 for e in ends)
effect=(run/'effect-renderer.log').read_text(encoding='utf-8')
assert 'dust.dds' in effect and 'ERROR' not in effect
assert 'samyeon_d.mse' in effect and 'palbang_spin.mse' in effect
sys.path.insert(0,str(src/'tests/Loading'))
from summarize_trace import read
traces=read(run/'map-load-trace.tsv')
windows=[w for w in traces if w['label'] in ('A1_TRAVERSAL','A1_TRAVERSAL_REPEAT')]
assert len(windows)==2
world=[]
for end in ends:
    start=next(e for e in events if e['event']=='start' and e['name']==end['name'])
    delta={k:end['world'][k]-start['world'][k] for k in start['world']}
    world.append(dict(name=end['name'],delta=delta))
    for k in ('terrainLoaded','terrainUnloaded','areasLoaded','areasUnloaded','terrainAssignments','treeCreated'):
        assert delta[k]==0,(end['name'],k,delta[k])
assert world[5]['delta']['instanceBufferCreates']==0
for window in windows:
    assert window['frames']>100
repeat=windows[1]
assert not [e for e in repeat['events'] if e['kind']=='pack-read'],repeat['events']
assert not [c for c in repeat['costs'] if c['name'] in ('CreateTexture','CreateBuffer')],repeat['costs']
result=dict(technicalStatus='PASS',sourceCommit=receipt['sourceCommit'],deployment=receipt,exit=data(run/'exit.json'),protectedUnchanged=len(protected)-1,productionRootRestored=True,stages=[dict(name=e['name'],render_fps=e['render_fps'],update_fps=e['update_fps'],effectLogDuringGameplay=e['effect_log_exists']) for e in ends],world=world,traversal=[dict(label=w['label'],frames=w['frames'],counters=w['counters'],resources=[c for c in w['costs'] if c['name'] in ('CreateTexture','CreateBuffer')]) for w in windows],dustRepeatReads=0,dustRepeatTextureCreates=0,effectFileOnlyAtShutdown=True,effectDiagnosticLines=len(effect.splitlines()),zeroLegacy=legacy,fastGate=data(run/'fast-gate.json'),visual='Pending user confirmation; three native spot captures available')
(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
