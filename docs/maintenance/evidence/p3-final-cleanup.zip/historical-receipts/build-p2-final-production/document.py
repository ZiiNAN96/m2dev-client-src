from pathlib import Path
import json, subprocess

out=Path(__file__).resolve().parent
source=out.parent
runtime=source.parent/'m2dev-client'
def data(path):return json.loads(path.read_text(encoding='utf-8-sig'))
first=data(out/'result-smoke.json')
second=data(out/'result.json')
manual=data(out/'manual-acceptance.json')
assert first['technicalStatus']==second['technicalStatus']=='PASS'
assert manual['accepted'] is True
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=source,text=True).strip()
receipt=first['deployment']
first_pid=first['exit']['PID'];second_pid=second['exit']['PID']
result=dict(status='GO',sourceCommit=receipt['sourceCommit'],deployment=receipt,first=first,visible=second,manual=manual)
(out/'final-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
text=f'''

## P2 FINAL Production Deployment – 17.09.2026

**P2 PRODUCTION = GO. P2 deployed. Source Commit: `4b2477d`.** Frischer Release-Build, EXE-Deployment und kurzes Originalclient-Gate abgeschlossen. Keine weitere Optimierung, kein P3, keine Änderung an VSync/Present/FPS-Limiter, kein Commit und kein Push.

### Identität, Backup und Deployment

| Punkt | Verifizierter Stand |
| --- | --- |
| Source | `m2dev-client-src`, Branch `feature/p2-runtime-performance`, HEAD `4b2477db3e2653279a49ba86f0684b987e05d8b7`, Worktree vor/nach Deployment sauber |
| Runtime | Normaler `m2dev-client`, Branch `main`, HEAD `d54637a4b323b9d40f0e200951c40d4d226a2cfc` |
| Finaler Build | Frischer MSBuild-Rebuild von `UserInterface` und Abhängigkeiten, Release/x64, Exit 0; bestehende Python/zlib-PDB-Linkerwarnungen |
| Dauerhaft ersetzt | Ausschließlich `Metin2_Release.exe`; installierter SHA256 identisch mit frischem Buildoutput |
| Deployment-Zeit | {receipt['deployed']} |
| Alte EXE / verifiziertes Backup SHA256 | `{receipt['oldExeSHA256']}` |
| Neue EXE SHA256 | `{receipt['newExeSHA256']}` |
| Unverändertes Produktions-Root-Paket SHA256 | `{receipt['normalRootSHA256']}` |

EXE-Backup: `m2dev-client-src/build-p2-final-production/backup/Metin2_Release.exe`. Zusätzlich wurde nur das tatsächlich vorübergehend ersetzte `pack/root.pck` gesichert. Die drei durch den Smoke überschriebenen bisherigen Logs (`renderer-startup.log`, `vegetation-runtime.log`, `log/syserr.txt`) liegen unter `backup/smoke-state/` und wurden danach bytegenau wiederhergestellt. Keine vollständige Clientkopie. Von 549 geschützten Dateien ist ausschließlich die Release-EXE dauerhaft geändert; **548 unverändert**, einschließlich Debug-EXE, Paketen, Assetquellen, Einstellungen und bisherigen Logs.

Die freigegebene EXE enthält die P2-Mesh-/Shadow-Bindungswiederverwendung, native Dust-Texture-Lifetime und gepufferte optionale Effect-Diagnose sowie den bestehenden P0-L-/Shadercache-/GR2-/Animation-/Production-Prewarm-Stand. Der native Standard bleibt `m_iFPS = 60`; der P2-Commit verändert keine Pacing-Datei. `app.RuntimePerf` ist in der produktiven EXE nicht vorhanden; keine uncapped-Konfiguration oder Profiling-Binary übernommen. Die kurzen nativen FPS-Zähler meldeten in allen Phasen beider Läufe **61 Render-/Update-FPS** im bestehenden nominellen 60-FPS-Pfad. Uncapped-Present-Tails wurden nicht bewertet oder bearbeitet.

### Originalclient-Smoke und Sichtprüfung

Tatsächlich gestartete Datei: `C:\\Users\\ZiiNAN\\Documents\\GitHub\\m2dev-client\\Metin2_Release.exe`, Arbeitsverzeichnis derselbe Originalordner. Kein Testclient gestartet. Zwei kurze Prozesse: **PID {first_pid}**, {first['exit']['Seconds']:.2f} s, und sichtbare Wiederholung **PID {second_pid}**, {second['exit']['Seconds']:.2f} s; jeweils Exit **0** und `ShutdownClean`.

In beiden Läufen: **A1 Idle → Laufen → volle Kameradrehung → Kampf/Effekte → dieselbe 25-s-Traversal-Strecke zweimal → B1 → A1 zurück → sauberer Exit**. Vollständiger nativer `chrmgr.PrewarmVisibleActors(True)` im aktiven GPU-Frame vor den Beobachtungsphasen; `NativePrewarmFailures=0`, `NativePrewarmLimited=0`. Bestehende Grafikqualität und View Distance beibehalten. Vorhandener Shadercache in einem isolierten Evidenzverzeichnis wiederverwendet; der Benutzer-Cache unverändert.

Für den netzwerkfreien Smoke wurde ausschließlich `prototype.py` im installierten Root-Paket vorübergehend ersetzt. Vergleich: **342 Einträge, genau 1 Änderung, 0 neue Einträge**. Die 341 anderen Einträge entsprechen bytegenau dem vorgefundenen Produktionspaket. Die losen Runtime-Assetquellen haben 121 bereits bestehende reine Zeilenendenabweichungen gegenüber diesem Paket; deshalb wurde der zuvor gesicherte, vollständig gegen das installierte Paket geprüfte Inhalt als Smoke-Basis verwendet. Keine dieser Abweichungen wurde deployed oder korrigiert. Nach jedem Exit normales Netzwerk-Startpaket bytegenau zurückgespielt und SHA256 geprüft. Kein Netzwerklogin erforderlich oder ausgeführt.

Die erste Sichtprüfung konnte der Nutzer nicht beobachten. Danach wurde der zweite Lauf ausdrücklich sichtbar gestartet. Nutzerbestätigung nach diesem Lauf: **„{manual['answer']}“**. Damit sind vollständige Meshes/Schatten/Materialien/Effekte, ruhige Vegetation und keine auffälligen neuen sichtbaren Ruckler für diesen kurzen Ablauf bestätigt. Zusätzlich drei native Einzelbilder des ersten Laufs auf sichtbare Inhalte geprüft; keine Visual-Galerie oder große Testsuite.

### P2-Sanity, World Stability und Fast Gate

| Prüfung | Ergebnis |
| --- | --- |
| Dust Resources | **PASS:** Dust im nativen Effect-Pfad aktiv. Während der wiederholten 25-s-Strecke jeweils **0 Pack-Reads, 0 CreateTexture, 0 CreateBuffer** insgesamt, damit auch keine erneuten Dust-Reads/-Creations. Je rund 1.516 präsentierte Frames; aktive Mesh-/Vegetation-Requests belegen das Beobachtungsfenster. |
| Effect Burst / optionale Diagnose | **PASS:** In allen Gameplay-Phasen beider Prozesse existiert noch keine `effect-renderer.log`; erst beim sauberen Exit werden jeweils 34 deduplizierte Diagnosezeilen geschrieben. Kampf-, Dust- und Wasserfalleffekte aktiv, keine Effect-ERROR-Zeile. Der beanstandete synchrone Diagnose-Schreib-/Flush-Pfad belastet diese Gameplay-Frames nicht; keine neue Zeitmess-/Optimierungsserie. |
| Static / Shadow Resources | **PASS:** Sichtprüfung bestätigt; erster Lauf 1.069.864 Mesh-Draws und 2.476.647 Shadow-Draws, keine Binding-/Rendererfehler. |
| Sektoren / Terrain / World | **PASS:** Innerhalb sämtlicher Bewegungsphasen keine Terrain-/Area-Loads/-Unloads, keine Terrain-Neuzuweisung und keine neu erstellten Bäume. Auf der Wiederholungsstrecke auch keine Buffer-/Texturerstellung; kein Hinweis auf Terrain-Patch-/World-Rebuild. Keine neue feine Patch-Instrumentierung eingebaut. |
| Instance Buffer / Vegetation | Erste Traversal-Erschließung 6 Instance-Buffer-Erstellungen; wiederholte Strecke **0**, dazu **0 neue Bäume und 0 LOD-Wechsel**. Kein wiederholter Aufbau; Sichtprüfung bestätigt fehlendes neues Flattern. |
| Fast Gate | **PASS in beiden Originalläufen:** Release, A1/B1/A1, Laufstrecke, Effekte, Exit 0, `ShutdownClean`, leeres frisches Python-Fehlerlog. |
| Diligent / GPU / CPU | `DiligentErrors=0`, `DiligentFatals=0`, `GPUFallbacks=0`, `AllCPUDeformationCalls=0`, `AllCPUDeformationVertices=0`. |
| Shutdown | Alle vorhandenen Fast-Gate-Ressourcen **0**: Source, Skin, Paletten, Collision, Vegetation, Assets, GR2, Animation, Prototypes, Modern/Water sowie Terrain-/Objekt-/Mount-Ressourcen. |
| Zero Legacy | **PASS:** Imports der tatsächlich installierten EXE ohne D3D9/D3DX9, Granny/granny2.dll und SpeedTree; einschlägige SDK-Marker 0. Native Logs `GrannyFileReads=0` bei aktivem eigenem GR2-/Vegetationspfad. Nur kurze Sanity, kein erneuter Vollaudit. |

Für die beiden Traversal-Fenster wurde ausschließlich der vorhandene optionale `MapLoadTrace` mit bereits vorhandenen Zählern verwendet. Erste Sichtbarkeits-/Ressourcennutzung ist von der unveränderten Wiederholung getrennt; keine Behauptung, dass beim allerersten Besuch keinerlei Ressourcen entstehen.

### Git, Nachweise und STOP

Runtime-Abschlussstatus: ausschließlich ` M docs/production-milestone-deployment.md`; nichts gestagt. Source weiterhin sauber auf `4b2477d`. Keine Logs, Caches, Backups, Screenshots, Traces, Debug-Dateien oder Benchmarkdaten deployed/gestagt. Frische Smoke-Dateien wurden hashgeprüft außerhalb des aktiven Clients archiviert und aus dem Runtimeordner entfernt; frühere Logs und Konfigurationen sind wiederhergestellt.

Lokale Nachweise im ignorierten Source-Verzeichnis `build-p2-final-production/`: `build-release.log`, `deployment.json`, `backup-manifest.json`, `protected-before.json`, `normal-staging-source.tsv`, `smoke-pack-diff.tsv`, `production-imports.txt`, `zero-legacy.json`, `result-smoke.json`, `result.json`, `manual-acceptance.json`, `final-result.json`; unter `smoke/` und `visual/` jeweils Launch-/Exit-/Ressourcen-/Lifecycle-Nachweise und `fast-gate.json`. Keine Runtime-Commits, kein Push.

**Client neu starten. STOP nach P2 Production Deployment; kein P3 begonnen.**
'''
document=runtime/'docs/production-milestone-deployment.md'
existing=document.read_text(encoding='utf-8')
assert '## P2 FINAL Production Deployment' not in existing
document.write_text(existing.rstrip()+text,encoding='utf-8')
print('P2 production GO documented with exact deployment and both original-client results.')
