from pathlib import Path
import hashlib, json, re, sys, statistics
out=Path(__file__).resolve().parent
src=out.parent
runtime=src.parent/'m2dev-client'
sys.path.insert(0,str(src/'tests/Loading'))
from summarize_trace import read
def data(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest().upper()
def write(name,obj): (out/name).write_text(json.dumps(obj,indent=2),encoding='utf-8')
receipt=data(out/'deployment.json')
assert sha(runtime/'Metin2_Release.exe')==receipt['newExeSHA256']==sha(src/'build-h2x/msvc/bin/Release/Metin2_Release.exe')
assert sha(runtime/'pack/root.pck')==receipt['newRootSHA256']==sha(out/'normal-pack/root.pck')
assert sha(out/'backup/Metin2_Release.exe')==receipt['oldExeSHA256']
assert sha(out/'backup/pack/root.pck')==receipt['oldRootSHA256']
protected=data(out/'protected-before.json')
for file in protected:
    path=file['path'].replace('\\','/')
    expected={'Metin2_Release.exe':receipt['newExeSHA256'],'pack/root.pck':receipt['newRootSHA256']}.get(path,file['sha256'])
    assert sha(runtime/path)==expected,path
assert (runtime/'docs/production-milestone-deployment.md').read_bytes().startswith((out/'backup/docs/production-milestone-deployment.md').read_bytes())
imports=(out/'production-imports.txt').read_text(encoding='utf-8-sig')
dlls=sorted(set(re.findall(r'^\s+([a-zA-Z0-9_.-]+\.dll)\s*$',imports,re.M)))
assert dlls
forbidden=[d for d in dlls if re.search(r'speedtree|granny|^d3d[89]\.dll$|^d3dx',d,re.I)]
namespace={}
exec((src/'tests/Vegetation/audit_removal.py').read_text().split('def audit(')[0],namespace)
binary=(runtime/'Metin2_Release.exe').read_bytes().lower()
markers=[m.decode() for m in namespace['SDK_MARKERS'] if m.lower() in binary]
assert not forbidden and not markers
write('zero-legacy.json',dict(status='PASS',imports=dlls,forbiddenImports=forbidden,sdkMarkers=markers))
runs={}
for name,expect,save in [('smoke',[0,1],[1,0]),('restart-a',[1,0],[0,1]),('restart-b',[0,1],[2,0]),('restart-c',[2,0],[0,1])]:
    directory=out/name
    exit_info=data(directory/'exit.json'); launch=data(directory/'launch.json')
    assert Path(launch['FilePath']).resolve()==(runtime/'Metin2_Release.exe').resolve()
    assert launch['ExeSHA256']==receipt['newExeSHA256'] and '--frame-pacing-capture' not in launch['Arguments']
    assert not (directory/'frame-pacing.csv').exists()
    events=[json.loads(line) for line in (directory/'p3-smoke.jsonl').read_text().splitlines()]
    first,last=events[0],events[-1]
    assert [first['settings'][k] for k in ('frameRateLimit','vsync')]==expect
    assert last['event']=='completed' and [last['saved'][k] for k in ('frameRateLimit','vsync')]==save
    cfg=(directory/'config/graphics.cfg').read_text()
    for key,value in zip(('FRAME_RATE_LIMIT','VSYNC'),save): assert re.search(r'^'+key+r'\s+'+str(value)+r'\s*$',cfg,re.M)
    gate=(src/'build-p2/gate.py').read_text().replace('p1-failure.log','p3-failure.log').replace('p1-run.log','p3-smoke.jsonl')
    sys.argv=[str(out/'check.py'),str(directory)]
    exec(compile(gate,str(src/'build-p2/gate.py'),'exec'),{})
    audit=(directory/'source-resource-audit.log').read_text()
    for key in ('NativePrewarmFailures','NativePrewarmLimited','GrannyFileReads'):
        assert re.search(r'\b'+key+r'=0\b',audit),key
    lifecycle=(directory/'gdxc-lifecycle.log').read_text()
    assert 'phase=ShutdownClean' in lifecycle
    runs[name]=dict(pid=exit_info['PID'],seconds=exit_info['Seconds'],exit=exit_info['ExitCode'],loaded=expect,saved=save,events=events)
assert len({r['pid'] for r in runs.values()})==4
events=runs['smoke']['events'];ends=[e for e in events if e['event']=='end']
maps=[e for e in events if e['event']=='map']
assert [e['name'] for e in maps]==['a1','b1','a1'] and all(e['mode']==[1,0] for e in maps)
assert all(not e['effect_log_exists'] for e in ends)
effect=(out/'smoke/effect-renderer.log').read_text()
assert 'dust.dds' in effect and 'samyeon_d.mse' in effect and 'palbang_spin.mse' in effect and 'ERROR' not in effect
phases=[]
for end in ends:
    start=next(e for e in events if e['event']=='start' and e['label']==end['label'])
    delta={k:end['world'][k]-start['world'][k] for k in start['world']}
    for k in ('terrainLoaded','terrainUnloaded','areasLoaded','areasUnloaded','terrainAssignments','treeCreated'):
        assert delta[k]==0,(end['label'],k,delta[k])
    intervals=sorted(end['intervals_ms']); rows=end['rows']
    assert intervals and rows
    frames=dict(fps=1000/statistics.mean(intervals),p99_ms=intervals[int((len(intervals)-1)*.99)],max_ms=max(intervals),over20=sum(v>20 for v in intervals),frames=len(intervals))
    phase=dict(label=end['label'],mode=end['mode'],phase=end['phase'],frames=frames,simulationHz=end['updates']/end['wall'],gameWallDeltaMs=(end['game']-end['wall'])*1000,world=delta)
    if end['phase'] in ('RUN','SANITY_RUN'):
        phase['unitsPerGameSecond']=(rows[-1]['x']-rows[0]['x'])/(rows[-1]['game']-rows[0]['game'])
    if end['phase']=='CAMERA':
        phase['cameraDegreesPerGameSecond']=sum((b['camera']-a['camera']+180)%360-180 for a,b in zip(rows,rows[1:]))/(rows[-1]['game']-rows[0]['game'])
    if end['phase']=='COMBAT':
        started=None;durations=[]
        for row in rows:
            if row['attacking'] and started is None: started=row['game']
            if not row['attacking'] and started is not None: durations.append(row['game']-started);started=None
        phase['attackSeconds']=durations
        phase['activeParticles']=max(r['particles'] for r in rows)
    phases.append(phase)
traces=read(out/'smoke/map-load-trace.tsv')
first_use=[]
for name in ('Attack','Damage','Death'):
    trace=next(t for t in traces if t['label']=='first-use-'+name)
    zero={k:trace['counters'].get(k,0) for k in ('first-use-key-allocation','first-use-clip-miss','gr2-parse')}
    zero['runtimeKeyBytes']=trace['bytes'].get('first-use-runtime-keys',0)
    assert all(v==0 for v in zero.values()),zero
    native=next(c for c in trace['costs'] if c['name']=='runtime motion state')
    assert native['max_ms']<8.33
    first_use.append(dict(motion=name,zero=zero,nativeMotionMaxMs=native['max_ms']))
repeat=next(t for t in traces if t['label']=='P2_REPEAT')
assert repeat['frames']>100 and not any(e['kind']=='pack-read' for e in repeat['events'])
assert not any(c['name'] in ('CreateTexture','CreateBuffer') for c in repeat['costs'])
assert next(p for p in phases if p['label']=='P2_REPEAT')['world']['instanceBufferCreates']==0
shader={k:sum(t['counters'].get('shader-'+k,0) for t in traces) for k in ('cache-request','cache-hit','cache-miss','runtime-compile','cache-invalid','cache-write-failure')}
assert shader['cache-request']>0 and shader['cache-request']==shader['cache-hit'] and all(shader[k]==0 for k in ('cache-miss','runtime-compile','cache-invalid','cache-write-failure'))
matrix=[p for p in phases if re.match(r'^\d-\d-',p['label'])]
assert len(matrix)==21
checks={}
checks['fps60']=all(57<p['frames']['fps']<63 for p in matrix if p['mode'][0]==0)
checks['fps120']=all(114<p['frames']['fps']<126 for p in matrix if p['mode'][0]==1)
off=[p['frames']['fps'] for p in matrix if p['mode']==[2,0]]
on=[p['frames']['fps'] for p in matrix if p['mode']==[2,1]]
checks['unlimited']=min(off)>130
checks['vsync']=min(off)>1.2*max(on) and min(on)>120
checks['pacing']=all(p['frames']['over20']==0 for p in matrix)
checks['simulation']=all(abs(p['simulationHz']-1000/16.5)<1.5 and abs(p['gameWallDeltaMs'])<25 for p in matrix)
for key in ('unitsPerGameSecond','cameraDegreesPerGameSecond'):
    values=[abs(p[key]) for p in matrix if key in p]
    checks[key]=min(values)>0 and max(values)/min(values)<1.05
attacks=[t for p in matrix for t in p.get('attackSeconds',[])]
checks['attackTiming']=len(attacks)>=3 and min(attacks)>.8 and max(attacks)<1.2 and max(attacks)-min(attacks)<.05
checks['effects']=all(p['activeParticles']>0 for p in matrix if p['phase']=='COMBAT')
result=dict(status='GO' if all(checks.values()) else 'NO-GO',deployment=receipt,checks=checks,phases=phases,shader=shader,firstUse=first_use,maps=maps,protectedUnchanged=len(protected)-2,fastGate='PASS: four distinct original-client processes',zeroLegacy='PASS',runs={k:{f:v for f,v in r.items() if f!='events'} for k,r in runs.items()},effectLogLines=len(effect.splitlines()),repeatFrames=repeat['frames'])
write('result.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('deployment','phases','maps')},indent=2))
