$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$audit="$source/build-h2x/msvc/tests/AssetRuntime/Release/PackContentAudit.exe"
$maker="$source/build-h2x/msvc/bin/Release/PackMaker.exe"
if(Test-Path "$PSScriptRoot/backup"){throw 'Fresh backup required'}
if(@(Get-Process Metin2* -ErrorAction SilentlyContinue).Count){throw 'Client already running'}
New-Item -ItemType Directory -Path "$PSScriptRoot/backup","$PSScriptRoot/normal-source","$PSScriptRoot/normal-pack","$PSScriptRoot/intermediate-pack","$PSScriptRoot/smoke-source","$PSScriptRoot/smoke-pack","$PSScriptRoot/shader-cache" | Out-Null
$backup=@()
foreach($relative in @('Metin2_Release.exe','pack/root.pck','config/graphics.cfg','docs/production-milestone-deployment.md')){
 $file=Get-Item -LiteralPath (Join-Path $runtime $relative)
 $saved=Join-Path "$PSScriptRoot/backup" $relative
 New-Item -ItemType Directory -Path (Split-Path $saved -Parent) -Force | Out-Null
 Copy-Item -LiteralPath $file.FullName -Destination $saved
 $hash=(Get-FileHash $file.FullName).Hash
 if((Get-FileHash $saved).Hash -ne $hash){throw "Backup mismatch: $relative"}
 $backup+=@{path=$relative;sha256=$hash;bytes=$file.Length}
}
$backup | ConvertTo-Json | Set-Content "$PSScriptRoot/backup-manifest.json"
$files=@(Get-ChildItem -LiteralPath "$runtime/pack","$runtime/config","$runtime/assets/root","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)+@(Get-ChildItem -LiteralPath $runtime -File)
$files | ForEach-Object {@{path=[IO.Path]::GetRelativePath($runtime,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json | Set-Content "$PSScriptRoot/protected-before.json"
# Canonical preserved package inputs; verify before making the two approved changes.
Copy-Item -LiteralPath "$source/build-p2-final-production/smoke-source/root" -Destination "$PSScriptRoot/normal-source/root" -Recurse
Copy-Item -LiteralPath "$runtime/assets/root/prototype.py" -Destination "$PSScriptRoot/normal-source/root/prototype.py" -Force
& $audit source "$runtime/pack/root.pck" "$PSScriptRoot/normal-source/root" "$PSScriptRoot/old-pack-source.tsv" > "$PSScriptRoot/old-pack-source.log"
if($LASTEXITCODE){throw 'Canonical inputs differ from installed pack'}
Copy-Item -LiteralPath "$runtime/assets/root/uichat.py" -Destination "$PSScriptRoot/normal-source/root/uichat.py" -Force
& $maker --input "$PSScriptRoot/normal-source/root" --output "$PSScriptRoot/intermediate-pack" *> "$PSScriptRoot/intermediate-package.log"
if($LASTEXITCODE){throw 'Intermediate packaging failed'}
& $audit compare "$runtime/pack/root.pck" "$PSScriptRoot/intermediate-pack/root.pck" "$PSScriptRoot/chat-diff.tsv" 'uichat.py' > "$PSScriptRoot/chat-diff.log"
if($LASTEXITCODE){throw 'Unexpected chat package delta'}
Copy-Item -LiteralPath "$runtime/assets/root/uigraphicssettings.py" -Destination "$PSScriptRoot/normal-source/root/uigraphicssettings.py" -Force
& $maker --input "$PSScriptRoot/normal-source/root" --output "$PSScriptRoot/normal-pack" *> "$PSScriptRoot/normal-package.log"
if($LASTEXITCODE){throw 'Normal packaging failed'}
& $audit compare "$PSScriptRoot/intermediate-pack/root.pck" "$PSScriptRoot/normal-pack/root.pck" "$PSScriptRoot/settings-diff.tsv" 'uigraphicssettings.py' > "$PSScriptRoot/settings-diff.log"
if($LASTEXITCODE){throw 'Unexpected settings package delta'}
& $audit source "$PSScriptRoot/normal-pack/root.pck" "$PSScriptRoot/normal-source/root" "$PSScriptRoot/new-pack-source.tsv" > "$PSScriptRoot/new-pack-source.log"
if($LASTEXITCODE){throw 'Normal package/source mismatch'}
Copy-Item -LiteralPath "$PSScriptRoot/normal-source/root" -Destination "$PSScriptRoot/smoke-source/root" -Recurse
Copy-Item -LiteralPath "$PSScriptRoot/entry.py" -Destination "$PSScriptRoot/smoke-source/root/prototype.py" -Force
& $maker --input "$PSScriptRoot/smoke-source/root" --output "$PSScriptRoot/smoke-pack" *> "$PSScriptRoot/smoke-package.log"
if($LASTEXITCODE){throw 'Smoke packaging failed'}
& $audit compare "$PSScriptRoot/normal-pack/root.pck" "$PSScriptRoot/smoke-pack/root.pck" "$PSScriptRoot/smoke-diff.tsv" 'prototype.py' > "$PSScriptRoot/smoke-diff.log"
if($LASTEXITCODE){throw 'Unexpected smoke delta'}
Get-ChildItem -LiteralPath "$source/build-p2-final-production/shader-cache" -File | Copy-Item -Destination "$PSScriptRoot/shader-cache"
Write-Output 'Backups verified; 342 entries, exactly two approved production script replacements and one temporary smoke entry.'
