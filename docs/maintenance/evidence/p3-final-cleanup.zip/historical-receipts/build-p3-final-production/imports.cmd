@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > nul
dumpbin /imports ..\m2dev-client\Metin2_Release.exe > build-p3-final-production\production-imports.txt
exit /b %errorlevel%
