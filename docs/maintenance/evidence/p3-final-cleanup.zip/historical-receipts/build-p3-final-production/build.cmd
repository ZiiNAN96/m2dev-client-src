@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p3-final-production\vs.log
if errorlevel 1 exit /b 1
msbuild build-h2x\msvc\src\UserInterface\UserInterface.vcxproj /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m:6 /v:minimal > build-p3-final-production\build-release.log 2>&1
exit /b %errorlevel%

