import builtins, traceback
try:
    import app, background, chr, chrmgr, effect, grp, item, player
    import playersettingmodule, systemSetting, time, ui, wndMgr, json, os
    import mouseModule, uisystemoption
    BASE = 'C:/Users/ZiiNAN/Documents/GitHub/m2dev-client-src/build-p3-final-production/'
    with builtins.old_open(BASE + 'control.json', encoding='utf-8-sig') as stream:
        control = json.load(stream)
    log = builtins.old_open('p3-smoke.jsonl', 'w')
    def emit(**row):
        log.write(json.dumps(row) + '\n'); log.flush()
    def failure():
        with builtins.old_open('p3-failure.log', 'w') as stream: stream.write(traceback.format_exc())
        app.Exit()
    assert not hasattr(app, 'RuntimePerf'), 'Profiling API present'
    initial = systemSetting.GetGraphicsSettings()
    if control['expected'] is not None:
        assert [initial['frameRateLimit'], initial['vsync']] == control['expected'], 'Restart persistence failed'
    emit(event='initial', settings=initial, control=control)
    app.MapLoadTrace('enable')
    assert app.MapLoadTrace('begin', 'production-setup')
    width, height = systemSetting.GetWidth(), systemSetting.GetHeight()
    wndMgr.SetScreenSize(width, height)
    app.Create('P3 Production Smoke', width, height, 1)
    app.SetMouseHandler(mouseModule.mouseController)
    wndMgr.SetMouseHandler(mouseModule.mouseController)
    assert mouseModule.mouseController.Create()
    app.SetCameraMaxDistance(40000.0)
    app.SetSightRange(initial['viewDistance'])
    app.SetHairColorEnable(True); app.SetArmorSpecularEnable(True)
    assert app.LoadLocaleData(app.GetLocalePath())
    item.LoadItemTable(app.GetLocalePath() + '/item_proto')
    getattr(playersettingmodule, '__LoadGameNPC')()
    getattr(playersettingmodule, '__LoadGameEffect')()
    for name in ('INIT', 'WARRIOR', 'ASSASSIN', 'SURA', 'SHAMAN'): playersettingmodule.LoadGameData(name)
    assert app.MapLoadTrace('end', 'setup-complete')
    # Only bounded acceptance scripting; production C++ and normal UI are unmodified.
    STAGES = []
    def stage(label, mode, phase, duration=2.0, mapname='a1', trace=False):
        STAGES.append((label, mode, phase, duration, mapname, trace))
    if control['name'] == 'smoke':
        for motion in ('Attack', 'Damage', 'Death'):
            stage('first-use-' + motion, (1, 0), motion, .65, trace=True)
        for mode in ((0, 0), (1, 0), (2, 0)):
            for phase in ('IDLE', 'CAMERA', 'RUN', 'COMBAT'):
                stage('%d-%d-%s' % (*mode, phase), mode, phase, 2.2 if phase == 'COMBAT' else 2.0)
        for i, mode in enumerate(((0, 0), (0, 1), (0, 0))):
            stage('LIVE_%d' % i, mode, 'IDLE', .65)
        for mode in ((0, 1), (1, 1), (2, 1)):
            for phase in ('IDLE', 'CAMERA', 'RUN'):
                stage('%d-%d-%s' % (*mode, phase), mode, phase)
        stage('P2_RUN', (1, 0), 'SANITY_RUN', 2.5, trace=True)
        stage('P2_REPEAT', (1, 0), 'SANITY_RUN', 2.5, trace=True)
        stage('B1_MOVE', (1, 0), 'RUN', 2.0, mapname='b1')
        stage('A1_RETURN', (1, 0), 'RUN', 2.0)
    else:
        stage('RESTART_VERIFY', tuple(control['expected']), 'IDLE', 1.0)

    class World(ui.Window):
        def __init__(self):
            ui.Window.__init__(self); self.SetSize(width, height); self.Show()
            self.index = -1; self.mapname = None; self.effects = []; self.complete = False
            self.tracing = False; self.maptrace = False
            self.options = uisystemoption.OptionDialog(); self.options.OpenGraphics()
            self.dialog = self.options.graphicsDialog
            self.dialog.SetPosition(width - 370, max(0, (height - 592) // 2))
            choices = [[c.listBox.textDict[i] for i in range(c.listBox.GetItemCount())]
                       for c in (self.dialog.frameRateLimit, self.dialog.vsync)]
            assert choices == [['60', '120', 'Unbegrenzt'], ['Aus', 'Ein']], choices
            labels = [c.label.GetText() for c in self.dialog.combos]
            assert labels.count('FPS-Limit') == labels.count('VSync') == 1
            emit(event='menu', choices=choices, labels=labels, size=[self.dialog.GetWidth(), self.dialog.GetHeight()])
            self.next_stage()

        def clear_effects(self):
            for index in self.effects: effect.DeleteEffect(index)
            self.effects = []

        def apply(self, mode):
            self.dialog.frameRateLimit.SelectItem(mode[0]); self.dialog.vsync.SelectItem(mode[1])
            actual = systemSetting.GetGraphicsSettings()
            assert (actual['frameRateLimit'], actual['vsync']) == mode
            assert all(actual[k] == initial[k] for k in initial if k not in ('frameRateLimit', 'vsync'))

        def next_stage(self):
            app.RotateCamera(0)
            if self.index >= 0:
                if self.tracing:
                    app.MapLoadTrace('pop'); assert app.MapLoadTrace('end', 'sanity-complete'); self.tracing = False
                emit(event='end', label=self.label, mode=self.mode, phase=self.phase,
                     wall=time.monotonic()-self.measure_start, game=app.GetTime()-self.game_start,
                     updates=self.updates, rows=self.rows, intervals_ms=self.intervals,
                     world=systemSetting.TestWorldResidency(), state=systemSetting.TestActorTiming(57900),
                     camera=app.GetCamera(), effect_log_exists=os.path.exists('effect-renderer.log'))
            self.index += 1
            if self.index == len(STAGES):
                self.complete = True
                self.apply(tuple(control['save']))
                self.dialog.Close(); assert not self.dialog.IsShow(), 'Menu save failed'
                saved = systemSetting.GetGraphicsSettings()
                assert systemSetting.LoadGraphicsSettings() and saved == systemSetting.GetGraphicsSettings()
                emit(event='completed', stages=self.index, saved=saved)
                app.Exit(); return
            self.label, self.mode, self.phase, self.duration, mapname, trace = STAGES[self.index]
            self.apply(self.mode)
            self.dialog.Show() if self.phase == 'IDLE' else self.dialog.Hide()
            self.clear_effects(); chr.Destroy()
            if mapname != self.mapname:
                if self.mapname is not None: background.Destroy()
                assert app.MapLoadTrace('begin', 'map-' + self.label); self.maptrace = True
                background.Initialize()
                x, y = {'a1': (63500, 59000), 'b1': (94300, 27100)}[mapname]
                background.LoadMap('metin2_map_' + mapname, float(x), float(y), 0.0)
                self.mapname = mapname
                emit(event='map', name=mapname, stage=self.label, mode=self.mode)
            x, y = {'a1': (63500, 59000), 'b1': (94300, 27100)}[mapname]
            if self.phase == 'SANITY_RUN': x, y = 44000, 25600
            self.origin = (x, y, background.GetHeight(x, y))
            chr.CreateInstance(57900); chr.SelectInstance(57900); chr.SetVirtualID(57900)
            chr.SetInstanceType(6); chr.SetRace(0); chr.SetArmor(11299); chr.SetHair(1001); chr.SetWeapon(19)
            chr.SetMoveSpeed(100); chr.SetAttackSpeed(100); chr.SetMotionMode(chr.MOTION_MODE_ONEHAND_SWORD)
            chr.SetLoopMotion(chr.MOTION_WAIT); chr.SetPixelPosition(*map(int, self.origin)); chr.Show()
            player.SetMainCharacterIndex(57900)
            app.SetCenterPosition(x, -y, self.origin[2] + 100); app.SetCamera(5500., 22., 0., 0.)
            self.prewarm = True; self.started = time.monotonic(); self.measure_start = None
            self.updates = 0; self.rows = []; self.intervals = []; self.previous_render = None
            self.last_attack = -1

        def OnUpdate(self):
            try: self.update()
            except Exception: failure()

        def update(self):
            if self.complete: return
            now = time.monotonic()
            if not self.prewarm and self.measure_start is None and now - self.started >= .65:
                if self.maptrace:
                    if app.MapLoadTrace('active'): assert app.MapLoadTrace('end', 'map-warm')
                    self.maptrace = False
                self.measure_start = now; self.game_start = app.GetTime()
                runtime = systemSetting.GetGraphicsRuntimeConfig()
                assert (runtime['frameRateLimit'], runtime['vsync']) == self.mode, 'Live runtime apply failed'
                emit(event='start', label=self.label, mode=self.mode, phase=self.phase, runtime=runtime,
                     world=systemSetting.TestWorldResidency(), state=systemSetting.TestActorTiming(57900), camera=app.GetCamera())
                if STAGES[self.index][5]:
                    assert app.MapLoadTrace('begin', self.label)
                    app.MapLoadTrace('push', 'short production sanity'); self.tracing = True
                if self.phase in ('RUN', 'SANITY_RUN'): chr.MoveToDestPosition(57900, self.origin[0] + 2500, self.origin[1])
                if self.phase == 'CAMERA': app.RotateCamera(1)
                if self.phase in ('Attack', 'Damage', 'Death'):
                    motion = {'Attack': chr.MOTION_COMBO_ATTACK_1, 'Damage': chr.MOTION_DAMAGE, 'Death': chr.MOTION_DEAD}[self.phase]
                    chr.SelectInstance(57900); start = time.perf_counter_ns(); chr.PushOnceMotion(motion, 0.)
                    emit(event='first-use', motion=self.phase, request_ms=(time.perf_counter_ns()-start)/1e6)
            t = now - self.measure_start if self.measure_start is not None else 0.
            if self.measure_start is not None and t >= self.duration: self.next_stage(); return
            if self.phase == 'COMBAT' and self.measure_start is not None and int(t / 1.1) != self.last_attack:
                self.last_attack = int(t / 1.1); chr.SelectInstance(57900); chr.PushOnceMotion(chr.MOTION_COMBO_ATTACK_1, 0.)
                self.clear_effects(); x, y, z = chr.GetPixelPosition(57900)
                chr.SetPixelPosition(int(x), int(-y), int(z + 100))
                for path in ('d:/ymir work/pc/warrior/effect/samyeon_d.mse', 'd:/ymir work/pc/warrior/effect/palbang_spin.mse'):
                    self.effects.append(effect.CreateEffect(path))
                chr.SetPixelPosition(int(x), int(y), int(z))
            x, y, z = chr.GetPixelPosition(57900); background.Update(x, -y, z); chr.Update(); effect.Update()
            x, y, z = chr.GetPixelPosition(57900); app.SetCenterPosition(x, -y, z + 100)
            if self.measure_start is not None:
                self.updates += 1
                state = systemSetting.TestActorTiming(57900)
                state.update(t=t, game=app.GetTime(), camera=app.GetCamera()[2]); self.rows.append(state)

        def OnRender(self):
            if self.complete: return
            try:
                now = time.perf_counter_ns()
                if self.measure_start is not None:
                    if self.previous_render is not None: self.intervals.append((now-self.previous_render)/1e6)
                    self.previous_render = now
                x, y, z = chr.GetPixelPosition(57900); distance, pitch, rotation, _ = app.GetCamera()
                grp.SetPositionCamera(x, -y, z + 100, distance, pitch, rotation)
                if self.prewarm:
                    assert chrmgr.PrewarmVisibleActors(True), 'Production animation prewarm failed'
                    self.prewarm = False; self.started = time.monotonic()
                app.RenderGame(); grp.SetInterfaceRenderState()
            except Exception: failure()

    world = World(); app.Loop()
    world.clear_effects(); world.options.Destroy(); world.Hide(); world.Destroy()
    chr.Destroy(); background.Destroy(); log.close()
except Exception:
    with builtins.old_open('p3-failure.log', 'w') as stream: stream.write(traceback.format_exc())
    import app
    app.Exit()
