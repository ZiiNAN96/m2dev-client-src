$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
if(@(Get-Process Metin2* -ErrorAction SilentlyContinue).Count){throw 'Client running'}
if((& git rev-parse HEAD) -notlike '186facd*' -or @(& git status --porcelain).Count){throw 'Exact approved clean source required'}
$build=Get-Content "$PSScriptRoot/build-result.json" -Raw | ConvertFrom-Json
if($build.ExitCode -ne 0){throw 'Fresh successful build required'}
if((Get-Content "$PSScriptRoot/build-release.log" -Raw) -notmatch 'UserInterface.vcxproj -> .*Metin2_Release.exe'){throw 'Missing fresh link result'}
foreach($file in (Get-Content "$PSScriptRoot/protected-before.json" -Raw | ConvertFrom-Json)){
 if((Get-FileHash -LiteralPath (Join-Path $runtime $file.path)).Hash -ne $file.sha256){throw "Concurrent runtime change: $($file.path)"}
}
$old=(Get-FileHash "$runtime/Metin2_Release.exe").Hash
$oldRoot=(Get-FileHash "$runtime/pack/root.pck").Hash
$new=(Get-FileHash "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe").Hash
$newRoot=(Get-FileHash "$PSScriptRoot/normal-pack/root.pck").Hash
if($new -ne $build.EXE -or $old -eq $new){throw 'Fresh P3 EXE mismatch'}
if($old -ne (Get-FileHash "$PSScriptRoot/backup/Metin2_Release.exe").Hash -or $oldRoot -ne (Get-FileHash "$PSScriptRoot/backup/pack/root.pck").Hash){throw 'Original backup mismatch'}
Copy-Item -LiteralPath "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe" -Destination "$runtime/Metin2_Release.exe" -Force
Copy-Item -LiteralPath "$PSScriptRoot/normal-pack/root.pck" -Destination "$runtime/pack/root.pck" -Force
if((Get-FileHash "$runtime/Metin2_Release.exe").Hash -ne $new -or (Get-FileHash "$runtime/pack/root.pck").Hash -ne $newRoot){throw 'Deployment hash mismatch'}
$receipt=@{sourceCommit=(& git rev-parse HEAD);uiCommit=(Get-Content "$PSScriptRoot/runtime-before.json" -Raw | ConvertFrom-Json).head;oldExeSHA256=$old;newExeSHA256=$new;oldRootSHA256=$oldRoot;newRootSHA256=$newRoot;replaced=@('Metin2_Release.exe','pack/root.pck');packChangedEntries=@('uichat.py','uigraphicssettings.py');deployed=(Get-Date).ToString('o');runtime=$runtime}
$receipt | ConvertTo-Json | Set-Content "$PSScriptRoot/deployment.json"
$receipt | ConvertTo-Json
