from pathlib import Path
import csv,json,statistics,sys,math,re
r=Path(sys.argv[1]);out=r.parent
def read(name):return [{k:float(v) for k,v in row.items()} for row in csv.DictReader((r/name).open())]
frames=read('p1-frames.csv');gpus={int(x['serial']):x for x in read('p1-gpu.csv')}
events=[json.loads(x) for x in (r/'p1-run.log').read_text().splitlines()]
labels={e['stage']:e['name'] for e in events if e['event']=='prepare'}
def percentile(a,p):
 a=sorted(a);i=(len(a)-1)*p;lo=int(i);return a[lo]+(a[min(lo+1,len(a)-1)]-a[lo])*(i-lo)
def stats(a):return dict(avg=statistics.mean(a),median=statistics.median(a),p95=percentile(a,.95),p99=percentile(a,.99),maximum=max(a),minimum=min(a)) if a else None
cpuKeys=[k for k in frames[0] if k.startswith('cpu_')]
counterKeys=[k for k in frames[0] if k not in cpuKeys and k not in ('serial','stage','presented','wall_ms','interval_ms','thread_cpu_ms')]
summary={};spikes=[]
clock=0.;last=None;previousStage=None;renderFrames=[];pending=[]
for f in frames:
 clock+=f['interval_ms']
 if f['stage']<0:last=None;previousStage=None;pending=[];continue
 if previousStage!=f['stage']:last=None;pending=[];previousStage=f['stage']
 pending.append(f)
 if not f['presented']:continue
 if last is None:last=clock;pending=[];continue
 row=dict(f);row['frametime']=clock-last;row['updates']=len(pending)
 for k in cpuKeys+counterKeys+['thread_cpu_ms','wall_ms']:row[k]=sum(x[k] for x in pending)
 row['cpu_active']=sum(row[k] for k in cpuKeys if k not in ('cpu_present','cpu_sleep'))
 row['gpu']=gpus.get(int(f['serial']),{})
 row['gpu_ms']=sum(v for k,v in row['gpu'].items() if k.startswith('gpu_')) if row['gpu'] else None
 renderFrames.append(row);last=clock;pending=[]
for i,label in labels.items():
 rows=[x for x in renderFrames if x['stage']==i];ft=[x['frametime'] for x in rows]
 if not rows:continue
 cpu={k[4:]:statistics.mean(x[k] for x in rows) for k in cpuKeys}
 active=statistics.mean(x['cpu_active'] for x in rows)
 gkeys=[k for k in next((x['gpu'] for x in rows if x['gpu']),{}) if k.startswith('gpu_')]
 gpu={k[4:]:statistics.mean(x['gpu'][k] for x in rows if x['gpu']) for k in gkeys}
 totals={k:sum(x[k] for x in rows) for k in counterKeys}
 metrics={k:statistics.mean(x['gpu'][k] for x in rows if x['gpu']) for k in next((x['gpu'] for x in rows if x['gpu']),{}) if k!='serial' and not k.startswith('gpu_')}
 count=dict(draws=sum(v for k,v in metrics.items() if k.endswith('_draws')),indexed=sum(v for k,v in metrics.items() if k.endswith('_indexed')),pso_calls=sum(v for k,v in metrics.items() if k.endswith('_pso_calls')),srb_calls=sum(v for k,v in metrics.items() if k.endswith('_srb_calls')),maps=sum(v for k,v in metrics.items() if k.endswith('_maps')),triangles=sum(v for k,v in metrics.items() if k.endswith('_triangles')))
 start=next(e for e in events if e['event']=='start' and e['stage']==i);end=next(e for e in events if e['event']=='end' and e['stage']==i)
 summary[label]=dict(frames=len(rows),process_frames=len([x for x in frames if x['stage']==i]),seconds=sum(ft)/1000,fps_avg=1000/statistics.mean(ft),fps_median=1000/statistics.median(ft),frametime=stats(ft),thresholds={str(t):sum(x>t for x in ft) for t in (8.33,16.67,20,33.33,50)},cpu_active=stats([x['cpu_active'] for x in rows]),thread_cpu=stats([x['thread_cpu_ms'] for x in rows]),gpu=stats([x['gpu_ms'] for x in rows if x['gpu_ms'] is not None]),cpu=cpu,gpu_phases=gpu,counts=count,metrics=metrics,counter_totals=totals,counters_average={k:v/len(rows) for k,v in totals.items()},world_delta={k:end['world'][k]-v for k,v in start['world'].items()},world_start=start['world'],world_end=end['world'],vegetation_start=start['vegetation'],vegetation_end=end['vegetation'],gpu_samples=sum(bool(x['gpu']) for x in rows))
 for x in rows:
  if x['frametime']<=20:continue
  phases={k[4:]:x[k] for k in cpuKeys};gp={k[4:]:v for k,v in x['gpu'].items() if k.startswith('gpu_')}
  spikes.append(dict(scenario=label,frame=int(x['serial']),frametime=x['frametime'],cpu=x['cpu_active'],thread_cpu=x['thread_cpu_ms'],gpu=x['gpu_ms'],largest_cpu=max(phases,key=phases.get),largest_cpu_ms=max(phases.values()),largest_gpu=max(gp,key=gp.get) if gp else None,largest_gpu_ms=max(gp.values()) if gp else None,present=x['cpu_present'],sleep=x['cpu_sleep'],updates=x['updates'],events={k:x[k] for k in ('terrain_load','terrain_unload','area_load','area_unload','instance_create','terrain_rebuild','resource_load','pack_read','gr2_parse','glb_parse','texture_decode','shader_compile','wait_idle','flush','temp_growth','temp_bytes')}))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
(out/'spikes.json').write_text(json.dumps(spikes,indent=2))
with (out/'spikes.csv').open('w',newline='') as f:
 keys=list(spikes[0]) if spikes else ['scenario','frame'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(spikes)
for name,s in summary.items():
 print(name, 'FPS',round(s['fps_avg'],2),'FT',*[round(s['frametime'][k],3) for k in ['median','p95','p99','maximum']], 'CPU',round(s['cpu_active']['avg'],3),'GPU',round(s['gpu']['avg'],3) if s['gpu'] else None,'draws',round(s['counts']['draws'],1),'gpu samples',s['gpu_samples'],'/',s['frames'])
 print(' CPU',sorted(s['cpu'].items(),key=lambda x:-x[1])[:8]);print(' GPU',sorted(s['gpu_phases'].items(),key=lambda x:-x[1])[:5])
print('Largest spikes',json.dumps(sorted(spikes,key=lambda x:-x['frametime'])[:5],indent=2))
