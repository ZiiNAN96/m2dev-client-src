from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parent.parent
manifest=json.loads((r/'build-p1/instrumented-files.json').read_text())
def edit(rel,fn):
 p=r/rel;raw=p.read_bytes();s=raw.decode('utf-8').replace('\r\n','\n');out=fn(s)
 if not any(x['path']==rel for x in manifest):
  b=r/'build-p1/before'/rel;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(raw);manifest.append(dict(path=rel,before=hashlib.sha256(raw).hexdigest()))
 p.write_bytes(out.replace('\n','\r\n').encode('utf-8'))
def cb(s):
 if '#include "Renderer/RuntimePerf.h"' not in s:s='#include "Renderer/RuntimePerf.h"\n'+s
 for t in ['Constants','ObjectConstants','TerrainConstants','SplatConstants','LightConstants','CompositeConstants','ToneConstants']:
  s=s.replace('MapHelper<'+t+'>', 'P1::Add(P1::Uploads);P1::Add(P1::ConstantUpdates);P1::Add(P1::UploadBytes,sizeof('+t+'));MapHelper<'+t+'>')
 return s
for f in ['DiligentModernRenderer.cpp','DiligentStaticObjectRenderer.cpp','DiligentTerrainRenderer.cpp','DiligentEffectRenderer.cpp','DiligentWater.cpp']:
 edit('src/Renderer/'+f,cb)
edit('src/Renderer/DiligentModernRenderer.cpp',lambda s:s.replace('MapHelper<CameraAttribs>', 'P1::Add(P1::Uploads);P1::Add(P1::ConstantUpdates);P1::Add(P1::UploadBytes,2*sizeof(CameraAttribs));MapHelper<CameraAttribs>'))
edit('src/Renderer/DiligentStaticObjectRenderer.cpp',lambda s:s.replace('MapHelper<SkinningMatrix>', 'P1::Add(P1::Uploads);P1::Add(P1::UploadBytes,gpuPrototypeBufferBones*sizeof(SkinningMatrix));MapHelper<SkinningMatrix>').replace('MapHelper<StaticObjectInstance>', 'P1::Add(P1::Uploads);P1::Add(P1::UploadBytes,bytes);MapHelper<StaticObjectInstance>'))
edit('src/Renderer/DiligentTerrainRenderer.cpp',lambda s:s.replace('MapHelper<TerrainSplatVertex>', 'P1::Add(P1::Uploads);P1::Add(P1::VertexUpdates);P1::Add(P1::UploadBytes,count*sizeof(TerrainSplatVertex));MapHelper<TerrainSplatVertex>'))
edit('src/Renderer/DiligentEffectRenderer.cpp',lambda s:s.replace('MapHelper<UploadVertex>', 'P1::Add(P1::Uploads);P1::Add(P1::VertexUpdates);P1::Add(P1::UploadBytes,bytes);MapHelper<UploadVertex>'))
edit('src/Renderer/DiligentWater.cpp',lambda s:s.replace('MapHelper<EffectVertex>', 'P1::Add(P1::Uploads);P1::Add(P1::VertexUpdates);P1::Add(P1::UploadBytes,batch*3*sizeof(EffectVertex));MapHelper<EffectVertex>'))
p=r/'src/Renderer/RuntimePerf.h';s=p.read_text().replace('kind=="shader-compile"','kind=="shader-runtime-compile"');p.write_text(s)
for item in manifest:item['after']=hashlib.sha256((r/item['path']).read_bytes()).hexdigest()
(r/'build-p1/instrumented-files.json').write_text(json.dumps(manifest,indent=2))
