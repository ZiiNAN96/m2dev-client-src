from pathlib import Path
import json,re,hashlib,csv
r=Path(__file__).resolve().parent;root=r/'baseline/test-root/root'
registry=json.loads((root/'vegetation/registry.json').read_text())['entries']
keys=sorted(set(re.findall(r'instance key=(.+?) position=',(r/'baseline/vegetation-runtime.log').read_text())))
assets=[]
for key in keys:
 path=registry[key];raw=(root/path).read_bytes();m=json.loads(raw)
 kind=m.get('modern',{}).get('plantKind',0)
 assert kind==0,(key,kind)
 assets.append(dict(key=key,metadata=path,sha256=hashlib.sha256(raw).hexdigest(),version=m['version'],plant_kind=kind,authored_lod_samples=len(m['lods'])))
result=dict(loaded_asset_types=len(assets),all_native_plant_kind_tree=True,all_version1=all(a['version']==1 for a in assets),fixed_tree_detail=True,source_rule='WorldTree Context keeps RenderContext.fixedTreeDetail=true; UpdateStable fixes stableLod=0 and stableLods.front().state',raw_bucket_warning='Legacy authored sample indices are not stable LOD indices. Raw tree_lod0..tree_impostor bins are excluded; only their sum is used as measured visible main-pass count.',assets=assets)
(r/'lod-policy-audit.json').write_text(json.dumps(result,indent=2))
s=json.loads((r/'summary.json').read_text())
for scenario in s.values():
 a=scenario['counters_average'];visible=sum(a[k] for k in ('tree_lod0','tree_lod1','tree_lod2','tree_impostor'))
 scenario['derived_vegetation_lod']={'lod0':visible,'lod1':0,'lod2':0,'impostor':0,'basis':'measured visible main-pass count plus verified fixed-high native Tree policy and metadata type audit'}
(r/'summary.json').write_text(json.dumps(s,indent=2))
gpu={int(q['serial']) for q in csv.DictReader((r/'baseline/p1-gpu.csv').open())}
frames=[q for q in csv.DictReader((r/'baseline/p1-frames.csv').open()) if int(q['stage'])>=0 and int(q['presented'])]
matched=sum(int(q['serial']) in gpu for q in frames);assert matched==len(frames)
b=json.loads((r/'bursts.json').read_text());b.pop('all_gpu_samples',None);b['measured_presented_frames']=len(frames);b['matched_gpu_samples']=matched;(r/'bursts.json').write_text(json.dumps(b,indent=2))
print('Audited',len(assets),'loaded vegetation asset types, all Tree; matched GPU samples',matched,'/',len(frames))
