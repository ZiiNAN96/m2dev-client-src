from pathlib import Path
import shutil
r=Path(__file__).resolve().parent
source=(r/'entry.py').read_text()
begin=source.index('STAGES=[');end=source.index("log=builtins.old_open",begin)
source=source[:begin]+"STAGES=[('A1_IDLE','a1',1,25),('A1_TRAVERSAL','a1',1,25)]\n"+source[end:]
source=source.replace('app.RuntimePerf(', 'perf(')
pos=source.index('width,height=')
source=source[:pos]+'''measurement_stage=-1
samples=[]
def perf(stage):
 global measurement_stage
 measurement_stage=stage
'''+source[pos:]
source=source.replace('app.RenderGame();grp.SetInterfaceRenderState()', '''start=time.perf_counter_ns();app.RenderGame();end=time.perf_counter_ns()
  if measurement_stage>=0:samples.append((measurement_stage,end,(end-start)/1000000))
  grp.SetInterfaceRenderState()''')
source+="\nwith builtins.old_open('control-frames.json','w') as output:json.dump(samples,output)\n"
wrapped='import builtins,traceback\ntry:\n'+'\n'.join('    '+line for line in source.splitlines())+"\nexcept Exception:\n    with builtins.old_open('p1-failure.log','w') as output:output.write(traceback.format_exc())\n    import app\n    app.Exit()\n"
(r/'control/test-root/root/prototype.py').write_text(wrapped,encoding='utf-8')
shutil.copy2(r.parent.parent/'m2dev-client/Metin2_Release.exe',r/'control/Metin2_Release.exe')
