from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent.parent
def edit(rel,fn):
 p=r/rel;s=p.read_text(encoding='utf-8');p.write_text(fn(s),encoding='utf-8')
edit('src/Renderer/DiligentD3D11Backend.cpp',lambda s:s.replace('const auto& adapter=state->device->GetAdapterInfo();','const auto& adapter=state->device->GetAdapterInfo();\n        {std::ofstream a("p1-adapter.txt");a<<adapter.Description<<" vendor="<<adapter.VendorId<<" device="<<adapter.DeviceId<<" localMemory="<<adapter.Memory.LocalMemory<<"\\n";}'))
def header(s):
 s=s.replace('#include <vector>','#include <vector>\n#include <map>')
 s=s.replace('CulledVegetation,CounterCount','CulledVegetation,InitialLod,TreeActual,BushActual,InstanceGrowth,CounterCount')
 s=s.replace('"culled_vegetation"};','"culled_vegetation","initial_lod","tree_actual","bush_actual","instance_growth"};')
 insert='''struct LodEvent {uint64_t frame;float time,x,y;bool initial,tree,repeat;};
inline std::vector<LodEvent> lodEvents;
inline std::map<const void*,float> lastLodChange;
inline void LodChange(const void* id,bool initial,bool tree,float time,float x,float y){
    if(!capturing)return;bool repeat=false;
    if(initial)Add(InitialLod);else{Add(tree?TreeActual:BushActual);auto it=lastLodChange.find(id);repeat=it!=lastLodChange.end()&&time-it->second<.5f;if(repeat)Add(TreeRepeat);lastLodChange[id]=time;}
    lodEvents.push_back({current.serial,time,x,y,initial,tree,repeat});
}
'''
 s=s.replace('inline void Write(){',insert+'inline void Write(){')
 s=s.replace('std::ofstream meta("p1-meta.txt");','std::ofstream lod("p1-lod-events.csv");lod<<"serial,time,x,y,initial,tree,repeat\\n";for(auto e:lodEvents)lod<<e.frame<<\',\'<<e.time<<\',\'<<e.x<<\',\'<<e.y<<\',\'<<e.initial<<\',\'<<e.tree<<\',\'<<e.repeat<<\'\\n\';\n    std::ofstream meta("p1-meta.txt");')
 return s
edit('src/Renderer/RuntimePerf.h',header)
edit('src/Vegetation/VegetationRenderer.cpp',lambda s:s.replace('if(previous!=instance->lod.meshes)P1::Add(P1::TreeTransition);','if(previous!=instance->lod.meshes){P1::Add(P1::TreeTransition);P1::LodChange(instance,std::all_of(previous.begin(),previous.end(),[](int x){return x<0;}),m.plantKind==PlantKind::Tree,context.lodTime,instance->transform[12],instance->transform[13]);}'))
edit('src/Renderer/DiligentStaticObjectRenderer.cpp',lambda s:s.replace('if(buffer->bytes<bytes) {','if(buffer->bytes<bytes) {\n        if(buffer->buffer)P1::Add(P1::InstanceGrowth);'))
def terrain(s):
 s=s.replace('const int p1OldLod=patch.GetStableLod();','')
 s=s.replace('if(p1OldLod!=patch.GetStableLod())P1::Add(P1::TerrainTransition);','')
 start=s.index('void CMapOutdoor::StabilizeTerrainLods()');end=s.index('void CMapOutdoor::__RenderTerrain_Recurse',start)
 segment=s[start:end]
 segment=segment.replace('const int count=int(m_wPatchCount)*m_wPatchCount;','const int count=int(m_wPatchCount)*m_wPatchCount;\n    static std::vector<int> p1Old;p1Old.resize(count);if(P1::capturing)for(int i=0;i<count;++i)p1Old[i]=m_pTerrainPatchProxyList[i].GetStableLod();')
 pos=segment.rfind('}')
 segment=segment[:pos]+'''    if(P1::capturing)for(int i=0;i<count;++i)if(m_pTerrainPatchProxyList[i].isUsed()&&p1Old[i]!=m_pTerrainPatchProxyList[i].GetStableLod())P1::Add(P1::TerrainTransition);
'''+segment[pos:]
 return s[:start]+segment+s[end:]
edit('src/GameLib/MapOutdoorRender.cpp',terrain)
m=json.loads((r/'build-p1/instrumented-files.json').read_text())
for item in m:item['after']=hashlib.sha256((r/item['path']).read_bytes()).hexdigest()
(r/'build-p1/instrumented-files.json').write_text(json.dumps(m,indent=2))
