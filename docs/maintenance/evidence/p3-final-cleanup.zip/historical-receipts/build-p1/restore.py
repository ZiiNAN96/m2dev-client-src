from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent.parent;folder=r/'build-p1';dest=folder/'instrumentation';dest.mkdir(exist_ok=True)
m=json.loads((folder/'instrumented-files.json').read_text());receipt=[]
# All files had no tracked modifications at P1 start. Preserve exact originals,
# not a git checkout/reset; unrelated documentation never enters this list.
for item in m:
 p=r/item['path'];backup=folder/'before'/item['path'];assert hashlib.sha256(backup.read_bytes()).hexdigest()==item['before']
 item['after']=hashlib.sha256(p.read_bytes()).hexdigest();saved=dest/item['path'];saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,saved)
(folder/'instrumented-files.json').write_text(json.dumps(m,indent=2))
(folder/'instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=r))
for name in ['RuntimePerf.h','RuntimePerfGpu.h']:shutil.copy2(r/'src/Renderer'/name,dest/name)
for item in m:
 p=r/item['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==item['after'],'Concurrent source change: '+item['path']
 shutil.copyfile(folder/'before'/item['path'],p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['before']
 receipt.append(dict(path=item['path'],restored_sha256=item['before']))
for name in ['RuntimePerf.h','RuntimePerfGpu.h']:
 p=r/'src/Renderer'/name;assert p.read_bytes()==(dest/name).read_bytes();p.unlink()
(folder/'source-restoration.json').write_text(json.dumps(dict(restored=receipt,temporary_headers_removed=True),indent=2))
print('Restored',len(receipt),'original files byte-for-byte; archived private instrumentation.')
