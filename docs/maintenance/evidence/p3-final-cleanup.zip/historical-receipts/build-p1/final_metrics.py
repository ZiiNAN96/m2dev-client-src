from pathlib import Path
import json,csv,statistics,hashlib
r=Path(__file__).resolve().parent
def pct(a,p):
 a=sorted(a);x=(len(a)-1)*p;i=int(x);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(x-i)
samples=json.loads((r/'control/control-frames.json').read_text());result={}
for stage,name in [(0,'A1_IDLE'),(1,'A1_TRAVERSAL')]:
 a=[x for x in samples if x[0]==stage];ft=[(y[1]-x[1])/1e6 for x,y in zip(a,a[1:])]
 result[name]=dict(frames=len(ft),fps=1000/statistics.mean(ft),p99=pct(ft,.99),max=max(ft),render_cpu=statistics.mean(x[2] for x in a),over20=sum(x>20 for x in ft))
assert hashlib.sha256((r/'control/Metin2_Release.exe').read_bytes()).digest()==hashlib.sha256((r.parent.parent/'m2dev-client/Metin2_Release.exe').read_bytes()).digest()
(r/'control-summary.json').write_text(json.dumps(result,indent=2));print('CONTROL',json.dumps(result))
rows=[{k:float(v) for k,v in row.items()} for row in csv.DictReader((r/'baseline/p1-frames.csv').open()) if int(row['stage'])>=0]
cpu=[k for k in rows[0] if k.startswith('cpu_') and k not in ('cpu_sleep','cpu_present')]
for row in rows:row['active']=sum(row[k] for k in cpu)
peaks=sorted(rows,key=lambda x:-x['active'])[:10]
io=sorted(rows,key=lambda x:-x['cpu_io'])[:10]
data=dict(cpu_bursts=[dict(serial=int(x['serial']),stage=int(x['stage']),active=x['active'],largest_phase=max(cpu,key=lambda k:x[k]),largest_phase_ms=max(x[k] for k in cpu),pack_read=int(x['pack_read']),buffer_create=int(x['buffer_create']),texture_create=int(x['texture_create'])) for x in peaks],max_io_frame_ms=io[0]['cpu_io'],max_io_serial=io[0]['serial'],total_frames=len(rows))
(r/'bursts.json').write_text(json.dumps(data,indent=2));print('BURSTS',json.dumps(data))
