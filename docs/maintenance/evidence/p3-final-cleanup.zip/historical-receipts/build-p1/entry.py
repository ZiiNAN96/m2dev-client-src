"""P1 bounded offline baseline; original graphics configuration and frame pacing."""
import app,background,builtins,chr,chrmgr,effect,grp,item,player
import playersettingmodule,systemSetting,time,ui,wndMgr,math,json,os
width,height=systemSetting.GetWidth(),systemSetting.GetHeight()
wndMgr.SetScreenSize(width,height)
app.Create('P1 isolated runtime baseline',width,height,1)
app.SetCameraMaxDistance(40000.0)
settings=systemSetting.GetGraphicsSettings()
# Preserve the configured distance; same explicit range selection as the prior route.
app.SetSightRange(25600)
app.SetHairColorEnable(True)
app.SetArmorSpecularEnable(True)
if not app.LoadLocaleData(app.GetLocalePath()):raise RuntimeError('Locale load failed')
item.LoadItemTable(app.GetLocalePath()+'/item_proto')
getattr(playersettingmodule,'__LoadGameNPC')()
getattr(playersettingmodule,'__LoadGameEffect')()
for load in ('INIT','WARRIOR','ASSASSIN','SURA','SHAMAN'):playersettingmodule.LoadGameData(load)
STAGES=[('A1_IDLE','a1',1,25),('A1_CAMERA','a1',1,25),('A1_RUN','a1',1,25),
        ('A1_TRAVERSAL','a1',1,25),('A1_ACTORS_20','a1',20,25),
        ('A1_COMBAT','a1',1,25),('A1_ACTORS_50','a1',50,20),('A1_TRAVERSAL_REPEAT','a1',1,25),
        ('B1_IDLE','b1',1,20),('C1_IDLE','c1',1,20)]
if os.environ.get('P1_PILOT')=='1':STAGES=[('A1_IDLE','a1',1,4),('A1_COMBAT','a1',1,4)]
log=builtins.old_open('p1-run.log','w')
def emit(obj):log.write(json.dumps(obj)+'\n');log.flush()
class World(ui.Window):
 def __init__(self):
  ui.Window.__init__(self);self.SetSize(width,height);self.Show();self.index=-1;self.map=None;self.rows=[];self.effects=[];self.next_stage()
 def clear_effects(self):
  for index in self.effects:effect.DeleteEffect(index)
  self.effects=[]
 def next_stage(self):
  app.RuntimePerf(-1)
  if self.index>=0:
   emit(dict(event='end',stage=self.index,name=STAGES[self.index][0],world=systemSetting.TestWorldResidency(),vegetation=systemSetting.TestVegetationStats()))
  self.clear_effects();self.index+=1
  if self.index==len(STAGES):app.Exit();return
  label,mapname,count,duration=STAGES[self.index]
  chr.Destroy()
  if mapname!=self.map:
   if self.map is not None:background.Destroy()
   background.Initialize()
   x,y={'a1':(63500,59000),'b1':(94300,27100),'c1':(44000,27200)}[mapname]
   background.LoadMap('metin2_map_'+mapname,float(x),float(y),0.0);self.map=mapname
  self.origin={'a1':(63500,59000),'b1':(94300,27100),'c1':(44000,27200)}[mapname]
  if label.startswith('A1_TRAVERSAL'):self.origin=(44000,25600)
  self.position=(*self.origin,background.GetHeight(*self.origin));self.actors=[]
  for i in range(count):
   race,kind=(0,6) if i==0 else ((9003,1) if i%2 else (101,0))
   vid=57900+i;chr.CreateInstance(vid);chr.SelectInstance(vid);chr.SetVirtualID(vid);chr.SetInstanceType(kind);chr.SetRace(race)
   if kind==6:chr.SetArmor(11299);chr.SetHair(1001);chr.SetWeapon(19)
   else:chr.SetArmor(0)
   chr.SetMotionMode(chr.MOTION_MODE_ONEHAND_SWORD if kind==6 else chr.MOTION_MODE_GENERAL)
   chr.SetLoopMotion(chr.MOTION_RUN if label in ('A1_RUN','A1_TRAVERSAL','A1_TRAVERSAL_REPEAT') else chr.MOTION_WAIT)
   self.actors.append(vid);chr.Show()
  player.SetMainCharacterIndex(57900)
  self.prewarm=True;self.measure_start=None;self.started=time.monotonic();self.last_attack=-1;self.last_effect=-1
  emit(dict(event='prepare',stage=self.index,name=label,actors=count,settings=settings,origin=self.origin))
 def OnUpdate(self):
  if self.index>=len(STAGES):return
  label,mapname,count,duration=STAGES[self.index];now=time.monotonic()
  if not self.prewarm and now-self.started>=4 and self.measure_start is None:
   self.measure_start=now;emit(dict(event='start',stage=self.index,name=label,world=systemSetting.TestWorldResidency(),vegetation=systemSetting.TestVegetationStats(),distance=background.GetDistanceSetInfo()))
  t=max(0,now-(self.measure_start or now))
  if self.measure_start is not None and t>=duration:self.next_stage();return
  app.RuntimePerf(self.index if self.measure_start is not None else -1)
  x,y=self.origin;rotation=0.;distance=5500.;pitch=22.
  if label=='A1_CAMERA':rotation=t*360/25
  if label=='A1_RUN':x+=600*t
  if label.startswith('A1_TRAVERSAL'):
   x=44000+1600*math.sin(t*math.pi/12);y=25600+1000*math.sin(t*math.pi/18)
   distance=5500+1200*math.sin(t*math.pi/15);rotation=t*8
  z=background.GetHeight(x,y);self.position=(x,y,z);self.camera=(distance,pitch,rotation)
  app.SetCenterPosition(x,-y,z+100);app.SetCamera(distance,pitch,rotation,0.)
  background.Update(x,-y,z)
  for i,vid in enumerate(self.actors):
   dx=0 if i==0 else ((i-1)%7-3)*170;dy=0 if i==0 else ((i-1)//7+1)*170
   chr.SelectInstance(vid);chr.SetPixelPosition(int(x+dx),int(y+dy),int(background.GetHeight(x+dx,y+dy)))
  if label=='A1_COMBAT':
   combat_t=now-self.started
   if int(combat_t/1.1)!=self.last_attack:
    self.last_attack=int(combat_t/1.1);chr.SelectInstance(57900);chr.PushOnceMotion(chr.MOTION_COMBO_ATTACK_1,0.)
   if int(combat_t/1.5)!=self.last_effect:
    self.last_effect=int(combat_t/1.5);self.clear_effects();chr.SelectInstance(57900)
    chr.SetPixelPosition(int(x),int(-y),int(z+100))
    for path in ('d:/ymir work/pc/warrior/effect/samyeon_d.mse','d:/ymir work/pc/warrior/effect/palbang_spin.mse'):
     self.effects.append(effect.CreateEffect(path))
    chr.SetPixelPosition(int(x),int(y),int(z))
  chr.Update();effect.Update()
 def OnRender(self):
  if self.index>=len(STAGES):return
  x,y,z=self.position;distance,pitch,rotation=getattr(self,'camera',(5500.,22.,0.))
  grp.SetPositionCamera(x,-y,z+100,distance,pitch,rotation)
  if self.prewarm:
   if not chrmgr.PrewarmVisibleActors(True):raise RuntimeError('Production actor prewarm failed')
   self.prewarm=False;self.started=time.monotonic()
  app.RenderGame();grp.SetInterfaceRenderState()
 def OnPressEscapeKey(self):app.Exit();return True
world=World();app.Loop();app.RuntimePerf(-1);world.clear_effects();chr.Destroy();background.Destroy();world.Hide();world.Destroy()
emit(dict(event='completed',stages=world.index));log.close()
