from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parent.parent
backup=root/'build-p1/before'
manifest=[]
def edit(rel,fn):
    p=root/rel; raw=p.read_bytes(); s=raw.decode('utf-8-sig'); s=s.replace('\r\n','\n')
    out=fn(s)
    if out==s: raise RuntimeError('No edit: '+rel)
    dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    p.write_bytes(out.replace('\n','\r\n').encode('utf-8'))
    manifest.append({'path':rel,'before':hashlib.sha256(raw).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})
    (root/'build-p1/instrumented-files.json').write_text(json.dumps(manifest,indent=2))
def inc(s):return '#include "Renderer/RuntimePerf.h"\n'+s
def wrap(s,call,phase,gpu=False):
    assert call in s,call
    return s.replace(call,'{ P1::Scope p1(P1::'+phase+(','+'true' if gpu else '')+'); '+call+' }')
def func(s,signature,phase,gpu=False):
    pattern=re.escape(signature)+r'\s*\{'
    out,n=re.subn(pattern,lambda m:m[0]+'\n    P1::Scope p1(P1::'+phase+(',true' if gpu else '')+');',s)
    assert n==1,(signature,n)
    return out
def app(s):
    s=inc(s).replace('#include "Renderer/SkinningBenchmark.h"','#include "Renderer/SkinningBenchmark.h"\n#include "Renderer/WorldResidencyDiagnostics.h"\n#include "Vegetation/VegetationRenderer.h"')
    start=s.index('bool CPythonApplication::Process()')
    s=s[:start]+'''namespace {
uint64_t P1ThreadTime(){FILETIME c,e,k,u;GetThreadTimes(GetCurrentThread(),&c,&e,&k,&u);ULARGE_INTEGER a,b;a.LowPart=k.dwLowDateTime;a.HighPart=k.dwHighDateTime;b.LowPart=u.dwLowDateTime;b.HighPart=u.dwHighDateTime;return a.QuadPart+b.QuadPart;}
struct P1Frame {
    bool active=P1::enabled;P1::Clock::time_point start;uint64_t thread=0;Renderer::WorldResidencyDiagnostics before;Vegetation::Statistics veg;
    P1Frame(){if(!active)return;start=P1::Clock::now();thread=P1ThreadTime();before=Renderer::worldResidency;veg=Vegetation::statistics;P1::current={};P1::current.serial=++P1::serial;P1::current.stage=P1::stage;P1::current.interval=P1::lastBegin.time_since_epoch().count()?P1::Ms(start-P1::lastBegin):0;P1::lastBegin=start;P1::capturing=true;}
    ~P1Frame(){if(!active)return;auto& f=P1::current;auto& w=Renderer::worldResidency;auto& v=Vegetation::statistics;f.wall=P1::Ms(P1::Clock::now()-start);f.cpuThread=double(P1ThreadTime()-thread)/10000;
    P1::Add(P1::TerrainLoad,w.terrainLoaded-before.terrainLoaded);P1::Add(P1::TerrainUnload,w.terrainUnloaded-before.terrainUnloaded);P1::Add(P1::AreaLoad,w.areasLoaded-before.areasLoaded);P1::Add(P1::AreaUnload,w.areasUnloaded-before.areasUnloaded);P1::Add(P1::InstanceCreate,w.instanceBufferCreates-before.instanceBufferCreates);P1::Add(P1::TerrainAssign,w.terrainAssignments-before.terrainAssignments);P1::Add(P1::VisibleTerrain,w.terrainVisible);P1::Add(P1::VisibleVegetation,v.visible-veg.visible);P1::Add(P1::CulledVegetation,v.culled-veg.culled);
    P1::capturing=false;if(P1::frames.size()<30000)P1::frames.push_back(f);else ++P1::dropped;}
};
}
'''+s[start:]
    s=s.replace('bool CPythonApplication::Process()\n{','bool CPythonApplication::Process()\n{\n    P1Frame p1Frame;P1::Scope p1Root(P1::Other);')
    for call,p,g in [('OnUIUpdate();','PythonUpdate',False),('OnUIRender();','UI',True),('OnMouseRender();','UI',True),('CResourceManager::Instance().Update();','Resources',False),('CCullingManager::Instance().Process();','Culling',False),('CCullingManager::Instance().Update();','Culling',False),('m_pyBackground.RenderCharacterShadowToTexture();','Shadows',True),('m_pyBackground.RenderWater();','Water',True),('Renderer::modernFrame->FinishWater();','Water',True),('Renderer::modernFrame->Begin(light,true);','Sky',True),('Platform::Time::SleepMilliseconds(static_cast<std::uint32_t>(rest));','Sleep',False)]:s=wrap(s,call,p,g)
    return s
edit('src/UserInterface/PythonApplication.cpp',app)
def api(s):
    s=inc(s);pos=s.index('extern BOOL bVisibleNotice')
    s=s[:pos]+'''static PyObject* appRuntimePerf(PyObject*,PyObject* args){int stage;if(!PyTuple_GetInteger(args,0,&stage))return Py_BuildException();if(!P1::enabled){P1::frames.reserve(30000);P1::enabled=true;}P1::stage=stage;P1::current.stage=stage;return Py_BuildNone();}
'''+s[pos:]
    return s.replace('{ "StartSkinningBenchmark",','{ "RuntimePerf",appRuntimePerf,METH_VARARGS },\n        { "StartSkinningBenchmark",')
edit('src/UserInterface/PythonApplicationModule.cpp',api)
def backend(s):
    s='#include "RuntimePerfGpu.h"\n'+s
    s=s.replace('m_impl->inFrame = true;','m_impl->inFrame = true;\n    P1::GpuBegin(m_impl->device,m_impl->context);')
    s=s.replace('void DiligentD3D11Backend::EndFrame()\n{','void DiligentD3D11Backend::EndFrame()\n{\n    P1::GpuEnd();')
    s=s.replace('m_impl->swapChain->Present(1);','P1::Scope p1(P1::Present); m_impl->swapChain->Present(1); P1::current.presented=true;')
    s=s.replace('m_impl->context->WaitForIdle();','m_impl->context->WaitForIdle();\n    P1::GpuShutdown();')
    return s
edit('src/Renderer/DiligentD3D11Backend.cpp',backend)
def trace(s):
    s=inc(s).replace('if(!state.active)return;\n    auto& e=','P1::Event(kind,bytes);\n    if(!state.active)return;\n    auto& e=')
    # Only I/O/assets/shader scopes, disabled elsewhere. No P0 trace file writes.
    s=s.replace('bool active_{};\npublic:\n    Scope','bool active_{};\n    P1::Scope perf_;\npublic:\n    Scope',1)
    s=s.replace(': active_(enabled&&state.active) {',': active_(enabled&&state.active), perf_(P1::TracePhase(phase)) {',1)
    return s
edit('src/EterBase/MapLoadTrace.h',trace)
for path,items in {
'src/UserInterface/PythonCharacterManager.cpp':[('void CPythonCharacterManager::Update()','ActorsUpdate',False),('void CPythonCharacterManager::Deform()','SkinPrepare',False),('void CPythonCharacterManager::Render()','Actors',True)],
'src/EterGrnLib/ModelInstanceUpdate.cpp':[('bool CGrannyModelInstance::UpdateWorldPose()','Animation',False)],
'src/EffectLib/EffectManager.cpp':[('void CEffectManager::Update()','EffectsUpdate',False),('void CEffectManager::Render(RenderPass pass)','Effects',True)],
'src/GameLib/MapOutdoorUpdate.cpp':[('bool CMapOutdoor::Update(float fX, float fY, float fZ)','WorldUpdate',False)],
'src/GameLib/MapOutdoorRender.cpp':[('void CMapOutdoor::RenderTerrain()','Terrain',True),('void CMapOutdoor::RenderArea(bool bRenderAmbience)','StaticWorld',True),('void CMapOutdoor::RenderTree()','Vegetation',True),('void CMapOutdoor::RenderEffect()','Effects',True),('void CMapOutdoor::StabilizeTerrainLods()','LodSelect',False)],
}.items():
    def change(s):
        s=inc(s)
        for sig,p,g in items:s=func(s,sig,p,g)
        return s
    edit(path,change)
def modern(s):
    s=inc(s)
    s=s.replace('const auto shadowStart=std::chrono::steady_clock::now();','P1::Scope p1Shadow(P1::Shadows,true);\n    const auto shadowStart=std::chrono::steady_clock::now();')
    s=s.replace('const auto aoStart=std::chrono::steady_clock::now();','p1Shadow.Stop();P1::Scope p1AO(P1::SSAO,true);\n    const auto aoStart=std::chrono::steady_clock::now();')
    s=s.replace('const auto compositeStart=std::chrono::steady_clock::now();','p1AO.Stop();P1::Scope p1Light(P1::Lighting,true);\n    const auto compositeStart=std::chrono::steady_clock::now();')
    s=s.replace('if(s.config.bloom||loadingPrewarm) {','if(s.config.bloom||loadingPrewarm) {\n        P1::Scope p1Bloom(P1::Bloom,true);')
    s=s.replace('if(!s.tone.pso) {','P1::Scope p1Tone(P1::ToneMap,true);\n    if(!s.tone.pso) {')
    s=s.replace('state.context->DrawIndexed(args);','P1::Add(P1::Vertices,item.draw.vertexCount*args.NumInstances);if(args.NumInstances>1){P1::Add(P1::InstancedDraws);P1::Add(P1::Instances,args.NumInstances);}\n        state.context->DrawIndexed(args);')
    return s
edit('src/Renderer/DiligentModernRenderer.cpp',modern)
def instance(s):
    s=inc(s).replace('MapHelper<StaticObjectInstance> mapped','P1::Add(P1::InstanceUpdates);P1::Add(P1::InstanceBytes,bytes);\n    MapHelper<StaticObjectInstance> mapped')
    return s
edit('src/Renderer/DiligentStaticObjectRenderer.cpp',instance)
def terrain(s):
    s=inc(s)
    s=func(s,'void CTerrainPatch::BuildTerrainVertexBuffer(HardwareTransformPatch_SSourceVertex* akSrcVertex)','Resources')
    return s.replace('P1::Scope p1(P1::Resources);','P1::Scope p1(P1::Resources);P1::Add(P1::TerrainRebuild);')
edit('src/GameLib/TerrainPatch.cpp',terrain)
def lod(s):
    s=inc(s)
    s=s.replace('patch.SetStableLod(int(WorldResidency::TerrainLod', 'const int p1OldLod=patch.GetStableLod();\n        patch.SetStableLod(int(WorldResidency::TerrainLod')
    s=s.replace('patch.GetStableLod())));','patch.GetStableLod())));\n        if(p1OldLod!=patch.GetStableLod())P1::Add(P1::TerrainTransition);')
    s=s.replace('if(Renderer::verboseDiagnostics&&!Renderer::shadowCasterCollection)Renderer::worldResidency.terrainVisible=m_PatchVector.size();','if(Renderer::verboseDiagnostics&&!Renderer::shadowCasterCollection)Renderer::worldResidency.terrainVisible=m_PatchVector.size();\n    if(P1::capturing&&!Renderer::shadowCasterCollection)for(auto& entry:m_PatchVector){int lod=m_pTerrainPatchProxyList[entry.second].GetStableLod();if(lod>=0&&lod<3)P1::Add(P1::Counter(P1::TerrainLod0+lod));}')
    return s
# Already backed up MapOutdoorRender: update directly without replacing its backup.
p=root/'src/GameLib/MapOutdoorRender.cpp';s=p.read_text(encoding='utf-8');p.write_text(lod(s),encoding='utf-8')
manifest[-4 if False else 0:0]=[]
def veg(s):
    s=inc(s)
    s=s.replace('const auto start=std::chrono::steady_clock::now();','P1::Scope p1Batch(P1::InstancePrepare);\n    const auto start=std::chrono::steady_clock::now();')
    s=s.replace('if(previous!=instance->lod.meshes)++statistics.lodChanges;', '''if(P1::capturing&&!context.shadowPass){
            if(previous!=instance->lod.meshes)P1::Add(P1::TreeTransition);
            int level=0;for(unsigned k=0;k<m.lods.size();++k)if(m.lods[k].meshes==instance->lod.meshes){level=int(m.lods.size()-1-k);break;}
            P1::Add(P1::Counter(P1::TreeLod0+std::min(level,3)));
        }
        if(previous!=instance->lod.meshes)++statistics.lodChanges;''')
    s=s.replace('groups[group].push_back(', 'if(P1::capturing&&groups[group].size()==groups[group].capacity()){P1::Add(P1::TempGrowth);P1::Add(P1::TempBytes,(groups[group].size()+1)*sizeof(::Renderer::StaticObjectInstance));}\n                groups[group].push_back(')
    return s
edit('src/Vegetation/VegetationRenderer.cpp',veg)
def trees(s):
    s=inc(s).replace('auto instance=std::make_shared<NativeTree>','P1::Add(P1::TreeCreate);auto instance=std::make_shared<NativeTree>')
    return s.replace('void DeleteWorldTree(WorldTreePtr&tree){tree.reset();}','void DeleteWorldTree(WorldTreePtr&tree){if(tree)P1::Add(P1::TreeDestroy);tree.reset();}')
edit('src/GameLib/WorldTree.cpp',trees)
for item in manifest:item['after']=hashlib.sha256((root/item['path']).read_bytes()).hexdigest()
(root/'build-p1/instrumented-files.json').write_text(json.dumps(manifest,indent=2))
print('Instrumented',len(manifest),'existing files; exact originals saved.')
