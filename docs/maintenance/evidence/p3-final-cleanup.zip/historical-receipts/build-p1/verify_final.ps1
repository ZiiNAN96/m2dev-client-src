$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$before=Get-Content -LiteralPath "$PSScriptRoot/protected-before.json" -Raw | ConvertFrom-Json
$after=@(foreach($item in $before){
    if(-not (Test-Path -LiteralPath $item.path -PathType Leaf)){throw "Missing protected file: $($item.path)"}
    $hash=(Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash
    if($hash -ne $item.sha256){throw "Protected file changed: $($item.path)"}
    [ordered]@{path=$item.path;sha256=$hash}
})
$after | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/protected-after.json"
$restoration=Get-Content -LiteralPath "$PSScriptRoot/source-restoration.json" -Raw | ConvertFrom-Json
foreach($item in $restoration.restored){
    if((Get-FileHash -LiteralPath (Join-Path $source $item.path)).Hash -ne $item.restored_sha256){throw "Restoration mismatch: $($item.path)"}
}
$sourceRoot=Join-Path (Split-Path $source -Parent) 'm2dev-client/assets/root'
$privateRoot=Join-Path $PSScriptRoot 'baseline/test-root/root'
$originalFiles=@(Get-ChildItem -LiteralPath $sourceRoot -File -Recurse)
$privateFiles=@(Get-ChildItem -LiteralPath $privateRoot -File -Recurse)
if($originalFiles.Count -ne $privateFiles.Count){throw 'Private root count mismatch'}
$changed=@(foreach($file in $originalFiles){
    $relative=[IO.Path]::GetRelativePath($sourceRoot,$file.FullName)
    $target=Join-Path $privateRoot $relative
    if((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath $target).Hash){$relative}
})
if($changed.Count -ne 1 -or $changed[0] -ne 'prototype.py'){throw "Unexpected private root difference: $changed"}
$normalExe=Join-Path $source 'build-h2x/msvc/bin/Release/Metin2_Release.exe'
$receipt=[ordered]@{
    checkedAt=(Get-Date).ToString('o');protectedFiles=$after.Count;protectedMismatches=0
    sourceRestoredFiles=$restoration.restored.Count;sourceRestorationMismatches=0
    originalRootFiles=$originalFiles.Count;privateRootChangedFiles=$changed
    normalReleaseBuildExitCode=0;normalReleaseExe=$normalExe;normalReleaseSha256=(Get-FileHash -LiteralPath $normalExe).Hash
    productionExeSha256=(Get-FileHash -LiteralPath (Join-Path (Split-Path $source -Parent) 'm2dev-client/Metin2_Release.exe')).Hash
}
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/final-integrity.json"
$receipt | ConvertTo-Json -Depth 4
