from pathlib import Path
import hashlib, json, subprocess

out=Path(__file__).resolve().parent
src=out.parent
runtime=src.parent/'m2dev-client'
def data(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def git(repo,*args): return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
receipt=data(out/'deployment.json')
expected_changes={'Metin2_Release.exe':receipt['newExeSHA256'],'pack/root.pck':receipt['newRootSHA256']}
protected=data(out/'protected-before.json')
changes=[]
for f in protected:
    relative=f['path'].replace('\\','/')
    actual=sha(runtime/relative)
    assert actual==expected_changes.get(relative,f['sha256']),relative
    if actual!=f['sha256']: changes.append(relative)
assert sorted(changes)==sorted(expected_changes)
observed=list(p for p in runtime.iterdir() if p.is_file())
for directory in ('pack','config','assets/root','log','mark','upload'):
    observed.extend(p for p in (runtime/directory).rglob('*') if p.is_file())
extras=sorted(set(p.relative_to(runtime).as_posix() for p in observed)-set(f['path'].replace('\\','/') for f in protected))
assert not extras,extras
configs=[]
for cfg in data(out/'userconfig-backup.json'):
    actual=sha(runtime/cfg['path'])
    assert actual==cfg['sha256']==sha(Path(cfg['backup']))
    configs.append({'path':cfg['path'],'sha256':actual,'byteIdentical':True,'localSkipWorktree':True})
assert git(src,'branch','--show-current')==git(runtime,'branch','--show-current')=='main'
assert git(src,'rev-parse','HEAD')==receipt['sourceCommit']
assert sha(src/'build-h2x/msvc/bin/Release/Metin2_Release.exe')==receipt['newExeSHA256']
assert not git(src,'status','--porcelain=v1')
assert not git(runtime,'status','--porcelain=v1')
result={'status':'PASS','sourceHead':git(src,'rev-parse','HEAD'),'runtimeHead':git(runtime,'rev-parse','HEAD'),
 'sourceStatus':'clean','runtimeStatus':'clean with two documented local skip-worktree user configs',
 'replaced':changes,'protectedFiles':len(protected),'unchangedFiles':len(protected)-len(changes),'extraArtifacts':extras,
 'configs':configs,'sourceMergedBranches':git(src,'branch','--merged','main').splitlines(),
 'runtimeMergedBranches':git(runtime,'branch','--merged','main').splitlines(),'push':False}
(out/'final-integrity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
