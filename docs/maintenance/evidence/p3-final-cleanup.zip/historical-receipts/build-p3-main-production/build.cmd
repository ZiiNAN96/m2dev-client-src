@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 > build-p3-main-production\vs.log
if errorlevel 1 exit /b 1
cmake -S . -B build-h2x/msvc > build-p3-main-production\configure.log 2>&1
if errorlevel 1 exit /b 1
msbuild build-h2x\msvc\src\UserInterface\UserInterface.vcxproj /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m:6 /v:minimal > build-p3-main-production\build-release.log 2>&1
if errorlevel 1 exit /b 1
cmake --build build-h2x/msvc --config Release --target FramePacingTest GraphicsSettingsTest DisplayConfigurationTest PackMaker PackContentAudit --parallel 6 > build-p3-main-production\build-tests.log 2>&1
if errorlevel 1 exit /b 1
ctest --test-dir build-h2x/msvc -C Release --output-on-failure -R "^Graphics\.(FramePacing|Presets|Custom|Invalid|LiveApply|Display|Persistence|WriteRestart|ReadRestart|DisplayConfiguration)$" > build-p3-main-production\tests.log 2>&1
exit /b %errorlevel%
