$ErrorActionPreference='Stop'
$source=Split-Path $PSScriptRoot -Parent
$runtime=[IO.Path]::GetFullPath((Join-Path $source '../m2dev-client'))
$audit="$source/build-h2x/msvc/tests/AssetRuntime/Release/PackContentAudit.exe"
$maker="$source/build-h2x/msvc/bin/Release/PackMaker.exe"
$build=Get-Content "$PSScriptRoot/build-result.json" -Raw | ConvertFrom-Json
if($build.exitCode -ne 0 -or $build.sourceBranch -ne 'main' -or @($build.sourceStatus).Count){throw 'Clean main build required'}
if((& git -C $source rev-parse HEAD) -ne $build.sourceHead -or (& git -C $source status --porcelain=v1)){throw 'Source changed since build'}
if((& git -C $runtime branch --show-current) -ne 'main' -or (& git -C $runtime status --porcelain=v1)){throw 'Runtime must be clean main before deployment'}
if(@(Get-Process Metin2* -ErrorAction SilentlyContinue).Count){throw 'Client already running'}
if(Test-Path "$PSScriptRoot/backup/Metin2_Release.exe"){throw 'Fresh deployment required'}
@{sourceHead=$build.sourceHead;sourceStatus=@(& git -C $source status --porcelain=v1);runtimeHead=(& git -C $runtime rev-parse HEAD);runtimeStatus=@(& git -C $runtime status --porcelain=v1)} | ConvertTo-Json | Set-Content "$PSScriptRoot/main-before-deployment.json"
$backup=@()
foreach($relative in @('Metin2_Release.exe','pack/root.pck','docs/production-milestone-deployment.md')){
 $file=Get-Item -LiteralPath (Join-Path $runtime $relative)
 $saved=Join-Path "$PSScriptRoot/backup" $relative
 New-Item -ItemType Directory -Path (Split-Path $saved -Parent) -Force | Out-Null
 Copy-Item -LiteralPath $file.FullName -Destination $saved
 $hash=(Get-FileHash -LiteralPath $file.FullName).Hash
 if((Get-FileHash -LiteralPath $saved).Hash -ne $hash){throw "Backup mismatch: $relative"}
 $backup+=@{path=$relative;sha256=$hash;bytes=$file.Length}
}
$backup | ConvertTo-Json | Set-Content "$PSScriptRoot/backup-manifest.json"
# Config templates stay committed unchanged. These two local index flags keep
# personal runtime preferences separate; record and verify the actual bytes.
& git -C $runtime update-index --skip-worktree -- config/graphics.cfg config/metin2.cfg
if($LASTEXITCODE){throw 'Local config index flags failed'}
foreach($cfg in (Get-Content "$PSScriptRoot/userconfig-backup.json" -Raw | ConvertFrom-Json)){
 if((Get-FileHash -LiteralPath $cfg.backup).Hash -ne $cfg.sha256){throw 'User backup changed'}
 Copy-Item -LiteralPath $cfg.backup -Destination (Join-Path $runtime $cfg.path) -Force
 if((Get-FileHash -LiteralPath (Join-Path $runtime $cfg.path)).Hash -ne $cfg.sha256){throw 'User config restore failed'}
}
& git -C $runtime ls-files -v -- config/graphics.cfg config/metin2.cfg | Set-Content "$PSScriptRoot/local-config-index-flags.txt"
$files=@(Get-ChildItem -LiteralPath "$runtime/pack","$runtime/config","$runtime/assets/root","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)+@(Get-ChildItem -LiteralPath $runtime -File)
$files | ForEach-Object {@{path=[IO.Path]::GetRelativePath($runtime,$_.FullName);sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json | Set-Content "$PSScriptRoot/protected-before.json"
New-Item -ItemType Directory -Path "$PSScriptRoot/normal-source","$PSScriptRoot/normal-pack","$PSScriptRoot/gameplay-source","$PSScriptRoot/gameplay-pack","$PSScriptRoot/display-source","$PSScriptRoot/display-pack","$PSScriptRoot/shader-cache" | Out-Null
Copy-Item -LiteralPath "$source/build-p3-final-production/normal-source/root" -Destination "$PSScriptRoot/normal-source/root" -Recurse
& $audit source "$runtime/pack/root.pck" "$PSScriptRoot/normal-source/root" "$PSScriptRoot/old-pack-source.tsv" > "$PSScriptRoot/old-pack-source.log"
if($LASTEXITCODE){throw 'Canonical inputs differ from installed pack'}
$previous="$runtime/pack/root.pck"
$i=0
foreach($name in @('game.py','interfacemodule.py','uigraphicssettings.py','uitaskbar.py')){
 $i++
 $destination=if($i -eq 4){"$PSScriptRoot/normal-pack"}else{"$PSScriptRoot/pack-step-$i"}
 New-Item -ItemType Directory -Path $destination -Force | Out-Null
 Copy-Item -LiteralPath "$runtime/assets/root/$name" -Destination "$PSScriptRoot/normal-source/root/$name" -Force
 & $maker --input "$PSScriptRoot/normal-source/root" --output $destination *> "$PSScriptRoot/pack-step-$i.log"
 if($LASTEXITCODE){throw 'Production packaging failed'}
 & $audit compare $previous "$destination/root.pck" "$PSScriptRoot/pack-step-$i.tsv" $name > "$PSScriptRoot/pack-step-$i-audit.log"
 if($LASTEXITCODE){throw "Unexpected pack delta: $name"}
 $previous="$destination/root.pck"
}
& $audit source "$PSScriptRoot/normal-pack/root.pck" "$PSScriptRoot/normal-source/root" "$PSScriptRoot/new-pack-source.tsv" > "$PSScriptRoot/new-pack-source.log"
if($LASTEXITCODE){throw 'Normal pack source mismatch'}
foreach($kind in @('gameplay','display')){
 Copy-Item -LiteralPath "$PSScriptRoot/normal-source/root" -Destination "$PSScriptRoot/$kind-source/root" -Recurse
 $entry=if($kind -eq 'gameplay'){'entry.py'}else{'display-entry.py'}
 Copy-Item -LiteralPath "$PSScriptRoot/$entry" -Destination "$PSScriptRoot/$kind-source/root/prototype.py" -Force
 & $maker --input "$PSScriptRoot/$kind-source/root" --output "$PSScriptRoot/$kind-pack" *> "$PSScriptRoot/$kind-package.log"
 if($LASTEXITCODE){throw 'Probe packaging failed'}
 & $audit compare "$PSScriptRoot/normal-pack/root.pck" "$PSScriptRoot/$kind-pack/root.pck" "$PSScriptRoot/$kind-diff.tsv" 'prototype.py' > "$PSScriptRoot/$kind-diff.log"
 if($LASTEXITCODE){throw 'Unexpected probe package delta'}
}
Get-ChildItem -LiteralPath "$source/build-p3-final-production/shader-cache" -File | Copy-Item -Destination "$PSScriptRoot/shader-cache"
$old=(Get-FileHash "$runtime/Metin2_Release.exe").Hash
$oldRoot=(Get-FileHash "$runtime/pack/root.pck").Hash
$new=(Get-FileHash "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe").Hash
$newRoot=(Get-FileHash "$PSScriptRoot/normal-pack/root.pck").Hash
if($new -ne $build.exeSha256 -or $old -eq $new){throw 'Fresh main EXE mismatch'}
Copy-Item -LiteralPath "$source/build-h2x/msvc/bin/Release/Metin2_Release.exe" -Destination "$runtime/Metin2_Release.exe" -Force
Copy-Item -LiteralPath "$PSScriptRoot/normal-pack/root.pck" -Destination "$runtime/pack/root.pck" -Force
if((Get-FileHash "$runtime/Metin2_Release.exe").Hash -ne $new -or (Get-FileHash "$runtime/pack/root.pck").Hash -ne $newRoot){throw 'Deployment hash mismatch'}
$receipt=@{sourceCommit=$build.sourceHead;sourceBranch='main';uiCommit=(& git -C $runtime rev-parse HEAD);runtimeBranch='main';oldExeSHA256=$old;newExeSHA256=$new;oldRootSHA256=$oldRoot;newRootSHA256=$newRoot;replaced=@('Metin2_Release.exe','pack/root.pck');packChangedEntries=@('game.py','interfacemodule.py','uigraphicssettings.py','uitaskbar.py');deployed=(Get-Date).ToString('o');runtime=$runtime}
$receipt | ConvertTo-Json | Set-Content "$PSScriptRoot/deployment.json"
$receipt | ConvertTo-Json
