param([switch]$AltTabOnly,[switch]$WindowedAlreadyPassed)
$ErrorActionPreference='Stop'
$runtime=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../m2dev-client'))
$controls=@('display-case.txt','display-world','display-expected.json','alt-tab-windowed.done','alt-tab-borderless.done')
foreach($name in $controls){if(Test-Path -LiteralPath "$runtime/$name"){throw "Existing display control: $name"}}
function RestoreUser {
 foreach($cfg in (Get-Content "$PSScriptRoot/userconfig-backup.json" -Raw | ConvertFrom-Json)){
  Copy-Item -LiteralPath $cfg.backup -Destination (Join-Path $runtime $cfg.path) -Force
  if((Get-FileHash -LiteralPath (Join-Path $runtime $cfg.path)).Hash -ne $cfg.sha256){throw 'User config restore failed'}
 }
}
function Case([string]$name,[string]$case){
 [IO.File]::WriteAllText("$runtime/display-case.txt",$case)
 & "$PSScriptRoot/run-original.ps1" -Name $name -Kind display
 $events=Get-Content "$PSScriptRoot/$name/display-run.jsonl" | ForEach-Object {$_ | ConvertFrom-Json}
 if($events[-1].event -ne 'completed'){throw "Incomplete display run: $name"}
}
try {
 RestoreUser
 [IO.File]::WriteAllText("$runtime/display-world",'1')
 if($AltTabOnly){
  if($WindowedAlreadyPassed){[IO.File]::WriteAllText("$runtime/alt-tab-windowed.done",'Confirmed by user in prior production process PID 3688')}
  Case 'alt-tab' 'alt-tab'
 }
 else {
  Case 'display-matrix' 'matrix'
  Copy-Item -LiteralPath "$PSScriptRoot/display-matrix/display-expected.json" -Destination "$runtime/display-expected.json"
  Case 'display-restart-window' 'restart'
  Case 'display-persist-borderless' 'persist-borderless'
  # The runner preserves pre-existing controls; copy the newly saved expected
  # state from its archive for the next fresh process.
  Copy-Item -LiteralPath "$PSScriptRoot/display-persist-borderless/display-expected.json" -Destination "$runtime/display-expected.json" -Force
  Case 'display-restart-borderless' 'restart'
  $invalids=@{
   'resolution'="RESOLUTION_WIDTH 1234`nRESOLUTION_HEIGHT 777`nDISPLAY_MODE 0`n";
   'exclusive'="RESOLUTION_WIDTH 1024`nRESOLUTION_HEIGHT 768`nDISPLAY_MODE 2`n";
   'mode'="RESOLUTION_WIDTH 1024`nRESOLUTION_HEIGHT 768`nDISPLAY_MODE 9`n";
   'malformed'="RESOLUTION_WIDTH 999999`nRESOLUTION_HEIGHT -5`nDISPLAY_MODE invalid`n"
  }
  foreach($entry in $invalids.GetEnumerator()){
   RestoreUser
   [IO.File]::AppendAllText("$runtime/config/graphics.cfg","`n"+$entry.Value)
   Case "display-fallback-$($entry.Key)" 'fallback'
  }
 }
} finally {
 RestoreUser
 foreach($name in $controls){
  $path=[IO.Path]::GetFullPath((Join-Path $runtime $name))
  if(-not $path.StartsWith($runtime+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe control cleanup path'}
  if(Test-Path -LiteralPath $path){
   $saved=Join-Path $PSScriptRoot "control-archive/$name"
   New-Item -ItemType Directory -Path (Split-Path $saved -Parent) -Force | Out-Null
   Copy-Item -LiteralPath $path -Destination $saved -Force
   if((Get-FileHash -LiteralPath $path).Hash -ne (Get-FileHash -LiteralPath $saved).Hash){throw 'Control archive mismatch'}
   Remove-Item -LiteralPath $path
  }
 }
}
Write-Output 'Production display runs completed; both user configs restored byte-for-byte.'
