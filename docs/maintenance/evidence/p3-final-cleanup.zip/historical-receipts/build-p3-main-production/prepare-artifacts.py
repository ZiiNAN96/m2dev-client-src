from pathlib import Path
import json, hashlib, shutil, subprocess

out = Path(__file__).resolve().parent
src = out.parent
runtime = src.parent / 'm2dev-client'
old = src / 'build-p3-final-production'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def write(name, data):
    (out / name).write_text(json.dumps(data, indent=2), encoding='utf-8')
def checked(args, log):
    result = subprocess.run([str(x) for x in args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / log).write_bytes(result.stdout)
    if result.returncode: raise RuntimeError((log, result.returncode, result.stdout.decode(errors='replace')))

# Keep the established gameplay/timing probe; only adapt its path, menu geometry,
# initial user values and one map-return phase to the approved current display UI.
entry = (old / 'entry.py').read_text()
entry = entry.replace('build-p3-final-production/', 'build-p3-main-production/')
entry = entry.replace("self.dialog.SetPosition(width - 370, max(0, (height - 592) // 2))", "self.dialog.SetCenterPosition()")
entry = entry.replace("stage('A1_RETURN', (1, 0)", "stage('A1_RETURN', (2, 0)")
(out / 'entry.py').write_text(entry, encoding='utf-8')
check = (old / 'check.py').read_text()
check = check.replace("('smoke',[0,1],[1,0])", "('smoke',[2,1],[1,0])")
check = check.replace("all(e['mode']==[1,0] for e in maps)", "[e['mode'] for e in maps]==[[1,0],[1,0],[2,0]]")
(out / 'check.py').write_text(check, encoding='utf-8')
runner = (old / 'run-original.ps1').read_text()
runner = runner.replace("[ValidateSet('smoke','restart-a','restart-b','restart-c')][string]$Name='smoke'", "[string]$Name='smoke',[ValidateSet('gameplay','display')][string]$Kind='gameplay'")
runner = runner.replace("$PSScriptRoot/smoke-pack/root.pck", "$PSScriptRoot/$Kind-pack/root.pck")
runner = runner.replace("$Name -eq 'visual'", "$Name -eq 'alt-tab'")
runner = runner.replace("-gt 180", "-gt 300")
runner = runner.replace("if(Test-Path \"$run/p3-failure.log\")", "if(Test-Path \"$run/display-failure.log\"){throw (Get-Content \"$run/display-failure.log\" -Raw)}\nif(Test-Path \"$run/p3-failure.log\")")
(out / 'run-original.ps1').write_text(runner, encoding='utf-8')
all_runs = (old / 'run-all.ps1').read_text().replace('expected=@(0,1);save=@(1,0)', 'expected=@(2,1);save=@(1,0)')
all_runs = all_runs.replace("Copy-Item -LiteralPath $original -Destination", "Copy-Item -LiteralPath \"$PSScriptRoot/backup/config/metin2.cfg\" -Destination \"$runtime/config/metin2.cfg\" -Force\n Copy-Item -LiteralPath $original -Destination")
(out / 'run-all.ps1').write_text(all_runs, encoding='utf-8')
(out / 'imports.cmd').write_text((old / 'imports.cmd').read_text().replace('build-p3-final-production', 'build-p3-main-production'), encoding='ascii')

# Wrap the committed display transaction probe for the installed production EXE.
display = (src / 'tests/Graphics/p3_display_entry.py').read_text()
display = display.replace('    def OnUpdate(self):\n        size =', '    def OnUpdate(self):\n        size =')
display = display.replace('        if case == "restart":', '''        if case == "alt-tab":
            emit("alt_tab_ready", mode="windowed")
            while not os.path.exists("alt-tab-windowed.done"):
                yield 0.5
            self.dialog.OnDisplayMode(1)
            yield 0.8
            verify()
            self.dialog.ConfirmDisplay()
            emit("alt_tab_ready", mode="borderless")
            while not os.path.exists("alt-tab-borderless.done"):
                yield 0.5
            verify()
            self.dialog.OnDisplayMode(0)
            yield 0.8
            self.dialog.ConfirmDisplay()
            verify()
        elif case == "restart":''')
wrapped = 'import builtins, traceback\ntry:\n' + ''.join('    '+line+'\n' for line in display.splitlines())
wrapped += "except Exception:\n    with builtins.old_open('p3-failure.log', 'w') as stream: stream.write(traceback.format_exc())\n    import app\n    app.Exit()\n"
(out / 'display-entry.py').write_text(wrapped, encoding='utf-8')
print('Prepared bounded probes and runners; no production files changed.')
