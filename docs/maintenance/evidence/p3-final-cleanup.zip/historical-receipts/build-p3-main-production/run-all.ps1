$ErrorActionPreference='Stop'
$runtime=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../m2dev-client'))
$original="$PSScriptRoot/backup/config/graphics.cfg"
if((Get-FileHash "$runtime/config/graphics.cfg").Hash -ne (Get-FileHash $original).Hash){throw 'Original user configuration changed'}
$steps=@(
 @{name='smoke';expected=@(2,1);save=@(1,0)},
 @{name='restart-a';expected=@(1,0);save=@(0,1)},
 @{name='restart-b';expected=@(0,1);save=@(2,0)},
 @{name='restart-c';expected=@(2,0);save=@(0,1)}
)
try {
 foreach($step in $steps){
  $step | ConvertTo-Json | Set-Content "$PSScriptRoot/control.json"
  & "$PSScriptRoot/run-original.ps1" -Name $step.name
  $events=Get-Content "$PSScriptRoot/$($step.name)/p3-smoke.jsonl" | ForEach-Object {$_ | ConvertFrom-Json}
  if($events[-1].event -ne 'completed'){throw "Incomplete run: $($step.name)"}
 }
} finally {
 Copy-Item -LiteralPath "$PSScriptRoot/backup/config/metin2.cfg" -Destination "$runtime/config/metin2.cfg" -Force
 Copy-Item -LiteralPath $original -Destination "$runtime/config/graphics.cfg" -Force
 if((Get-FileHash "$runtime/config/graphics.cfg").Hash -ne (Get-FileHash $original).Hash){throw 'User config restoration failed'}
}
Write-Output 'Original-client smoke and three distinct persistence restarts completed; original configuration restored byte-for-byte.'
