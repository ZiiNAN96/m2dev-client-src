from pathlib import Path
import json, sys, re, hashlib

out=Path(__file__).resolve().parent
src=out.parent
runtime=src.parent/'m2dev-client'
def data(p): return json.loads(p.read_text(encoding='utf-8-sig'))
receipt=data(out/'deployment.json')
cases=['display-matrix','display-restart-window','display-persist-borderless','display-restart-borderless',
       'display-fallback-resolution','display-fallback-exclusive','display-fallback-mode','display-fallback-malformed','alt-tab']
partial='--without-alt-tab' in sys.argv
if partial: cases.remove('alt-tab')
result={}
for name in cases:
    directory=out/name
    launch=data(directory/'launch.json')
    assert Path(launch['FilePath']).resolve()==(runtime/'Metin2_Release.exe').resolve()
    assert Path(launch['WorkingDirectory']).resolve()==runtime.resolve()
    assert launch['ExeSHA256']==receipt['newExeSHA256']
    events=[json.loads(line) for line in (directory/'display-run.jsonl').read_text().splitlines()]
    if name=='alt-tab':
        assert data(out/'alt-tab-ui.json')['status']=='PASS'
        assert data(directory/'exit.json')['ExitCode']==0
    else:
        assert events[-1]['event']=='completed'
    gate=(src/'build-p2/gate.py').read_text().replace('p1-failure.log','display-failure.log').replace('p1-run.log','display-run.jsonl')
    gate=gate.replace("events[-1]['stages']", "events[-1].get('case', 'display')")
    if name=='alt-tab':
        gate=gate.replace("assert events[-1]['event']=='completed'", "assert any(e.get('mode')=='borderless' for e in events)")
        gate=gate.replace("events[-1].get('case', 'display')", "'manual-borderless-acceptance'")
    sys.argv=[str(out/'check-display.py'),str(directory)]
    exec(compile(gate,str(src/'build-p2/gate.py'),'exec'),{})
    assert not (directory/'p3-failure.log').exists()
    assert 'phase=ShutdownClean' in (directory/'gdxc-lifecycle.log').read_text()
    verified=[e for e in events if e['event']=='verified']
    assert verified
    for event in verified:
        s,n=event['settings'],event['native']
        assert (s['resolutionWidth'],s['resolutionHeight'])==(n['clientWidth'],n['clientHeight'])
        assert s['displayMode'] in (0,1) and bool(n['borderless'])==(s['displayMode']==1)
    result[name]={'exit':data(directory/'exit.json'),'verified':len(verified),'completed':events[-1].get('case','manual-borderless-acceptance')}
    if name=='display-matrix':
        modes=sorted(set((e['settings']['resolutionWidth'],e['settings']['resolutionHeight']) for e in verified if e['settings']['displayMode']==0))
        assert len(modes)>=3
        timeout=next(e for e in events if e['event']=='timeout_rollback')
        assert 15<=timeout['elapsed']<18
        assert set((e['settings']['frameRateLimit'],e['settings']['vsync']) for e in verified)>={(i,j) for i in range(3) for j in range(2)}
        hud=[e for e in events if e['event']=='hud_resize']
        assert hud
        for event in hud:
            w,h=event['size']
            assert event['taskbar']==[0,h-37] and event['minimap']==[w-136,0]
        result[name].update(resolutions=modes,rollbackSeconds=timeout['elapsed'],hudReflows=len(hud))
    if name.startswith('display-fallback-'):
        assert any(e['event']=='startup_fallback' and e['settings']['displayMode']==0 for e in events)
    if name=='alt-tab':
        assert [e['mode'] for e in events if e['event']=='alt_tab_ready']==['windowed','borderless']
        assert data(out/'alt-tab-ui.json')['status']=='PASS'
for cfg in data(out/'userconfig-backup.json'):
    assert hashlib.sha256((runtime/cfg['path']).read_bytes()).hexdigest().upper()==cfg['sha256']
if not partial:
    directory=out/'alt-tab-windowed-manual'
    acceptance=data(directory/'acceptance.json')
    assert acceptance['status']=='PASS' and acceptance['pid']==3688
    gate=(src/'build-p2/gate.py').read_text().replace('p1-failure.log','display-failure.log').replace('p1-run.log','display-run.jsonl')
    gate=gate.replace("assert events[-1]['event']=='completed'", "assert any(e.get('mode')=='windowed' for e in events)")
    gate=gate.replace("events[-1]['stages']", "'manual-windowed-acceptance'" )
    sys.argv=[str(out/'check-display.py'),str(directory)]
    exec(compile(gate,str(src/'build-p2/gate.py'),'exec'),{})
    assert 'phase=ShutdownClean' in (directory/'gdxc-lifecycle.log').read_text()
    result['alt-tab-windowed-manual']={'exit':data(directory/'exit.json'),'acceptance':acceptance}
status='PARTIAL' if partial else 'PASS'
(out/'display-result.json').write_text(json.dumps({'status':status,'pending':['alt-tab'] if partial else [],'runs':result,'userConfigs':'byte-identical'},indent=2))
print(json.dumps({'status':status,'runs':len(result),'matrix':result['display-matrix'],'userConfigs':'byte-identical'},indent=2))
