$ErrorActionPreference='Stop'
$runtime=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../m2dev-client'))
if(@(Get-Process Metin2* -ErrorAction SilentlyContinue).Count){throw 'Wait for owned client exit before recovery'}
$archive="$PSScriptRoot/attempt-alt-tab-approval-timeout"
New-Item -ItemType Directory -Path $archive -Force | Out-Null
$normal="$PSScriptRoot/normal-pack/root.pck"
$receipt=Get-Content "$PSScriptRoot/deployment.json" -Raw | ConvertFrom-Json
Copy-Item -LiteralPath $normal -Destination "$runtime/pack/root.pck" -Force
if((Get-FileHash "$runtime/pack/root.pck").Hash -ne $receipt.newRootSHA256){throw 'Normal production pack restore failed'}
$protected=@{}
foreach($f in (Get-Content "$PSScriptRoot/protected-before.json" -Raw | ConvertFrom-Json)){$protected[$f.path]=$f.sha256}
$changes=@()
$files=@(Get-ChildItem -LiteralPath $runtime -File)+@(Get-ChildItem -LiteralPath "$runtime/config","$runtime/log","$runtime/mark","$runtime/upload" -File -Recurse)
foreach($file in $files){
 $relative=[IO.Path]::GetRelativePath($runtime,$file.FullName)
 if($relative -eq 'Metin2_Release.exe'){if((Get-FileHash $file.FullName).Hash -ne $receipt.newExeSHA256){throw 'EXE changed'};continue}
 $hash=(Get-FileHash -LiteralPath $file.FullName).Hash
 if($protected.ContainsKey($relative) -and $protected[$relative] -eq $hash){continue}
 $destination=Join-Path $archive $relative
 New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
 Copy-Item -LiteralPath $file.FullName -Destination $destination
 if((Get-FileHash $destination).Hash -ne $hash){throw 'Recovery archive mismatch'}
 $changes+=@{path=$relative;sha256=$hash;bytes=$file.Length;archive=$destination}
 if($protected.ContainsKey($relative)){
  $saved=Join-Path "$PSScriptRoot/backup/smoke-state" $relative
  if(-not(Test-Path $saved) -or (Get-FileHash $saved).Hash -ne $protected[$relative]){throw "No verified original for $relative"}
  Copy-Item -LiteralPath $saved -Destination $file.FullName -Force
 }else{
  $resolved=[IO.Path]::GetFullPath($file.FullName)
  if(-not $resolved.StartsWith($runtime+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe recovery path'}
  Remove-Item -LiteralPath $resolved
 }
}
$changes | ConvertTo-Json | Set-Content "$archive/recovered-files.json"
@{status='RECOVERED';reason='Computer Use app approval timed out; incomplete Alt-Tab run is excluded';normalRootSHA256=(Get-FileHash "$runtime/pack/root.pck").Hash;configs=@(Get-FileHash "$runtime/config/graphics.cfg","$runtime/config/metin2.cfg" | Select-Object Path,Hash)} | ConvertTo-Json -Depth 4 | Set-Content "$archive/recovery.json"
Get-Content "$archive/recovery.json"
