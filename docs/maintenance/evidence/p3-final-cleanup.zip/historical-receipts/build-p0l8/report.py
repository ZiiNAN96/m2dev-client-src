import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tests/Loading'))
from analyze_first_use import analyze as uses
from analyze_runtime_preparation import analyze as profile
from animation_loading import analyze_animations
from summarize_trace import read
names=['l8-serial','l8-serial-complete','l8-before','l8-after']
u={n:uses(root/'build-p0l'/n) for n in names}
p={n:analyze_animations(root/'build-p0l'/n) for n in names}
prof=[profile(root/'build-p0l'/n)[1] for n in ('l8-before-profile','l8-after-profile')]
for n in names:
    subprocess.run([sys.executable,'tests/Loading/verify_probe.py',str(root/'build-p0l'/n),'--shader-lifecycle','--animation-first-use'],check=True,stdout=subprocess.DEVNULL)
for n in ('l8-before','l8-after','l8-serial-complete'):
    subprocess.run([sys.executable,'tests/Loading/analyze_first_use.py',str(root/'build-p0l'/n),'--expect-prepared'],check=True,stdout=subprocess.DEVNULL)
def prewarm(n):return float(re.search(r'production-prewarm-ms=([\d.]+)',(root/'build-p0l'/n/'p0l-smoke.log').read_text()).group(1))
def cold(n):return p[n][1]['total_ms']
def total(z,key):return sum(c.get(key,0) for c in z['clips'])
def pick(actor,motion):return next(r for r in u['l8-after']['rows'] if r['actor']==actor and r['motion']==motion and r['use']==1)
old,now=prof
before,after=cold('l8-before'),cold('l8-after')
saved=before-after; psaved=prewarm('l8-before')-prewarm('l8-after')
death=next(c for c in now['clips'] if '/warrior/general/dead.gr2|' in c['id'])
assert cold('l8-after')<cold('l8-serial-complete') and psaved>0
assert p['l8-serial-complete'][1]['concurrency']['peak']==0
assert p['l8-after'][1]['concurrency']['peak']==p['l8-before'][1]['concurrency']['peak']==4
parts=[]
def add(s):parts.append(s.strip())
add(f'''# P0-L8 – Animation Runtime Preparation / Prewarm Optimization

## P0-L8 SUMMARY

17.09.2026: **FINAL P0-L7 + P0-L7C + P0-L8 = GO im angeforderten kurzen Release-/Offline-Gate.** Genau ein P0-L8-Fix: bereits berechnete Spline-Zwischenwerte bei adaptiver Unterteilung wiederverwenden. Keine neue Parallelisierung, keine geänderten Keys/Toleranzen, keine gekürzten oder entfernten Animationen.

Vollständiger A1 Cold **{before:.3f} → {after:.3f} ms** (−{saved:.3f} ms / −{100*saved/before:.2f} %). Produktiver Prewarm **{prewarm('l8-before'):.3f} → {prewarm('l8-after'):.3f} ms** (−{psaved:.3f} ms / −{100*psaved/prewarm('l8-before'):.2f} %). Der gesamte A1-Gewinn ist größer als der direkt gemessene Prewarm-Gewinn; die zusätzliche Differenz wird **nicht** dem Fix zugeschrieben. Andere Ladephasen und normale Run-to-Run-Streuung tragen bei.

First Use bleibt warm: maximaler einzelner Runtime-Motion-Aufruf über alle 36 Einsätze **{max(r['runtime_motion_max_ms'] for r in u['l8-after']['rows']):.4f} ms**, 0 neue Runtime-Keys/Clip-Misses/GR2-Parses. **234 bestehende Posen plus 468 Posen gegen den eingefrorenen Vorher-Algorithmus identisch**, alle Keys/Bindings auf vier Randvarianten bitgleich, gezielte Tests **7/7 PASS**.

2014,6 ms bis zum stabilen Frame ist **nicht deutlich unter 2 s**. Dieses Wunschziel wird nicht behauptet; die GO-Kriterien verlangen einen klaren Gewinn und erhaltene First-Use-/Korrektheitsgarantien, keinen erzwungenen 2000-ms-Schwellwert.

## Startstand und Messdefinition

Source `m2dev-client-src`, Branch `codex/g56-hdr-atmosphere`, Ausgangs-HEAD **873d989**. L7/L7C lagen ungestagt vor; Anfangsdiff und Dateihashes wurden unter `build-p0l8/start.*` gesichert. Runtime-/Python-Source ist das separate Repository `m2dev-client`, Ausgangs-HEAD **548c43b4**. Fremde Dateien bleiben ungestagt: Source `docs/performance/p0l3-shader-pso-breakdown.md`, Runtime beide vorherigen Deployment-JSONs. Keine Resets, keine gelöschten Änderungen.

Alle Zeitläufe benutzen denselben privaten Release-Probe mit Originalpacks, gefülltem Shadercache, A1 → B1 → A1 und denselben Actors/Settings. Die echte Funktion `CPythonCharacterManager::PrewarmVisibleActors(true)` läuft vor dem World-Render in einem aktiven GPU-Frame. Im Netzwerkprodukt ruft `PythonNetworkStream::PrepareGamePhase` genau diese Funktion bei sichtbarem LoadingWindow auf. Der Offline-Probe ruft den produktiven Funktionskörper über die vorhandene Python-API auf; ein Netzwerklogin wurde wie beauftragt nicht ausgeführt.

FIRST PLAYABLE: erste native World-Präsentation **nach** Rückkehr der vollständigen Vorbereitung. A1 total endet für alle Läufe am bestehenden `stable-present`-Endpunkt. Beide Werte werden unten getrennt angegeben; die rund 35 ms bis Stabilität werden nicht aus After herausgerechnet. Cold = frischer Prozess, nicht geleerter OS-Dateicache. Keine statistische Langzeit-Benchmarkbehauptung.

Die ursprüngliche HEAD-EXE A0 hat die ältere lokale Prewarm-Auswahl ohne Damage/Death. Deshalb gibt es zusätzlich **A**, den fairen seriellen Kontrollpfad mit derselben vollständigen L7C-Auswahl wie B/C: unveränderter Vorher-Keyalgorithmus, in der privaten Python-Kopie nur `LoadMotionDataBatch(load)` durch den ursprünglichen seriellen `load()` ersetzt. Die übrige L7-Implementierung ist dort nicht ausgeführt. **A ist kein unveränderter HEAD-Build**; A0 bleibt als exakte HEAD-Referenz ausdrücklich separat. Keine Produktdatei wird für diesen Kontrollpfad umgeschaltet.

## PRODUCTION BASELINE / P0-L7/P0-L7C / AFTER

Keine Detailmarker in diesen Zeitläufen. Angaben in ms; GR2 wall enthält die native Runtime-Bindung, Spalten deshalb nicht addieren.

| Variante | A1 total | First playable | GR2 wall | Animation decode wall | Animation parse wall | Runtime Prewarm |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |''')
for name,label in zip(names,('A0: exakte serielle HEAD-Referenz','A: seriell, vollständige L7C-Auswahl','B: L7/L7C vor L8','C: nach L8')):
    x=p[name][1]
    add(f"| {label} | {x['total_ms']:.3f} | {x['first_present_ms']:.3f} | {x['gr2_wall_ms']:.3f} | {x['metrics']['decode_wall_ms']:.3f} | {x['metrics']['parse_wall_ms']:.3f} | {prewarm(name):.3f} |")
add(f'''C ist gegenüber A **{cold('l8-serial-complete')-after:.3f} ms / {100*(cold('l8-serial-complete')-after)/cold('l8-serial-complete'):.2f} %** schneller. Gegenüber der exakten, aber weniger vollständig vorbereitenden HEAD-Referenz A0 beträgt die Verbesserung **{cold('l8-serial')-after:.3f} ms / {100*(cold('l8-serial')-after)/cold('l8-serial'):.2f} %**. Der frühere vereinfachte 1337-ms-Wert wird nicht als fairer Production-Vergleich verwendet.

B und C behalten 646 Animation-Dateijobs, maximal vier Worker und alle 693 Animations-Parses. A hat null Animation-Batchjobs; vorhandener Area-Parallelismus bleibt auch in A erhalten. Änderungen an Decode/Parse-Zeiten in dieser Tabelle sind keine weiteren L8-Fixes.

## Produktiver Callpath und Sharing

`playersettingmodule.LoadGameData` → L7-Batch → ownerseitiger Pack-Read → vorhandene Worker `GR2::File`/Decode/`ReadAnimation` → ownerseitiger Document-Publish mit Quellkurven. Noch keine vollständigen Runtime-Keyarrays für fremde Skeletons.

Nach Actor-Erzeugung: `PrepareGamePhase` → `PrewarmVisibleActors(true)` → `CActorInstance::PrewarmMotions` → `PrepareGR2Animation` → Modell-/Skeleton-/Trackgruppe prüfen → `Document::BoundClip`. Cache-Schlüssel bleibt Animationindex + **Skeleton.BindingId** + Trackgruppenindex, mit vier Boundary-Slots. Ein Treffer liefert denselben immutable Clip. Nur bei Miss: Track/Bone-Zuordnung → `ConvertCurve` → `RuntimeAnimationClip::Initialize` → Cache-Publish. First Use findet diese Struktur direkt.

Im diagnostizierten A1: **82 gültige Prewarm-Requests**, insgesamt **28 neue eindeutige Bindungen einschließlich initialer Idle-Bindungen**, **0 doppelte echte Bindungen** pro Schlüssel. B1 und A1 Warm: jeweils 82 Prewarm-Requests, **0 neue Bindungen**, vorhandene Dokumente behalten ihre Keyarrays. Cache-Limit bleibt 64 MiB pro Dokument / 64 Bindings; kein neuer globaler Cache, keine zusätzlichen Actor-Kopien.

Die anfängliche zufällige Idle-Variante verschiebt genau eine Bindung zwischen Actor-Erzeugung und Prewarm: Diagnose Before **23 neue Prewarm-Bindungen + 5 initiale**, After **24 + 4**. Beide haben dieselben 28 Schlüssel, Source-/Runtime-Daten und Gesamtspeichermengen. Diese Verteilung wird nicht als zusätzliche Arbeitseinsparung ausgegeben. Die First-Use-Prüfung pinnt wie L7C denselben registrierten Clip für die drei Wiederholungen.

## PREWARM BREAKDOWN

Separater opt-in Diagnose-Lauf mit privater Datei `animation-preparation-trace.enabled`, nicht für den Performance-Gewinn verwendet. Feine Timer pro Kurvenauswertung/Fehlerprüfung beeinflussen die Laufzeit deutlich: Before **{old['wall_ms']:.3f} ms**, After **{now['wall_ms']:.3f} ms** statt der oben genannten Zeitläufe. Prozentwerte beziehen sich auf diese diagnostische Prewarm-Wallzeit. Max clip = größter aggregierter Stagewert eines Clips, kein einzelner Key.

| Block Before | Total ms | Calls | Max clip ms | % Prewarm |
| --- | ---: | ---: | ---: | ---: |''')
for s in old['stages']:add(f"| {s['stage']} | {s['ms']:.3f} | {s['calls']} | {s['max_clip_ms']:.3f} | {s['percent']:.3f} |")
for s in old['cache_costs']:add(f"| {s['name']} (ganzer A1-Start) | {s['inclusive_ms']:.3f} | {s['calls']} | n/a | n/a |")
other=old['wall_ms']-sum(s['ms'] for s in old['stages'])
add(f'''**Other / Scope- und Timer-Overhead / Actor-Auswahl / nicht einzeln getimte Arbeit:** Rest **{other:.3f} ms** im diagnostischen Prewarm, inklusive nicht aus den Stage-Timern separierbarer Messkosten. Diese Restzeit ist keine belegte Optimierungsreserve. Globale Cache-/Lookup-Timer oben umfassen auch initiales Actor-Binding; sie werden nicht nochmals von diesem Prewarm-Rest abgezogen.

Vollständige Zuordnung der angeforderten A–R-Blöcke:

| Block | Befund / Messung |
| --- | --- |
| A Clip lookup | eigener Cache-Lookup-Timer und Hit/Miss-Zähler; keine Suche pro Key |
| B Skeleton lookup | `model skeleton and track group lookup`; ownerseitiger Handle-/Gruppencheck vor BoundClip |
| C Track → Bone | 1198 Zuordnungen im Before-Prewarm, 0,598 ms; pro Bone/Track, nicht pro Key |
| D Key count | inkrementelles Zählen plus Budgetcheck im `key count and store`-Timer; kein separater Vollpass |
| E Key allocation | `key allocation relocation`; 22.415 Key-Vektorvergrößerungen im Before-Prewarm |
| F Key generation | adaptive Probeauswertung + Fehlerprüfung + Keyablage, oben getrennt |
| G Key conversion | `source curve evaluation` enthält B-Spline-Basis, float-Konvertierung und Quaternion-Normalisierung; kein zusätzlicher Kopier-/Konvertierungspass |
| H Sorting | **0** Runtime-Sort-Aufrufe: Rekursion emittiert monoton; Source-Sortiertheitsprüfung geschieht beim Parse |
| I Sampling/index table | **0** zusätzliche Tabellen; Runtime verwendet direkt `upper_bound` auf Keys |
| J Interpolation metadata | konstantes Linear-Metadatum je Kanal; in Clip-Validierung/Trackaufbau enthalten, kein großer Extra-Pass |
| K Duration/timeline | eigener Timer für Source-Knotenzeit-Vektor; keine feste Raster-/Frame-Schleife |
| L Duplicate/static tracks | Statistik pro Quellkanal; vorhandener <=1-Knoten-Pfad emittiert bereits nur einen Key |
| M Temporary buffers | Knotzeit-Vektoren und temporär gehaltene alte Vektorspeicher bei Wachstum erfasst |
| N Alloc/realloc | dynamische Key-, Track- und Zeitvektoren sowie Clip-Objekt gezählt; Grenzen unten |
| O Copies/memcpy | Vektor-Relocation-Bytes gezählt und in Allocation/Track/Timeline-Zeiten enthalten; vollständige Keyarrays werden beim Clip-Publish verschoben, nicht kopiert |
| P Cache insertion | eigener `cache memory count and insertion`-Timer; unveränderter Documentcache |
| Q Synchronization/locks | **0** neue Runtime-Preparation-Locks/Worker-Waits; Bindung läuft weiter synchron auf dem Owner |
| R Other | separat ausgewiesener Rest oben; keine versteckte Zeitgutschrift |

## RUNTIME DATA / MEMORY

Für einen fairen Mengenvergleich umfasst diese Tabelle **alle 28 Bindungen des kalten A1-Starts**, da initiales Idle und Prewarm ineinander übergehen. Es gibt keine Mengenreduktion durch den Fix.

| Größe | Before | After |
| --- | ---: | ---: |''')
for title,key in [('Gebundene Tracks / Bone-Referenzen','runtime-tracks'),('Source-Knoten der referenzierten Tracks','runtime-source-keys'),('Runtime-Keys','runtime-keys'),('Runtime-Clip-/Track-/Key-Kapazitätsbytes','runtime-owned-bytes'),('Gezählte Allokationsanforderungen','runtime-allocations'),('Davon Vektor-Reallokationen','runtime-reallocations'),('Kumulierte angeforderte Kapazitätsbytes','runtime-allocated-bytes'),('Kumulierte temporäre Timeline-Kapazitätsbytes','runtime-temporary-allocated'),('Relokierte Elementbytes','runtime-relocated-bytes'),('Source-Kurvenauswertungen','runtime-sample-calls')]:
    add(f'| {title} | {total(old,key)} | {total(now,key)} |')
add(f'''| Peak temporäre Heap-Kapazität | {old['peak_temporary_bytes']} | {now['peak_temporary_bytes']} |

Runtime-Array-/Clip-Speicher **83.651.352 Bytes / {83651352/1024/1024:.3f} MiB**, unverändert. Gezählt werden tatsächliche Vektorkapazitäten und `sizeof` der Clip-/Trackobjekte. Dies ist **keine Prozess-RSS-Messung**: Allocatorheader/Shared-Pointer-Controlblock, Namens-String-Heap und das Validierungs-Bitset sind nicht enthalten; ebenso nicht die separat gehaltenen GR2-Quelldokumente. Allokationscounts sind die instrumentierten Strukturen, kein globaler Heap-Hook. Gleiche IR und gleicher Vorbereitungsumfang schließen ein Entfernen von Quelldaten als Gewinnquelle aus.

Peak temporary ist das Maximum gleichzeitig lebender Timeline-Kapazität und alter Kapazität während einer Key-Reallokation; kein aufsummierter Peak über Clips. Der Fix braucht zusätzlich ein festes Array aus drei Proben pro Rekursionsebene: höchstens **2040 Bytes Probe-Nutzdaten auf dem Stack** bei Dimension 9 und maximal 17 aktiven Ebenen, zuzüglich compilerabhängigem Frame-Overhead. Kein zusätzlicher Heap, keine zusätzliche dauerhafte Runtime-Memory.

## DEATH ANALYSIS – 225.456 Keys

Datei `d:/ymir work/pc/warrior/general/dead.gr2`, Boundary 0. Source **75 Transform-Tracks, {death['runtime-all-source-keys']} Source-Knoten insgesamt**; davon **74 tatsächlich an Bones gebundene Tracks mit 3582 Knoten**. Der zusätzliche ungebundene Track wird unverändert nicht als Skelettkanal abgetastet. Dauer **{death['duration']:.9f} s**, Metadatum TimeStep **0,033333335 s** (~30 Hz Autorentakt).

Runtime **225.456 Keys**, Expansion **{225456/3709:.3f}×** gegenüber allen Source-Knoten bzw. **{225456/3582:.3f}×** gegenüber den gebundenen Source-Knoten. Aufteilung: **17.351 Translation, 208.031 Rotation, 74 Scale/Shear**. Durchschnitt **{death['keys_per_second']:.1f} Keys/s über alle Kanäle**, **{death['keys_per_track']:.1f} Keys/Track**; dies ist ausdrücklich **keine feste Samplerate**.

Root cause der Expansion: Source enthält kompakte GR2-B-Spline-Kurven mit float-Knoten/Controls; Runtime speichert lineare Zeit/Wert-Keys. `ConvertCurve` prüft jedes Knotenintervall bei 1/4, 1/2, 3/4 gegen die Runtime-Interpolation und halbiert adaptiv. Toleranzen bleiben Translation **1e-5**, Rotation/Scale **5e-7** einschließlich bestehender float-Rundungskorrektur, maximale Tiefe 16. Für Death wird Tiefe **{death['runtime-max-depth']}** erreicht. 221.801 innere Splits / 225.234 Blattintervalle erklären die hohe Ausgabe, überwiegend Rotation. Es wird weder pro Frame vorab gerastert noch pro Bone die ganze Animation kopiert.

Death hat **23 vollständig statische gebundene Tracks**, konstante/Identity-Kanäle Translation **68/74**, Rotation **23/74**, Scale **74/74**. 73 Identity-Kanäle + 92 explizit konstante Kanäle = 165 mathematisch konstante Kanäle; dieselben 165 werden bereits im Ein-Key-Pfad behandelt. Kein zusätzlicher Mehrknoten-Konstantfall wurde in diesem Clip gefunden. Statische Scale-Tracks verursachen damit 74, nicht hunderttausende Keys.

Die teure Redundanz liegt **innerhalb** der Key-Erzeugung: ein Parent hat die Mitte bereits als Prüfprobe berechnet, berechnet sie bei Split aber erneut; seine Viertelproben werden danach als Kind-Mittelpunkte wieder berechnet. Vorher Death **1.569.994**, nachher **988.506 Source-Auswertungen**: **581.488 identische Auswertungen entfallen**. Sämtliche Fehlerprüfungen und 225.456 Ausgabekeys bleiben erhalten.

## Source vs. Runtime – repräsentative Clips

Source-Format der gemessenen GR2-Kurven: `legacy-f32` bzw. GR2-Format 1, eigene float-Knotenzeit-/Control-Arrays, Grad 0–2. Runtime: `Track<array<float,N>>`, Zeit als double, Werte als float, unveränderte lineare Interpolationsmetadaten (Quaternion-Normalisierung/Nlerp im vorhandenen Sampler). Tabellenzeit ist Clipdauer, Keys sind einzelne Kanalknoten, nicht ganze Skelettposen.

| Motion, Warrior | Source tracks gesamt / gebunden | Source keys gesamt / gebunden | Runtime tracks | Runtime keys | Dauer s | Keys/s | Keys/Track |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |''')
for motion in ('Idle','Walk','Run','Attack','Damage','Death'):
    path=pick('player',motion)['path'];c=next(c for c in now['clips'] if c['id'].startswith(path+'|'))
    add(f"| {motion} | {c['runtime-source-tracks']} / {c['runtime-tracks']} | {c['runtime-all-source-keys']} / {c['runtime-source-keys']} | {c['runtime-tracks']} | {c['runtime-keys']} | {c['duration']:.6f} | {c['keys_per_second']:.1f} | {c['keys_per_track']:.1f} |")
add('''## TOP 30 CLIPS nach Runtime-Keys

Es gibt nur **28** tatsächlich benötigte neue Bindungen in diesem A1-Start; alle 28 werden gezeigt. Kein Auffüllen mit nicht vorbereiteten Assets. Pfade sind unter `d:/ymir work/`, Boundary 0 = Once, 3 = Loop. Werte Before/After identisch.

| # | Clip | Boundary | Runtime Keys | Runtime Bytes | Keys/s | Keys/Track |
| --- | --- | ---: | ---: | ---: | ---: | ---: |''')
for i,c in enumerate(now['clips'],1):
    path=c['id'].split('|')[0].removeprefix('d:/ymir work/');boundary=c['id'].rsplit('|',1)[1]
    add(f"| {i} | `{path}` | {boundary} | {c['runtime-keys']} | {c['runtime-owned-bytes']} | {c['keys_per_second']:.1f} | {c['keys_per_track']:.1f} |")
add(f'''## SELECTED FIX / Alternativen / Thread-Safety

**Ein Fix: Wiederverwendung bereits geprüfter dyadischer Kurvenproben.** Drei lokale Probe-Records halten Zeit + Samplewert. Beim Split wird die vorhandene Mittelprobe als Intervallgrenze weitergereicht; Viertelproben werden den Kindern als bekannte Mittelproben angeboten. Wiederverwendung nur bei **exakt gleicher float-Zeit**. Bei abweichender Rundung wird normal neu ausgewertet. Keine Änderung an Unterteilungsentscheidung, Anzahl/Reihenfolge der drei Fehlerprüfungen, Tiefe, Toleranz, Knotengrenze, Fehlerablehnung oder Key-Publish.

Alle 28 Bindungen zusammen: **19.615.700 → 11.706.976 Source-Auswertungen**, **7.908.724 / {100*7908724/19615700:.3f} %** weniger. Der Diagnose-Gate prüft pro Clip: alte Samplecalls − neue Samplecalls = gemeldete Wiederverwendungen. Key-/Split-/Blatt-/Fehlerprüfungszahlen, Laufzeiten, IDs und Speichergrößen bleiben gleich.

Nicht gewählt: konstante Tracks sind schon kompakt; Reserve/Allocation und Bone-Lookups sind nicht der größte Kostenblock; Sort-/Index-Tabellenarbeit existiert nicht; Cache-Sharing funktioniert. Eine kompakte Source-Spline-Auswertung direkt in jedem Runtime-Frame wäre eine andere Repräsentation mit neuem Sampler-/Semantiknachweis. Sie wurde nicht gebaut. Keine Toleranzlockerung oder Keyreduktion.

BindAnimation rechnet überwiegend mit lokalem Scratch und unveränderlichen Source-/Skeletondaten. Actor-/Resource-/Documentcache und optionaler AnimationStallAudit bleiben ownerseitig; ihre gemeinsame Nutzung wäre zusätzliche Thread-Safety-Arbeit. Weil ein algorithmischer Redundanz-Fix belegt ist, wird **keine zweite Parallelisierung** gewählt. Der vorhandene L7-Workerpool bleibt ausschließlich für GR2-Dateivorbereitung zuständig.

## FIRST USE AFTER

Einzelner maximaler Runtime-Motion-Aufruf innerhalb des ersten Beobachtungsfensters; umfasst nativen Kontrollwechsel und Lookup, nicht den ~18-ms-Frame-Pacing-Takt. Alle drei Einsätze desselben Clips bleiben ohne neue Bindung/Keys/GR2-I/O.

| Actor | Motion | First Use runtime ms | Runtime preparation ms | Max Gesamtframe ms |
| --- | --- | ---: | ---: | ---: |''')
for actor in ('player','mob'):
    for motion in ('Attack','Damage','Death'):
        r=pick(actor,motion);add(f"| {actor} | {motion} | {r['runtime_motion_max_ms']:.4f} | {r['runtime_preparation_ms']:.4f} | {r['max_frame_ms']:.3f} |")
add(f'''A1 Warm nach dem Mapwechsel: **{p['l8-after'][3]['total_ms']:.3f} ms**; B1 **{p['l8-after'][2]['total_ms']:.3f} ms**. Warme Prewarm-Aufrufe erzeugen keine zusätzlichen Clipdaten. Normale Sounds/Staub können kleine eigene Loads auslösen; keine späten GR2-Assetloads und keine Rückkehr der 50–80-ms-Animation-Spitzen.

## CORRECTNESS / FAST GATE

- **Release Build PASS**, exakt finaler C++-Baum; keine Debug-/GCC-/Gesamtsuite. Die letzte Änderung danach betrifft nur Test-Harness-Auswahl/Analyse und Dokumentation.
- **903 GR2-Dateien / 7224 Sections / 60.042.028 Bytes bytegleich**, vollständige relevante IR identisch; 903 halbierte Inputs weiterhin abgelehnt.
- **13 reale Modell-/Clip-Paare**, Keys/Zeiten/Dauer/Tracks/Bone-Bindings/Interpolation bitgleich für alle vier Boundary-Slots gegen `GR2AnimationPreparationReference.h`. Diese eingefrorene Testreferenz enthält den Vorher-Algorithmus und wird nicht in den Client gelinkt.
- **234 bestehende Runtime-Posevergleiche PASS**, zusätzlich **468 Vorher/Nachher-Sampler-/World-Transform-/Palette-Vergleiche PASS**. Alle Warm-First-Use-Bindungen ohne weitere Konvertierung. Kein sichtbarer Unterschied aus einem ungemessenen manuellen Test behauptet.
- **7/7 gezielte Tests PASS**, einschließlich Warmup-Allokation/Lebensdauer, Golden static/animation, Safety, Compatibility, Preparation, Independence.
- **A1 → B1 → A1, 36 First/Second/Third Uses, Exit 0 PASS**. Diligent ERROR/FATAL = **0**, GPU fallback = **0**, CPU deformation = **0**, Shutdown-Ressourcen = **0**, NativePrewarmFailures/Limited = **0**.
- Native Before/After-Mapdaten, Requests/Hits, Section-CRCs/Bytes, Registrierungen, Kopierbytes und Shaderbytecode identisch. Kein ausgelassener Clip; gleiche 28 echte Bindungen. Keine beobachteten Race-/Deadlocksymptome. Kein ThreadSanitizer-Nachweis behauptet.
- Gefüllter Shadercache unverändert, kein Shader-Miss/Runtime-Compile. Originalclient-EXE/Rootpack, Area-Parallelismus und SSE2-Decoder bleiben geschützt. Kein Deployment, kein Netzwerklogin, keine Visual-Galerie, kein weiterer Performancebereich verändert.

**FAST GATE PASS. FINAL GO:** vollständiger Prewarm nachweisbar günstiger, A1 Production Cold klar schneller als beide seriellen Referenzen, L7-Parallelisierung und stallfreier First Use erhalten, alle Korrektheits-/Ressourcenprüfungen bestanden. Kein zweiter Runtime-Fix wird begonnen.

## Evidenz / Reproduktion / Commit

`build-p0l8/build-release.log`, `corpus-runtime.log`, `focused-tests.log`, `start.diff`, `start-hashes.json`; pro Lauf unter `build-p0l/<Name>/` native Trace, `first-use-analysis.json`, `runtime-preparation.json` (nur Profile), `fast-gate.json`, Exit/Audit und Probe-Hashes. `l8-before-detail` hatte keine aktivierten Detailzähler und wird als Diagnose verworfen, nicht als PASS umgedeutet. Die gültigen Detaildaten stammen ausschließlich aus `l8-before-profile` / `l8-after-profile`.

`prepare_probe.ps1 -ShaderLifecycle -AnimationFirstUse -LoadPrewarm` für Zeitläufe; zusätzlich `-RuntimePreparationDetails` nur für Mengendiagnose. Der serielle vollständige Kontrollpfad nutzt `-SerialAnimationLoading` **und die gesicherte Vorher-EXE**. Ressourcen-/Daten-Gate: `verify_runtime_preparation.py <before> <after> <profile-before> <profile-after>`. Frische Namen erforderlich; keine bestehenden Beweise überschreiben.

| Lauf | Release-EXE SHA256 |
| --- | --- |''')
for n in names+['l8-before-profile','l8-after-profile']:
    add(f"| `{n}` | `{hashlib.sha256((root/'build-p0l'/n/'Metin2_Release.exe').read_bytes()).hexdigest().upper()}` |")
add('''Commit erst nach diesem GO, nur Source/Tests/Doku von L7/L7C/L8. Die Python-Ladegrenze gehört zum separaten Runtime-Source-Repository und benötigt dort einen eigenen Commit. Keine Logs, Traces, Builds, Cachedateien, Testclients oder Backup-EXEs stagen. Die beiden Abschluss-Hashes werden im Abschlussbericht der Task angegeben; keine Commit-Selbstreferenz in diesem Dokument. Kein Push. **STOP nach P0-L8.**''')
report=re.sub(r'(?m)(^\|[^\n]*\n)\n(?=\|)',r'\1','\n\n'.join(parts))
(root/'docs/performance/p0l8-animation-runtime-prewarm.md').write_text(report+'\n',encoding='utf-8')
print(json.dumps(dict(final='GO',cold_before=before,cold_after=after,cold_serial=cold('l8-serial-complete'),prewarm_before=prewarm('l8-before'),prewarm_after=prewarm('l8-after')),indent=2))
