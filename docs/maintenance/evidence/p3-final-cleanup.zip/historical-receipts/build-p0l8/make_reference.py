from pathlib import Path
p=Path('build-p0l8/GR2AnimationReader-before.cpp').read_text()
begin=p.index('template<std::size_t N> std::array<float,N> SampleCurve')
end=p.index('\n}\nAnimationData ReadAnimation',begin)
bind=p.index('std::shared_ptr<const AnimationRuntime::RuntimeAnimationClip> BindAnimation(')
tail=p[bind:].rstrip()
assert tail.endswith('}\n}')
tail=tail[:-2]
header='''#pragma once
// Frozen pre-P0-L8 adaptive conversion oracle. Test only: never compiled into
// the client. Keep independent arithmetic and control flow for bitwise parity.
#include "AssetRuntime/GR2/GR2Reader.h"
#include "AssetRuntime/GR2/GR2AssetProvider.h"
#include "AssetRuntime/AnimationStallAudit.h"
#include "EterBase/MapLoadTrace.h"
#include <algorithm>
#include <cmath>
#include <limits>
namespace AssetRuntime::GR2::PreparationReference {
'''
Path('tests/AssetRuntime/GR2AnimationPreparationReference.h').write_text(header+p[begin:end]+ '\n'+tail+'\n}\n')
