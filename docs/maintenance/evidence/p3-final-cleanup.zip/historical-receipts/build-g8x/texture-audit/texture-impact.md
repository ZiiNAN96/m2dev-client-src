# G8 texture impact audit

Counts come from effective pack entries, tile usage and placed environment properties. Terrain references count tile files; object references count distinct model files. Tile samples include duplicated borders. Map counts are distinct authored map roots, not active server maps. Categories use descriptive filenames or native vegetation part kinds; ambiguous names remain Unclassified.

| Texture | Category | Maps | Asset references | Placed instances |
| --- | --- | ---: | ---: | ---: |
| `d:/ymir work/tree/compositemapb1.dds` | Leaves, Vegetation atlas | 47 | 15 | 5062 |
| `d:/ymir work/tree/pagodatreebark.dds` | Bark | 45 | 5 | 2018 |
| `d:/ymir work/tree/compositemapb3.dds` | Leaves, Vegetation atlas | 43 | 16 | 1598 |
| `d:/ymir work/tree/beechbark.dds` | Bark | 42 | 8 | 2352 |
| `d:/ymir work/tree/montereycypressbark.dds` | Bark | 42 | 5 | 1316 |
| `d:/ymir work/zone/b/obj/general_obj_stone02.dds` | Stone | 36 | 5 | 358 |
| `d:/ymir work/zone/b/obj/general_obj_brazier_01.dds` | Unclassified | 34 | 5 | 418 |
| `d:/ymir work/zone/b/obj/general_obj_stone01.dds` | Stone | 34 | 3 | 300 |
| `d:/ymir work/zone/b/obj/general_obj_brazier.dds` | Unclassified | 31 | 21 | 1392 |
| `d:/ymir work/zone/b/obj/b_general_obj_18.dds` | Unclassified | 29 | 15 | 577 |
| `d:/ymir work/zone/b/obj/general_obj_stone18.dds` | Stone | 28 | 1 | 163 |
| `d:/ymir work/zone/b/obj/ob-7-all-01.dds` | Unclassified | 27 | 6 | 976 |
| `d:/ymir work/zone/b/obj/general_obj_stonebox.dds` | Stone | 27 | 4 | 174 |
| `d:/ymir work/zone/b/obj/general_obj_stone04.dds` | Stone | 27 | 3 | 553 |
| `d:/ymir work/zone/b/obj/general_obj_stone03.dds` | Stone | 26 | 3 | 434 |
| `d:/ymir work/zone/b/obj/b_general_obj_06.dds` | Unclassified | 25 | 13 | 317 |
| `d:/ymir work/zone/b/obj/ob-b1-001-015.dds` | Unclassified | 24 | 9 | 977 |
| `d:/ymir work/zone/b/obj/general_obj_stone13.dds` | Stone | 24 | 2 | 149 |
| `d:/ymir work/zone/b/obj/obj-0002-9.dds` | Unclassified | 23 | 5 | 260 |
| `d:/ymir work/tree/sassafrasbark.dds` | Bark | 22 | 2 | 381 |
| `d:/ymir work/zone/b/obj/warpgate02.dds` | Unclassified | 22 | 2 | 74 |
| `d:/ymir work/terrainmaps/dungeon/field 01.dds` | Dirt | 21 | 290 | 0 |
| `d:/ymir work/zone/b/obj/general_obj_stone19.dds` | Stone | 21 | 2 | 137 |
| `d:/ymir work/zone/b/obj/warpgate03.dds` | Unclassified | 21 | 2 | 62 |
| `d:/ymir work/zone/b/obj/b_general_obj_02.dds` | Unclassified | 20 | 7 | 208 |
| `d:/ymir work/zone/b/obj/general_obj_suspension bridge01.dds` | Unclassified | 19 | 3 | 122 |
| `d:/ymir work/tree/umbrellathornbark.dds` | Bark | 18 | 4 | 380 |
| `d:/ymir work/zone/b/building/b1s-002-inwall-02.dds` | Unclassified | 18 | 3 | 122 |
| `d:/ymir work/zone/b/obj/general_obj_drum.dds` | Unclassified | 18 | 2 | 87 |
| `d:/ymir work/zone/b/obj/general_obj_stone14.dds` | Stone | 18 | 1 | 120 |
| `d:/ymir work/terrainmaps/b/field/field 04.dds` | Dirt | 17 | 174 | 0 |
| `d:/ymir work/zone/b/obj/general_obj_bigtower01.dds` | Unclassified | 17 | 12 | 279 |
| `d:/ymir work/zone/b/obj/ob-bigstone.dds` | Stone | 16 | 4 | 461 |
| `d:/ymir work/zone/b/obj/general_obj_tent.dds` | Unclassified | 16 | 2 | 119 |
| `d:/ymir work/zone/b/building/b1-bigdam-01.dds` | Unclassified | 15 | 6 | 1629 |
| `d:/ymir work/zone/b/obj/obj-0010jomyoung-all.dds` | Unclassified | 15 | 2 | 79 |
| `d:/ymir work/zone/b/building/b1-bigdam-02.dds` | Unclassified | 15 | 1 | 73 |
| `d:/ymir work/zone/b/building/b1-bigdam-03.dds` | Unclassified | 15 | 1 | 73 |
| `d:/ymir work/terrainmaps/b/grass/grass 03.dds` | Grass | 14 | 85 | 0 |
| `d:/ymir work/zone/b/obj/general_obj_bigstonegate.dds` | Stone | 14 | 11 | 107 |
| `d:/ymir work/zone/b/obj/b_general_obj_03.dds` | Unclassified | 14 | 4 | 87 |
| `d:/ymir work/zone/b/obj/general_obj_carriage.dds` | Unclassified | 14 | 1 | 43 |
| `d:/ymir work/terrainmaps/b/tile/tile01.dds` | Path, Stone | 13 | 52 | 0 |
| `d:/ymir work/tree/compositemapn2.dds` | Leaves, Vegetation atlas | 13 | 22 | 3542 |
| `d:/ymir work/zone/b/obj/ob-bigstatue01-01.dds` | Unclassified | 13 | 1 | 21 |
| `d:/ymir work/zone/b/obj/ob-bigstatue01-02.dds` | Unclassified | 13 | 1 | 21 |
| `d:/ymir work/tree/compositemapb2.dds` | Leaves, Vegetation atlas | 12 | 15 | 599 |
| `d:/ymir work/zone/b/obj/general_obj_ferryboat.dds` | Unclassified | 12 | 8 | 30 |
| `d:/ymir work/zone/b/obj/sign.dds` | Unclassified | 12 | 1 | 31 |
| `d:/ymir work/terrainmaps/b/field/field 01.dds` | Dirt | 11 | 115 | 0 |

## Coverage

{
  "schema": 1,
  "input_sha256": "1ceb2cff655480cc3f605b32c87cb8b196cce97e340ff40567765822bdfda73f",
  "legacy_text_decode_replacements": 30,
  "effective_entries": 50983,
  "audited_files": 16709,
  "maps_with_texture_sets": 85,
  "placed_environment_assets": 896,
  "missing_packs": [],
  "placed_gr2_parse_errors": [],
  "all_gr2_parse_error_count": 1,
  "missing_placed_models": [
    "d:/maiinbase.gr2",
    "d:/project/metin2/data/zone/devils_dragon_island/ships_brokenbody00.gr2",
    "d:/ymir work/guild/building/generaltomb.gr2",
    "d:/ymir work/zone/b/obj/ob-11-03-bonetunnel04.gr2",
    "d:/ymir work/zone/devils_dragon_island/bone_whale_tail00.gr2",
    "d:/ymir work/zone/dungeon/devil_underground/cliff_01.gr2",
    "d:/ymir work/zone/dungeon/devil_underground/cliff_corner.gr2",
    "d:/ymir work/zone/metin_test/a3_building.gr2",
    "d:/ymir work/zone/sample0000/666.gr2",
    "d:/ymir work/zone/\uacf5\uc6a9/hay_02.gr2"
  ],
  "categories": {
    "Grass": 36,
    "Dirt": 63,
    "Path": 2,
    "Rock": 6,
    "Stone": 118,
    "Wood": 20,
    "Cliff": 5,
    "Bark": 26,
    "Leaves": 5,
    "Unclassified": 418
  }
}

Modern water normals are generated, so no replacement texture is ranked. Repository/pack mismatches and unresolved links remain in the JSON evidence. Pixel coverage and player travel frequency are not measured. No textures have been replaced.
