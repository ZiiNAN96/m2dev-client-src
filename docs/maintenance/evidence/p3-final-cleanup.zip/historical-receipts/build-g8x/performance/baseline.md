# G8 / P-X performance baseline

First 180 sample=1 frames per preset, starting after two seconds of warmup. The screenshot occurs after six seconds and is outside this equal frame window. No timing outliers removed. CPU is steady elapsed frame work excluding Present and frame limiter; it is not OS process CPU accounting. GPU is the existing asynchronous frame duration query. Draws are actor frontend draws, not all renderer passes. One bounded run per build; no confidence interval.

1024 x 768, D3D11, VSync and existing 16/17 ms limiter; six actors on the same B1 camera. G8 uses the production moving-cloud clock. G7 has no animated atmosphere clouds. Water time is fixed in both runs. GPU gates and capture series ran sequentially; no build ran during the measurements. An earlier private normal-client launch remained idle with no world-frame log and Windows denied cleanup access; this is a sanity measurement, not a fully isolated benchmark. Hardware inventory is in evidence/hardware-*.json; the existing counter does not identify the selected adapter.

| Build | Preset | CPU avg / median / P95 / P99 ms | GPU avg / median / P95 / P99 ms | Actor draws avg |
| --- | --- | --- | --- | ---: |
| baseline | Low | 0.962 / 0.756 / 1.112 / 4.272 | 0.252 / 0.199 / 0.575 / 0.899 | 28 |
| baseline | Medium | 1.123 / 1.085 / 1.395 / 1.475 | 0.459 / 0.362 / 0.908 / 1.419 | 56 |
| baseline | High | 1.324 / 1.258 / 1.704 / 1.946 | 0.723 / 0.579 / 1.468 / 1.581 | 56 |
| baseline | Ultra | 1.788 / 1.681 / 2.397 / 2.545 | 0.944 / 0.809 / 1.748 / 2.018 | 56 |
| final | Low | 1.164 / 0.956 / 1.392 / 3.976 | 0.257 / 0.218 / 0.599 / 0.937 | 45 |
| final | Medium | 1.421 / 1.223 / 1.523 / 1.714 | 0.489 / 0.384 / 1.008 / 1.204 | 56 |
| final | High | 1.385 / 1.325 / 1.695 / 1.959 | 0.797 / 0.602 / 1.602 / 1.997 | 56 |
| final | Ultra | 1.673 / 1.611 / 2.085 / 2.328 | 0.903 / 0.797 / 1.689 / 1.888 | 56 |

## Whole-run CPU submission counters

These include first-use initialization and preset changes; they are not isolated GPU pass timings or warm percentiles. Nested totals are not additive. GPU pass-specific timers do not exist in this harness.

| Pass | G7 total ms | G8 total ms |
| --- | ---: | ---: |
| shadowCpuSubmitMs | 611.848 | 627.772 |
| aoCpuSubmitMs | 375.276 | 385.602 |
| atmosphereCpuSubmitMs | 222.138 | 270.892 |
| bloomCpuSubmitMs | 38.417 | 40.094 |
| toneMapCpuSubmitMs | 9.892 | 7.655 |
| compositeCpuSubmitMs | 54.288 | 54.846 |
| waterCpuSubmitMs | 26.126 | 27.480 |
| ssrCpuSubmitMs | 382.561 | 383.463 |

## First use and resources

The direct-map fixture bypasses network LoadingWindow, so its cold first-use frames include compilation. The existing normal-client loading prewarm invokes the same atmosphere constructor and shader. A hitch-free network relog is not established by this fixture.

| Build | Low / Medium / High / Ultra warmup maximum CPU ms | Atmosphere target bytes | Frames |
| --- | --- | ---: | ---: |
| baseline | 1131.7 / 480.6 / 376.0 / 182.0 | 9318384 | 1612 |
| final | 1508.0 / 186.1 / 378.7 / 181.8 | 10104816 | 1622 |

Low gains a real 512 shadow cascade in G8, explaining 45 versus 28 actor draws. Medium/High/Ultra retain 56 actor draws. The larger sky atlas adds 786432 bytes (0.75 MiB). No gross regression is indicated by this bounded rig; it does not replace later P-X profiling.

Full counters, shader/PSO creation events, binary hashes and all frame statistics are in baseline.json. Raw captures remain in performance-baseline and performance-acceptance.
