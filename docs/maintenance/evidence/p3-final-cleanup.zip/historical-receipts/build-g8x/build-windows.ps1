param([string]$Configuration='Release',[switch]$Configure)
$ErrorActionPreference='Stop'
$source=(Resolve-Path "$PSScriptRoot/..").Path
& 'C:/Program Files/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation *> "$PSScriptRoot/evidence/vs-$Configuration.log"
if($Configure) {
    & cmake --fresh -S $source -B "$PSScriptRoot/msvc" -G 'Visual Studio 17 2022' -A x64 -DM2_BUILD_ASSET_TOOL=ON "-DFETCHCONTENT_SOURCE_DIR_DILIGENTCORE=$source/build-deps/DiligentCore" "-DFETCHCONTENT_SOURCE_DIR_M2DILIGENTFXSOURCE=$source/build-deps/DiligentFX" "-DFETCHCONTENT_SOURCE_DIR_ZIINAN_ASSIMP=$source/build-deps/assimp" "-DFETCHCONTENT_SOURCE_DIR_ZIINAN_MESHOPTIMIZER=$source/build-deps/meshoptimizer" *> "$PSScriptRoot/evidence/configure.log"
    if($LASTEXITCODE -ne 0){Get-Content "$PSScriptRoot/evidence/configure.log" -Tail 35;throw 'Configure failed'}
}
& cmake --build "$PSScriptRoot/msvc" --config $Configuration --parallel 6 *> "$PSScriptRoot/evidence/build-$Configuration.log"
if($LASTEXITCODE -ne 0){Get-Content "$PSScriptRoot/evidence/build-$Configuration.log" -Tail 55;throw 'Build failed'}
Write-Output "$Configuration build PASS"

