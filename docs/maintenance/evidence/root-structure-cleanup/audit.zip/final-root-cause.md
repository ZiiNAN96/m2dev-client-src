# Root cause before edits

- Diligent-GraphicsEngineD3D11-shared: LNK2001/LNK1120 for five XXH128State
  methods. Our ShaderLoadAudit.cmake replaces RenderDeviceD3D11Impl.cpp with an
  instrumented generated copy. ShaderLoadAudit.h invokes XXH128State; its
  implementation is XXH128Hasher.cpp in Diligent-GraphicsTools. The instrumented
  Diligent-GraphicsEngineD3D11-static target does not declare that dependency.
  The shared target only receives its declared static dependency closure, which
  lacks GraphicsTools and its xxHash dependency. The normal client separately
  receives GraphicsTools through M2DiligentFX. Declare the private dependency
  on the instrumented static target in our integration CMake file.
- WideIndexRenderTest: LNK2001/LNK1120 for
  Platform::Time::MonotonicNanoseconds, called in DiligentD3D11Backend.cpp.
  Its implementation is Win32Time.cpp in M2Platform. M2RendererDiligent does not
  declare M2Platform, while the normal client/bootstrap already links it.
  Declare the private dependency on M2RendererDiligent, so standalone consumers
  inherit its required static-library link closure.

Both symbol providers already exist at correct Release paths. Their exported
library symbols were checked with dumpbin. Generated projects contain neither
old build-deps nor build-h2x paths; the actual output/import-library naming is
correct. Missing dependency edges also explain the absent build-order edges.
The relevant CMake declarations are unchanged from baseline e83dd0a: the source
relocation did not introduce the missing dependencies. No separate historical
baseline build is claimed. No stale library copy, new library implementation,
upstream edit, runtime behavior change or per-test workaround is needed.
