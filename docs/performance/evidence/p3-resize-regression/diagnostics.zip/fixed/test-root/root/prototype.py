import builtins, traceback
try:
    """Private native A1 closure probe: uses the real GameWindow and its existing HUD.
    
    No network session, production pack or production config is modified. Baseline
    mode records the unfixed layout; acceptance mode checks the same controls.
    """
    import app, builtins, grp, json, os, systemSetting, time, traceback, ui, wndMgr
    import background, chr, chrmgr, item, player, playersettingmodule, mouseModule
    
    width, height = systemSetting.GetWidth(), systemSetting.GetHeight()
    wndMgr.SetScreenSize(width, height)
    app.Create("P3 Resize Regression - private A1", width, height, 1)
    app.SetMouseHandler(mouseModule.mouseController)
    wndMgr.SetMouseHandler(mouseModule.mouseController)
    assert mouseModule.mouseController.Create()
    log = builtins.old_open("resize-run.jsonl", "w")
    
    
    def emit(event, **values):
        values.update(event=event, seconds=time.monotonic())
        log.write(json.dumps(values) + "\n")
        log.flush()
    
    
    assert app.LoadLocaleData(app.GetLocalePath())
    item.LoadItemTable(app.GetLocalePath() + "/item_proto")
    getattr(playersettingmodule, "__LoadGameNPC")()
    getattr(playersettingmodule, "__LoadGameEffect")()
    for name in ("INIT", "WARRIOR", "ASSASSIN", "SURA", "SHAMAN"):
        playersettingmodule.LoadGameData(name)
    background.Initialize()
    background.LoadMap("metin2_map_a1", 63500.0, 59000.0, 0.0)
    origin = (63500, 59000, background.GetHeight(63500, 59000))
    chr.CreateInstance(57900)
    chr.SelectInstance(57900)
    chr.SetVirtualID(57900)
    chr.SetInstanceType(6)
    chr.SetRace(0)
    chr.SetArmor(11299)
    chr.SetHair(1001)
    chr.SetWeapon(19)
    chr.SetMotionMode(chr.MOTION_MODE_ONEHAND_SWORD)
    chr.SetLoopMotion(chr.MOTION_WAIT)
    chr.SetPixelPosition(*map(int, origin))
    chr.Show()
    player.SetMainCharacterIndex(57900)
    for key in range(player.MAX_NUM):
        player.SetStatus(key, 0)
    for key, value in ((player.LEVEL, 54), (player.MAX_HP, 5000), (player.HP, 4500),
                       (player.MAX_SP, 3000), (player.SP, 2600), (player.STAT, 1),
                       (player.SKILL_ACTIVE, 1), (player.ATT_SPEED, 100), (player.MOVING_SPEED, 100),
                       (player.ST, 80), (player.HT, 60), (player.DX, 35), (player.IQ, 10),
                       (player.EXP, 250000), (player.NEXT_EXP, 500000)):
        player.SetStatus(key, value)
    app.SetCenterPosition(origin[0], -origin[1], origin[2] + 100)
    
    import game
    
    
    class RealGame(game.GameWindow):
        # Only add renderer prewarm instrumentation. Layout/update/render remain the
        # normal game path, including all interface and game-owned controls.
        def OnRender(self):
            if getattr(self, "prewarm", True):
                assert chrmgr.PrewarmVisibleActors(True)
                self.prewarm = False
            game.GameWindow.OnRender(self)
    
    
    # Appended to the existing native RealGame fixture. No test window coordinates
    # replace the product's default Open/Show rules.
    import net, uiCommon
    world = RealGame(None)
    sendEnter = net.SendEnterGamePacket
    try:
        net.SendEnterGamePacket = lambda: None
        world.Open()
    finally:
        net.SendEnterGamePacket = sendEnter
    world.RefreshStatus()
    app.SetCamera(5500.0, 22.0, 0.0, 0.0)
    interface = world.interface
    import event, uiQuest
    quest_index = event.RegisterEventSetFromString('[DONE]')
    quest = uiQuest.QuestDialog(0, quest_index)
    curtain = uiQuest.QuestDialog.QuestCurtain
    
    def geometry(window):
        return dict(position=window.GetGlobalPosition(), size=(window.GetWidth(),window.GetHeight()), visible=bool(window.IsShow()))
    
    def snapshot(label):
        state = dict(label=label, ui=(wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight()),
                     game=geometry(world), top=geometry(curtain.TopBar), bottom=geometry(curtain.BottomBar),
                     curtain_mode=curtain.CurtainMode, bar_height=curtain.BarHeight)
        if hasattr(systemSetting, 'TestDisplayGeometry'):
            state['native'] = systemSetting.TestDisplayGeometry()
            state['residency'] = systemSetting.TestWorldResidency()
        emit('snapshot', **state)
    
    def open_ui():
        interface.OpenCharacterWindowWithState('STATUS')
        interface.wndInventory.Show()
        if interface.wndInventory.wndBelt: interface.wndInventory.wndBelt.OpenInventory()
        interface.dlgSystem._SystemDialog__ClickSystemOptionButton()
        interface.dlgSystem.systemOptionDlg.OpenGraphics()
    
    def panels():
        windows = {name:getattr(interface,name) for name in ('wndInventory','wndCharacter','wndTaskBar','wndChat','wndMiniMap')}
        windows['belt']=interface.wndInventory.wndBelt
        windows['graphics']=interface.dlgSystem.systemOptionDlg.graphicsDialog
        return {name:geometry(window) for name,window in windows.items() if window}
    
    def check(label, expected):
        w,h=expected
        assert (wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight())==(w,h)
        g=systemSetting.TestDisplayGeometry()
        for prefix in ('Client','Backbuffer','UIScreen','CPUViewport','RenderViewport'):
            assert (g[prefix+'Width'],g[prefix+'Height'])==(w,h),(label,prefix,g)
        for bar in (curtain.TopBar,curtain.BottomBar):
            x,y=bar.GetGlobalPosition()
            assert bar.GetWidth()==w,(label,'stale width')
            assert y+bar.GetHeight()<=0 or y>=h,(label,'black bar',geometry(bar))
        p=panels()
        expected_positions={'wndInventory':(w-176,h-602),'wndCharacter':(24,(h-398)//2),
            'wndTaskBar':(0,h-37),'wndChat':((w-600)//2,h-62),'wndMiniMap':(w-136,0),
            'belt':(w-324,h-361),'graphics':((w-700)//2,(h-510)//2)}
        for name,pos in expected_positions.items():
            assert p[name]['position']==pos,(label,name,p[name],pos)
        snapshot(label)
        emit('check_pass',label=label,panels=p)
        return p
    
    def matrix(probe):
        open_ui()
        yield .5
        first=check('A-start',(1280,960))
        for label,size in [('B-grow',(1920,1200)),('C-shrink',(1024,768)),('A-return',(1280,960)),
                           ('horizontal',(1664,960)),('vertical',(1664,1176))]:
            systemSetting.TestGraphicsWindow(*size)
            yield .7
            check(label,size)
            if label=='B-grow': probe.shot='fixed-grow'
        for cycle in range(3):
            for name,size in [('A',(1280,960)),('B',(1920,1200)),('A',(1280,960))]:
                systemSetting.TestGraphicsWindow(*size)
                yield .4
                current=check('cycle-%d-%s'%(cycle,name),size)
                if name=='A': assert current==first,('layout drift',cycle)
        for size in ((1320,980),(1450,1000),(1200,850),(1740,1180),(1280,960)):
            systemSetting.TestGraphicsWindow(*size)
            yield .08
        yield .6
        assert check('multi-resize',(1280,960))==first
        systemSetting.ApplyGraphicsSettings({'displayMode':1})
        yield .6
        systemSetting.ConfirmDisplaySettings()
        size=(wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight())
        check('borderless',size)
        probe.shot='fixed-borderless'
        systemSetting.ApplyGraphicsSettings({'displayMode':0,'resolutionWidth':1280,'resolutionHeight':960})
        yield .6
        systemSetting.ConfirmDisplaySettings()
        assert check('windowed-return',(1280,960))==first
        # The cinematic bars must still open, follow live width and close normally.
        curtain.CurtainMode=1
        yield 1
        assert curtain.TopBar.GetGlobalPosition()==(0,0)
        systemSetting.TestGraphicsWindow(1600,1200)
        yield .7
        assert curtain.TopBar.GetWidth()==1600
        assert curtain.BottomBar.GetGlobalPosition()==(0,1200-curtain.BarHeight)
        curtain.CurtainMode=-1
        yield 1
        check('cinema-closed-after-resize',(1600,1200))
        systemSetting.TestGraphicsWindow(1280,960)
        yield .7
        assert check('final-A',(1280,960))==first
        before=systemSetting.TestWorldResidency()
        yield 2
        after=systemSetting.TestWorldResidency()
        for key in ('terrainLoaded','terrainUnloaded','areasLoaded','areasUnloaded','terrainAssignments','instanceBufferCreates','treeCreated'):
            assert before[key]==after[key],('idle recreation',key,before,after)
        emit('idle_stability_pass',before=before,after=after)
        emit('matrix_pass',cycles=3)
        probe.shot='fixed-final-A'
    
    class Probe(ui.Window):
        def __init__(self):
            ui.Window.__init__(self, 'TOP_MOST')
            self.Show()
            self.deadline=time.monotonic()+3
            self.last_size=None
            self.shot=None
            self.count=0
            self.done=False
            self.steps=None
        def OnUpdate(self):
            if self.done or time.monotonic()<self.deadline: return
            try:
                if self.steps:
                    try:
                        self.deadline=time.monotonic()+next(self.steps)
                        return
                    except StopIteration:
                        self.steps=None
                size=(wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight())
                if size!=self.last_size:
                    self.last_size=size
                    self.count+=1
                    snapshot('resize-%d'%self.count)
                    self.shot='resize-%d'%self.count
                if os.path.exists('command.json'):
                    with builtins.old_open('command.json') as stream: command=json.load(stream)
                    os.remove('command.json')
                    action=command['action']
                    if action=='hide_bottom': curtain.BottomBar.Hide()
                    elif action=='show_bottom': curtain.BottomBar.Show()
                    elif action=='display':
                        systemSetting.ApplyGraphicsSettings(command['settings'])
                    elif action=='confirm': systemSetting.ConfirmDisplaySettings()
                    elif action=='snapshot': snapshot(command['label']); self.shot=command['label']
                    elif action=='close_curtain': curtain.Close()
                    elif action=='open_ui': open_ui()
                    elif action=='matrix': self.steps=matrix(self)
                    elif action=='resize': systemSetting.TestGraphicsWindow(*command['size'])
                    elif action=='check': check(command['label'],tuple(command['size']))
                    elif action=='exit':
                        snapshot('exit'); self.done=True; app.Exit()
                    emit('command', action=action)
                self.deadline=time.monotonic()+0.2
            except Exception:
                with builtins.old_open('resize-failure.log','w') as stream: stream.write(traceback.format_exc())
                self.done=True
                app.Exit()
        def OnRender(self):
            if self.shot:
                ok,path=grp.SaveScreenShotToPath(self.shot+'-')
                emit('screenshot',ok=ok,path=path)
                self.shot=None
    
    probe=Probe()
    emit('ready',diagnostics=hasattr(systemSetting,'TestDisplayGeometry'))
    app.Loop()
    probe.Hide()
    quest.CloseSelf()
    world.Close()
    log.close()
except Exception:
    with builtins.old_open("resize-failure.log", "w") as failure:
        failure.write(traceback.format_exc())
    import app
    app.Exit()
