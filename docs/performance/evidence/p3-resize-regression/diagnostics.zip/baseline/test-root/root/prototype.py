import builtins, traceback
try:
    """Private native A1 closure probe: uses the real GameWindow and its existing HUD.
    
    No network session, production pack or production config is modified. Baseline
    mode records the unfixed layout; acceptance mode checks the same controls.
    """
    import app, builtins, grp, json, os, systemSetting, time, traceback, ui, wndMgr
    import background, chr, chrmgr, item, player, playersettingmodule, mouseModule
    
    width, height = systemSetting.GetWidth(), systemSetting.GetHeight()
    wndMgr.SetScreenSize(width, height)
    app.Create("P3 Resize Regression - private A1", width, height, 1)
    app.SetMouseHandler(mouseModule.mouseController)
    wndMgr.SetMouseHandler(mouseModule.mouseController)
    assert mouseModule.mouseController.Create()
    log = builtins.old_open("resize-run.jsonl", "w")
    
    
    def emit(event, **values):
        values.update(event=event, seconds=time.monotonic())
        log.write(json.dumps(values) + "\n")
        log.flush()
    
    
    assert app.LoadLocaleData(app.GetLocalePath())
    item.LoadItemTable(app.GetLocalePath() + "/item_proto")
    getattr(playersettingmodule, "__LoadGameNPC")()
    getattr(playersettingmodule, "__LoadGameEffect")()
    for name in ("INIT", "WARRIOR", "ASSASSIN", "SURA", "SHAMAN"):
        playersettingmodule.LoadGameData(name)
    background.Initialize()
    background.LoadMap("metin2_map_a1", 63500.0, 59000.0, 0.0)
    origin = (63500, 59000, background.GetHeight(63500, 59000))
    chr.CreateInstance(57900)
    chr.SelectInstance(57900)
    chr.SetVirtualID(57900)
    chr.SetInstanceType(6)
    chr.SetRace(0)
    chr.SetArmor(11299)
    chr.SetHair(1001)
    chr.SetWeapon(19)
    chr.SetMotionMode(chr.MOTION_MODE_ONEHAND_SWORD)
    chr.SetLoopMotion(chr.MOTION_WAIT)
    chr.SetPixelPosition(*map(int, origin))
    chr.Show()
    player.SetMainCharacterIndex(57900)
    for key in range(player.MAX_NUM):
        player.SetStatus(key, 0)
    for key, value in ((player.LEVEL, 54), (player.MAX_HP, 5000), (player.HP, 4500),
                       (player.MAX_SP, 3000), (player.SP, 2600), (player.STAT, 1),
                       (player.SKILL_ACTIVE, 1), (player.ATT_SPEED, 100), (player.MOVING_SPEED, 100),
                       (player.ST, 80), (player.HT, 60), (player.DX, 35), (player.IQ, 10),
                       (player.EXP, 250000), (player.NEXT_EXP, 500000)):
        player.SetStatus(key, value)
    app.SetCenterPosition(origin[0], -origin[1], origin[2] + 100)
    
    import game
    
    
    class RealGame(game.GameWindow):
        # Only add renderer prewarm instrumentation. Layout/update/render remain the
        # normal game path, including all interface and game-owned controls.
        def OnRender(self):
            if getattr(self, "prewarm", True):
                assert chrmgr.PrewarmVisibleActors(True)
                self.prewarm = False
            game.GameWindow.OnRender(self)
    
    
    # Appended to the existing native RealGame fixture. No test window coordinates
    # replace the product's default Open/Show rules.
    import net, uiCommon
    world = RealGame(None)
    sendEnter = net.SendEnterGamePacket
    try:
        net.SendEnterGamePacket = lambda: None
        world.Open()
    finally:
        net.SendEnterGamePacket = sendEnter
    world.RefreshStatus()
    app.SetCamera(5500.0, 22.0, 0.0, 0.0)
    interface = world.interface
    import event, uiQuest
    quest_index = event.RegisterEventSetFromString('[DONE]')
    quest = uiQuest.QuestDialog(0, quest_index)
    curtain = uiQuest.QuestDialog.QuestCurtain
    
    def geometry(window):
        return dict(position=window.GetGlobalPosition(), size=(window.GetWidth(),window.GetHeight()), visible=bool(window.IsShow()))
    
    def snapshot(label):
        state = dict(label=label, ui=(wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight()),
                     game=geometry(world), top=geometry(curtain.TopBar), bottom=geometry(curtain.BottomBar),
                     curtain_mode=curtain.CurtainMode, bar_height=curtain.BarHeight)
        if hasattr(systemSetting, 'TestDisplayGeometry'):
            state['native'] = systemSetting.TestDisplayGeometry()
            state['residency'] = systemSetting.TestWorldResidency()
        emit('snapshot', **state)
    
    class Probe(ui.Window):
        def __init__(self):
            ui.Window.__init__(self, 'TOP_MOST')
            self.Show()
            self.deadline=time.monotonic()+3
            self.last_size=None
            self.shot=None
            self.count=0
            self.done=False
        def OnUpdate(self):
            if self.done or time.monotonic()<self.deadline: return
            try:
                size=(wndMgr.GetScreenWidth(),wndMgr.GetScreenHeight())
                if size!=self.last_size:
                    self.last_size=size
                    self.count+=1
                    snapshot('resize-%d'%self.count)
                    self.shot='resize-%d'%self.count
                if os.path.exists('command.json'):
                    with builtins.old_open('command.json') as stream: command=json.load(stream)
                    os.remove('command.json')
                    action=command['action']
                    if action=='hide_bottom': curtain.BottomBar.Hide()
                    elif action=='show_bottom': curtain.BottomBar.Show()
                    elif action=='display':
                        systemSetting.ApplyGraphicsSettings(command['settings'])
                    elif action=='confirm': systemSetting.ConfirmDisplaySettings()
                    elif action=='snapshot': snapshot(command['label']); self.shot=command['label']
                    elif action=='close_curtain': curtain.Close()
                    elif action=='open_ui':
                        interface.OpenCharacterWindowWithState('STATUS')
                        interface.wndInventory.Show()
                        if interface.wndInventory.wndBelt: interface.wndInventory.wndBelt.OpenInventory()
                        interface.dlgSystem._SystemDialog__ClickSystemOptionButton()
                        interface.dlgSystem.systemOptionDlg.OpenGraphics()
                    elif action=='exit':
                        snapshot('exit'); self.done=True; app.Exit()
                    emit('command', action=action)
                self.deadline=time.monotonic()+0.2
            except Exception:
                with builtins.old_open('resize-failure.log','w') as stream: stream.write(traceback.format_exc())
                self.done=True
                app.Exit()
        def OnRender(self):
            if self.shot:
                ok,path=grp.SaveScreenShotToPath(self.shot+'-')
                emit('screenshot',ok=ok,path=path)
                self.shot=None
    
    probe=Probe()
    emit('ready',diagnostics=hasattr(systemSetting,'TestDisplayGeometry'))
    app.Loop()
    probe.Hide()
    quest.CloseSelf()
    world.Close()
    log.close()
except Exception:
    with builtins.old_open("resize-failure.log", "w") as failure:
        failure.write(traceback.format_exc())
    import app
    app.Exit()
