import ctypes as c, json, sys
from ctypes import wintypes as w
u = c.WinDLL('user32', use_last_error=True)
u.SetThreadDpiAwarenessContext.argtypes=[w.HANDLE]
u.SetThreadDpiAwarenessContext.restype=w.HANDLE
u.SetThreadDpiAwarenessContext(w.HANDLE(-4))
u.GetDpiForWindow.argtypes=[w.HWND]
u.GetWindowDpiAwarenessContext.argtypes=[w.HWND]
u.GetWindowDpiAwarenessContext.restype=w.HANDLE
u.GetAwarenessFromDpiAwarenessContext.argtypes=[w.HANDLE]
u.GetClientRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
u.GetWindowRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
u.IsIconic.argtypes=[w.HWND]
hwnd=w.HWND(int(sys.argv[1]))
client,outer=w.RECT(),w.RECT()
assert u.GetClientRect(hwnd,c.byref(client))
assert u.GetWindowRect(hwnd,c.byref(outer))
print(json.dumps(dict(hwnd=hwnd.value,dpi=u.GetDpiForWindow(hwnd),awareness=u.GetAwarenessFromDpiAwarenessContext(u.GetWindowDpiAwarenessContext(hwnd)),client=[client.right,client.bottom],physicalOuter=[outer.left,outer.top,outer.right,outer.bottom],minimized=bool(u.IsIconic(hwnd))),indent=2))
