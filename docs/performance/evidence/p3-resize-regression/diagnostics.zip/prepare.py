from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

source = Path(__file__).resolve().parents[2]
runtime = source.parent / 'm2dev-client'
root = source / 'build/resize-regression'
target = root / sys.argv[1]
target.mkdir()
for name in ('pack', 'log', 'mark', 'upload', 'test-root'):
    (target / name).mkdir()
protected = ['config/graphics.cfg', 'config/metin2.cfg', 'Metin2_Release.exe', 'Metin2_Debug.exe', 'pack/root.pck']
receipt = {name: hashlib.sha256((runtime / name).read_bytes()).hexdigest() for name in protected}
(target / 'protected-before.json').write_text(json.dumps(receipt, indent=2))
shutil.copytree(runtime / 'config', target / 'config')
shutil.copytree(runtime / 'config', target / 'config-before')
shutil.copytree(runtime / 'assets/root', target / 'test-root/root')
shutil.copy2(source / 'build/bin/Release/Metin2_Release.exe', target / 'Metin2_Release.exe')
for pack in (runtime / 'pack').iterdir():
    if pack.is_file() and pack.name != 'root.pck':
        os.link(pack, target / 'pack' / pack.name)
for filename, values in [('graphics.cfg', {'RESOLUTION_WIDTH':1280, 'RESOLUTION_HEIGHT':960, 'DISPLAY_MODE':0}), ('metin2.cfg', {'WIDTH':1280,'HEIGHT':960,'WINDOWED':1})]:
    path = target / 'config' / filename
    lines = path.read_text().splitlines()
    path.write_text('\n'.join(str(line.split()[0])+' '+str(values[line.split()[0]]) if line.split() and line.split()[0] in values else line for line in lines)+'\n')
fixture = (source / 'tests/Graphics/p3_ui_layout_entry.py').read_text()
fixture = fixture[:fixture.index('reflow_count = 0')]
fixture = fixture.replace('P3 UI Layout Closure - private A1', 'P3 Resize Regression - private A1')
fixture = fixture.replace('closure-run.jsonl', 'resize-run.jsonl')
entry = fixture + (root / 'probe.py').read_text()
wrapped = 'import builtins, traceback\ntry:\n' + '\n'.join('    '+line for line in entry.splitlines()) + '\nexcept Exception:\n    with builtins.old_open("resize-failure.log", "w") as failure:\n        failure.write(traceback.format_exc())\n    import app\n    app.Exit()\n'
(target / 'test-root/root/prototype.py').write_text(wrapped, encoding='utf-8')
with (target / 'package.log').open('w') as log:
    subprocess.run([str(source/'build/bin/Release/PackMaker.exe'),'--input',str(target/'test-root/root'),'--output',str(target/'pack')], stdout=log, stderr=subprocess.STDOUT, check=True)
print(target)
