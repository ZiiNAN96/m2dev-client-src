# CONTENT-TX-P0 – Grass-Terrain-Proof

Stand: 16.09.2026. **Technisches GO für diesen isolierten Proof. Art Direction und Production GO: offen, ausschließlich nach Sichtabnahme.** Kein Commit, kein Push, kein Deployment in den Originalclient.

## Umfang und Ausgangspunkt

- Source: `codex/g56-hdr-atmosphere`, `def2674` (anfangs sauber).
- Originalclient: `codex/g56-hdr-colors`, `6697736a` (anfangs sauber).
- Neue Designregel: flächiges Gras entsteht durch Terrainmaterial. Bäume, Büsche, Blumen und gezielte Bodendecker bleiben Vegetationsobjekte.
- Ausschließlich A1, Slot **005**, vorher `d:/ymir work/terrainmaps/b/grass/grass 01.dds`. Dieser Slot ist mit **315.247** Maskeneinträgen der häufigste Grass-Slot; Slot 006 hat 165.682, Slot 007 hat 7.723. Zählung einschließlich vorhandener Tile-Randdaten, keine Flächenmessung.
- Heightmaps, Geometrie, Splat-Masks, Layerverteilung, Paths, Dirt, Rocks, Buildings, Water und Spawns bleiben unverändert. **317 geschützte Dateien** einschließlich aller A1-Quelldaten, TextureSets und des gesamten Texture-Packs sind nachher SHA256-identisch.

## Entfernte Arbeit, erhaltene Systeme

Der Produktionsaufruf `PrepareNativeGrass`, der vollständige Kartendurchlauf `VisitGrassTerrain`, die gespeicherten Graszellen und der Aufruf `RenderNativeGrass` sind entfernt. Damit entstehen keine Grass-Platzierungen, Grass-GPU-Batches oder Grass-Asset-Uploads mehr. Die Grasdaten-Hilfsfunktionen und portable H2-Test-APIs bleiben für mögliche spätere Editor-/Bodendeckerarbeit erhalten, werden im Produktionspfad aber nicht aufgerufen.

Unverändert bleiben ZiiNAN Vegetation Runtime, Registry, Legacy-Asset-Fallback, Bäume/Büsche, Instancing, LOD/Impostors, Wind, Leaf Flutter, Foliage Lighting und Backlighting. Die vorhandene Vegetationsqualität steuert weiterhin die Baum-/Vegetationsparameter. Es gibt keine separate anklickbare Grass-Option und keine neue UI.

## Material und Import

[Vollständiges Inventar aller 68 Dateien](../../build-content-tx-p0/evidence/texture-inventory.md), [Hashes, Formate und Kanalwerte](../../build-content-tx-p0/evidence/source-inventory.json).

Sechs Varianten liegen als rohe Texturen sowie als Unreal/glTF-Materialexport vor. Vorhanden sind BaseColor, Normal, AO, Height, Metallic und Roughness; die Materialexporte enthalten zusätzlich bei Varianten 2 und 5 gepacktes Metallic/Roughness. Die `.gltf`/`.bin`-Dateien beschreiben Material und Vorschaumesh und werden nicht in die Spielwelt importiert.

Verwendet wird genau **`T_GrassMat3_basecolor.PNG`**, die reine Grasvariante ohne aufgemalte Wege/Steine/Schnee. Die rohe BaseColor wird verwendet, nicht die sichtbar anders aufbereitete BaseColor des Materialexports. Quelle ist ausschließlich lesend geöffnet worden.

| Parameter | Proof |
|---|---|
| BaseColor | 4096² Quelle → 1024² RGBA8 DDS, 11 Mipstufen |
| Farbraum | Autorierte sRGB-Werte; bestehender Modern-Terrainshader dekodiert nach Linear |
| Mipfilter | Offline in linearem Licht; keine Farbkorrektur oder künstlichen Maps |
| Metallic | 0; kein metallischer Term |
| Specular | 0; bestehende diffuse Terrainbeleuchtung |
| Roughness | Matt/diffus; kein Roughness-Sampler oder zusätzlicher PBR-Pfad |
| Normal/AO/Height | Reale Quellen inventarisiert, im Proof nicht gebunden |
| Texture Scale | Originalslot unverändert: U/V = 9, Offset = 0; HTP-Periode 3200/9 ≈ 355,6 Welteinheiten ≈ 3,56 m |
| Sampling | Bestehendes Wrap- und Mip-Filtering; keine Anti-Tiling-Erweiterung |

Die echte Normalmap zeigt eine tangententypische +Z-Verteilung. Ihre Y-Konvention wurde anhand Height-/Normaldaten geprüft, aber nicht belastbar für einen Terrain-Tangentenraum bestätigt. Deshalb wird kein Green-Flip vorgenommen und kein Normalmapping behauptet. Der vorhandene Terrainpfad unterstützt diffuse Farbe und Geometrienormalen; ein neuer Terrain-PBR-/Tangentenpfad liegt außerhalb dieses Proofs. Metallic/Roughness/AO werden somit auch nicht versehentlich als sRGB-Farben geladen.

Die DDS-Kanten unterscheiden sich durchschnittlich um 4,72 / 3,87 Kanalstufen; benachbarte innere Texel um 4,72 / 3,73. Damit entsteht keine auffällige zusätzliche Kantenstufe. Die Aufnahmen zeigen die vorhandenen Maskenübergänge unter Sonne, Schatten, SSAO, HDR und Tone Mapping. Langfristiges Bewegungsflimmern und die künstlerische Eignung bleiben Teil der Sichtabnahme.

## Modern-only Override

Der bestehende Pack-Dateizugriff und Terrain-Uploader laden optional `terrain/modern/<map>/slot-NNN.dds`. Die Zuordnung enthält Karte und Slot. Nur der isolierte C-/normale Testclient enthält **`terrain/modern/metin2_map_a1/slot-005.dds`**. Es gibt keinen globalen Austausch des alten Grass-Dateinamens und keine Änderung der TextureSet-Dateien.

Der Map-Loader erfasst vorhandene Override-Pfade; GPU-Texturen werden erst bei einem Modern-Draw geladen. Classic nutzt die Originaltextur. Original- und Modern-Farbmaterial teilen dieselbe unveränderte Splat-Maske und besitzen getrennte gecachte Bindings, sodass der Live-Wechsel Modern → Classic → Modern sicher funktioniert. Beide werden beim Kartenabbau freigegeben. Ohne Override-Datei bleiben die bisherigen Terrainfarben erhalten.

## Kurzer Performance-Sanity

Gleiche A1-Kamera, Modern/High, gleiche Umgebung und Sonne, festgehaltene Wind-/Himmelzeit. Erste 180 markierte Frames nach zwei Sekunden Aufwärmen; drei kurze nacheinander ausgeführte Läufe ohne gleichzeitigen Build/GPU-Test. CPU ist Framearbeit ohne Present/Limiter; GPU stammt aus der vorhandenen Frame-Abfrage. Keine Perzentile, kein Langbenchmark.

| Messwert | A: alt + 3D-Gras | B: alt, ohne Gras | C: neue Textur, ohne Gras |
|---|---:|---:|---:|
| Map-Load, ms | 153,37 | 71,65 | 76,56 |
| Grass-Preparation, ms | 78,43 | 0 | 0 |
| Grass-Platzierungen | 625.189 | 0 | 0 |
| Grass-Platzierungsdaten, MiB | 19,08 | 0 | 0 |
| Vegetation Draws / Frame, inkl. Schatten | 55 | 49 | 49 |
| CPU-Framearbeit Mittel, ms | 4,076 | 0,648 | 0,634 |
| GPU-Framezeit Mittel, ms | 0,562 | 0,491 | 0,490 |

Das kleine Fenster zeigt keine relevante Regression; die Grass-Arbeit entfällt eindeutig. Ladezeiten hängen auch von Cache und Systemlast ab und sind keine garantierte allgemeine FPS-/Ladezeitverbesserung. [Rohwerte und Auswertung](../../build-content-tx-p0/evidence/comparison.json).

## A/B/C und Prüfungen

[Interaktive Galerie](../../build-content-tx-p0/gallery/index.html) · [alle drei nebeneinander](../../build-content-tx-p0/gallery/ABC.jpg).

- **A:** Original Terrain + bisheriges 3D-Gras, unveränderte alte Release-EXE.
- **B:** Original Terrain, ohne flächiges 3D-Gras.
- **C:** Ohne 3D-Gras, neue BaseColor ausschließlich in A1-Slot 005.

Kamera: A1 `(13000, 9500, 17668.5)`, Distanz/Pitch/Rotation `(4500, 25, 0)`, 1024×768. Alle drei Zustände verwenden identische Einstellungen. Der frühere Kamera-Vorlauf auf dem Stadtpflaster ist separat unter `evidence/pilot-a` abgelegt und gehört nicht zur Galerie oder den Vergleichszahlen.

| Prüfung | Ergebnis |
|---|---|
| Betroffener Release-Client und Testtargets | PASS |
| Terrain CPU/GPU, Vegetation Contracts/Modern/GPU, benötigte Asset-Fixture | **6/6 PASS**, 14,02 s |
| A1 native A/B/C und Live-Stylewechsel | PASS, alle Läufe Exit 0 |
| Classic gegen unveränderte alte EXE | B und C im Weltbild **pixelgenau**; obere 50 Zeilen mit Zustandslabel ausgenommen |
| Neue Textur tatsächlich geladen | Genau ein protokollierter Override, A1/Slot 005 |
| Grass nach Load und nach Stylewechsel | Platzierungen/Zellen/Tiles/Bytes/Preparation jeweils 0 |
| Diligent ERROR/FATAL | **0/0** |
| Shutdown-Ressourcen | **0**, native A/B/C und Classic-Referenz |
| Geschützte Quellen/Mapdaten | **317/317 SHA256-identisch** |
| GCC/LP64 | NOT RUN: keine portable/core Logik geändert |
| Vollständige Classic-Golden-/Gesamtsuite | NOT RUN; gezielter A1-Bildvergleich durchgeführt |

Beim ersten Build-/Startversuch blockierte die eingeschränkte Umgebung Windows-SDK bzw. Clientinitialisierung. Die erlaubten Wiederholungen außerhalb dieser Umgebung bestanden. Der gemeinsame Modern-Teststarter erwartet auch bei einem Classic-only Lauf eine Modern-Logdatei; die Classic-Referenz wurde daher anschließend direkt anhand Exit 0, Aufnahme, leerem Game-Errorlog und Null-Ressourcenzählern validiert. Es wurde keine fehlende Modern-Datei als echte Renderstörung gewertet.

[Gebündelter Nachweis mit Binär-/Sourcehashes](../../build-content-tx-p0/evidence/result.json), [gezieltes Testprotokoll](../../build-content-tx-p0/evidence/targeted-release.log), [Importparameter](../../build-content-tx-p0/evidence/import.json).

## Sichtabnahme / STOP

Der normale isolierte Testclient liegt unter `build-content-tx-p0/runtime-manual/`, mit originalem Einstiegsskript und Modern/High. Er wurde sichtbar geöffnet und bleibt für die Sichtabnahme verfügbar. Die neue Farbe ist nur auf A1/Slot 005 sichtbar; die Entfernung des flächigen 3D-Grases gilt für den neuen Client allgemein.

Bekannte Grenze: C wirkt deutlich heller und gelbgrüner als die alte Grass-Textur; die Packfarbe wurde bewusst unverändert übernommen. Ob dieser Stil zum gewünschten Metin2-Remaster passt, entscheidet der Nutzer. Es wurden keine weiteren Slots, Maps, Packs oder Materialarten ersetzt.

**Art Direction: PENDING USER. Production GO: PENDING USER. CONTENT-TX-X wird nicht begonnen.**

Abnahmefragen: Ist B ohne 3D-Gras besser? Passt C? Bleiben Farbe/Stil Metin2? GO für diese Grass-Art-Direction?
