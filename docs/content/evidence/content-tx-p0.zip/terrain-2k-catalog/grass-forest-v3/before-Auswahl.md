# 2K-Bodentexturen: Auswahl und Zuordnung

Stand: 16.09.2026. 38 ausgewählte Basismaterialien für 218 Terrain-Referenzen in 85 vorhandenen Maps (37 TextureSets). Eine schwarze Hilfstextur bleibt erhalten. 18 besondere Oberflächen benötigen aus den ausgewählten Basen eine eigene Variante. Bei 16 Referenzen fehlt die Original-Bilddatei; diese Vorschläge sind nur anhand von Dateiname und Kontext zugeordnet.

[Interaktive Übersicht mit Alt/Neu-Vorschau](Boden-2K-Auswahl.html) · [Vollständige Zuordnung](alt-neu-zuordnung.csv) · [Strukturierte Daten](catalog.json)

Alle 38 Quellen bieten echte 2K-Dateien. Die Download-Metadaten wurden direkt bei den Anbietern geprüft. Die Vorschauen sind verkleinert. Das freigegebene Grass004 wird mit der vorhandenen Dunkelgrün-Korrektur gezeigt; alle weiteren Bilder zeigen die unbearbeiteten Farbtexturen. Einheitliche Helligkeit, Maßstab, Kachelung und Übergänge sind beim späteren Einbau zu prüfen. Sondervarianten sind als Arbeitsvorschläge gekennzeichnet und noch nicht hergestellt.

Rechercheumfang: Terrain-Boden und Terrain-Felsflächen. Texturen von separaten Gebäude-/Objektmodellen sowie Wasser sind nicht Bestandteil dieser Inventur. 16 Atlas-Aliase besitzen hier keine ladbaren Mapdaten und sind nicht als zusätzliche Maps gezählt.

Die 37 ambientCG-2K-Pakete umfassen zusammen etwa 2,22 GiB und wurden für diese Recherche nicht vollständig heruntergeladen. Grass004 liegt bereits in 2K vor. Für den Poly-Haven-Lehmboden wurde eine 2K-Farbdatei geprüft. Sonst wurden nur Vorschaubilder und offizielle Download-Metadaten abgerufen.

Lizenz: CC0 für alle ausgewählten Assets. Quellen: [ambientCG-Lizenz](https://docs.ambientcg.com/license/) und [Poly-Haven-Lizenz](https://polyhaven.com/license).

| Bodenart | Material | Vorschlag für | Quelle / 2K |
|---|---|---|---|
| Gras & Waldboden | Dunkelgrünes Gras (Grass004) | 34 alte Referenzen | [Quelle](https://ambientcg.com/a/Grass004) · [2K](https://ambientcg.com/get?file=Grass004_2K-PNG.zip) |
| Gras & Waldboden | Moosiger Erdboden (Ground037) | 7 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground037) · [2K](https://ambientcg.com/get?file=Ground037_2K-PNG.zip) |
| Gras & Waldboden | Dunkler Waldboden (Ground048) | 13 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground048) · [2K](https://ambientcg.com/get?file=Ground048_2K-PNG.zip) |
| Gras & Waldboden | Gras zwischen Felsen (Ground068) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground068) · [2K](https://ambientcg.com/get?file=Ground068_2K-PNG.zip) |
| Erde & Wege | Brauner Boden mit Kies (Ground085) | 9 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground085) · [2K](https://ambientcg.com/get?file=Ground085_2K-PNG.zip) |
| Erde & Wege | Festgetretene Erde (Ground103) | 12 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground103) · [2K](https://ambientcg.com/get?file=Ground103_2K-PNG.zip) |
| Erde & Wege | Raue Erde (Ground106) | 4 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground106) · [2K](https://ambientcg.com/get?file=Ground106_2K-PNG.zip) |
| Erde & Wege | Rötliche Erde (Ground067) | 6 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground067) · [2K](https://ambientcg.com/get?file=Ground067_2K-PNG.zip) |
| Erde & Wege | Trockener Sandboden (Ground087) | 1 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground087) · [2K](https://ambientcg.com/get?file=Ground087_2K-PNG.zip) |
| Erde & Wege | Rissiger Lehmboden (mud_cracked_dry_riverbed_002) | 1 alte Referenzen | [Quelle](https://polyhaven.com/a/mud_cracked_dry_riverbed_002) · [2K](https://dl.polyhaven.org/file/ph-assets/Textures/png/2k/mud_cracked_dry_riverbed_002/mud_cracked_dry_riverbed_002_diff_2k.png) |
| Sand & Kies | Feiner Sand (Ground079L) | 7 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground079L) · [2K](https://ambientcg.com/get?file=Ground079L_2K-PNG.zip) |
| Sand & Kies | Sand mit kleinen Steinen (Ground079S) | 4 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground079S) · [2K](https://ambientcg.com/get?file=Ground079S_2K-PNG.zip) |
| Sand & Kies | Sand mit Windrillen (Ground093A) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Ground093A) · [2K](https://ambientcg.com/get?file=Ground093A_2K-PNG.zip) |
| Sand & Kies | Dunkler Kies (Gravel040) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Gravel040) · [2K](https://ambientcg.com/get?file=Gravel040_2K-PNG.zip) |
| Sand & Kies | Flusskiesel (Rocks022) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Rocks022) · [2K](https://ambientcg.com/get?file=Rocks022_2K-PNG.zip) |
| Fels & Stein | Grauer Naturfels (Rock030) | 13 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock030) · [2K](https://ambientcg.com/get?file=Rock030_2K-PNG.zip) |
| Fels & Stein | Dunkler Vulkanfels (Rock031) | 9 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock031) · [2K](https://ambientcg.com/get?file=Rock031_2K-PNG.zip) |
| Fels & Stein | Geschichteter Fels (Rock051) | 8 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock051) · [2K](https://ambientcg.com/get?file=Rock051_2K-PNG.zip) |
| Fels & Stein | Roter Fels (Rock029) | 4 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock029) · [2K](https://ambientcg.com/get?file=Rock029_2K-PNG.zip) |
| Fels & Stein | Brauner Sandstein (Rock061) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock061) · [2K](https://ambientcg.com/get?file=Rock061_2K-PNG.zip) |
| Fels & Stein | Bemooster Fels (Rock057) | 11 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock057) · [2K](https://ambientcg.com/get?file=Rock057_2K-PNG.zip) |
| Fels & Stein | Heller Fels (Rock026) | 6 alte Referenzen | [Quelle](https://ambientcg.com/a/Rock026) · [2K](https://ambientcg.com/get?file=Rock026_2K-PNG.zip) |
| Pflaster & Platten | Altes Steinpflaster (PavingStones070) | 5 alte Referenzen | [Quelle](https://ambientcg.com/a/PavingStones070) · [2K](https://ambientcg.com/get?file=PavingStones070_2K-PNG.zip) |
| Pflaster & Platten | Unregelmäßiges Pflaster (PavingStones141) | 5 alte Referenzen | [Quelle](https://ambientcg.com/a/PavingStones141) · [2K](https://ambientcg.com/get?file=PavingStones141_2K-PNG.zip) |
| Pflaster & Platten | Graue Steinplatten (PavingStones111) | 14 alte Referenzen | [Quelle](https://ambientcg.com/a/PavingStones111) · [2K](https://ambientcg.com/get?file=PavingStones111_2K-PNG.zip) |
| Pflaster & Platten | Gebrochene Steinplatten (PavingStones054) | 5 alte Referenzen | [Quelle](https://ambientcg.com/a/PavingStones054) · [2K](https://ambientcg.com/get?file=PavingStones054_2K-PNG.zip) |
| Pflaster & Platten | Sechseckiges Pflaster (PavingStones130) | 1 alte Referenzen | [Quelle](https://ambientcg.com/a/PavingStones130) · [2K](https://ambientcg.com/get?file=PavingStones130_2K-PNG.zip) |
| Pflaster & Platten | Dunkle Bruchsteinplatten (Tiles093) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Tiles093) · [2K](https://ambientcg.com/get?file=Tiles093_2K-PNG.zip) |
| Pflaster & Platten | Verwitterter Plattenboden (Tiles130) | 5 alte Referenzen | [Quelle](https://ambientcg.com/a/Tiles130) · [2K](https://ambientcg.com/get?file=Tiles130_2K-PNG.zip) |
| Schnee & Eis | Geschlossene Schneedecke (Snow010A) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Snow010A) · [2K](https://ambientcg.com/get?file=Snow010A_2K-PNG.zip) |
| Schnee & Eis | Schnee auf Gras (Snow015) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Snow015) · [2K](https://ambientcg.com/get?file=Snow015_2K-PNG.zip) |
| Schnee & Eis | Schnee auf Erde (Snow012) | 1 alte Referenzen | [Quelle](https://ambientcg.com/a/Snow012) · [2K](https://ambientcg.com/get?file=Snow012_2K-PNG.zip) |
| Schnee & Eis | Festgetretener Schnee (Snow013) | 3 alte Referenzen | [Quelle](https://ambientcg.com/a/Snow013) · [2K](https://ambientcg.com/get?file=Snow013_2K-PNG.zip) |
| Schnee & Eis | Fein gerissenes Eis (Ice003) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Ice003) · [2K](https://ambientcg.com/get?file=Ice003_2K-PNG.zip) |
| Schnee & Eis | Groß gerissenes Eis (Ice004) | 1 alte Referenzen | [Quelle](https://ambientcg.com/a/Ice004) · [2K](https://ambientcg.com/get?file=Ice004_2K-PNG.zip) |
| Lava & Vulkan | Offene Lava (Lava004) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Lava004) · [2K](https://ambientcg.com/get?file=Lava004_2K-PNG.zip) |
| Lava & Vulkan | Dunkle Lavakruste (Lava002) | 2 alte Referenzen | [Quelle](https://ambientcg.com/a/Lava002) · [2K](https://ambientcg.com/get?file=Lava002_2K-PNG.zip) |
| Lava & Vulkan | Fließende Lava (Lava001) | 1 alte Referenzen | [Quelle](https://ambientcg.com/a/Lava001) · [2K](https://ambientcg.com/get?file=Lava001_2K-PNG.zip) |

## Besondere Varianten

- `d:/ymir work/terrainmaps/bayblacksand/bayblacksand_seagrass.dds` → Rock057 + Ground037: Unterwasserbewuchs: dunkle, kühle Variante mit erkennbaren Wasserpflanzen ausarbeiten. Rock057 liefert nur die Stein-/Moosbasis.
- `d:/ymir work/terrainmaps/b/tile/tile01.dds` → Tiles130: Das charakteristische Ornament aus dem Original erhalten; Tiles130 liefert nur das Steinmaterial.
- `d:/ymir work/terrainmaps/b/tile/tile06.dds` → Tiles130: Das charakteristische Ornament aus dem Original erhalten; Tiles130 liefert nur das Steinmaterial.
- `d:/ymir work/terrainmaps/dungeon/devilcave/dc_spider_00.dds` → Rock031: Spinnweben aus dem Original als eigenes Detail erhalten; Rock031 ist nur die Felsbasis.
- `d:/ymir work/terrainmaps/dungeon/devilcave/dc_tile_00.dds` → Tiles093: Dungeonspezifische Ornamente erhalten; Steinfarbe und Fugen am Original orientieren.
- `d:/ymir work/terrainmaps/empirewar/snow/stone01.dds` → Rock026 + Snow010A: Schneeschicht auf Fels als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/stone02.dds` → Rock026 + Snow010A: Schneeschicht auf Fels als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/stone03.dds` → Rock026 + Snow010A: Schneeschicht auf Fels als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/tile01.dds` → PavingStones111 + Snow010A: Schnee und vorhandene Plattenfugen als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/tile02.dds` → PavingStones070 + Snow010A: Schnee und Pflaster als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/tile03.dds` → PavingStones111 + Snow010A: Schnee und vorhandene Plattenfugen als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/empirewar/snow/tile04.dds` → PavingStones111 + Snow010A: Schnee und Pflaster kombinieren; fehlendes Original vor dem Einbau prüfen.
- `d:/ymir work/terrainmaps/n/snow.m/ice_quest.dds` → Ice003: Bläuliche Quest-Eisstruktur und markante Risse aus dem Original erhalten.
- `d:/ymir work/terrainmaps/n/snow.m/stone01.dds` → Rock026 + Snow010A: Schneeschicht auf Fels als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/n/snow.m/stone03.dds` → Rock026 + Snow010A: Schneeschicht auf Fels als eigene 2K-Variante kombinieren.
- `d:/ymir work/terrainmaps/n/snow.m/tile05.dds` → Tiles130: Das charakteristische Steinornament aus dem Original erhalten.
- `d:/ymir work/terrainmaps/trent/tile/tile02.dds` → Tiles130 + Ground037: Das charakteristische Steinornament aus dem Original erhalten; bemooste Variante ausarbeiten.
- `d:/ymir work/zone/dungeon/snow_dungeon/tile_rock00.dds` → Ice004 + Rock031: Eigenständige Fantasievariante: dunkler Fels mit blauen Eisrissen. Das Leuchten separat prüfen.
