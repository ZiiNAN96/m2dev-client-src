# Eigene Ornamententwürfe

Erstellt mit dem eingebauten Imagegen-Werkzeug, keine CLI und kein externer API-Auftrag. Beide Dateien wurden als 2048² angefordert; tatsächlich ausgegeben wurden jeweils 1254 × 1254 Pixel. Sie sind daher ausdrücklich Musterentwürfe und keine fertigen 2K-Texturen. Die generierten Bilder ersetzen in der Galerie die unpassenden Tiles130-Vorschläge. Sie sind noch nicht im Spiel eingebaut. Originalrechte bleiben maßgeblich; keine CC0-Zusage für diese Bearbeitungen.

## B/tile01 — warmer Entwurf

Datei: `../custom/OrnamentB01-Entwurf.png`. Referenz: `../old-previews/072.jpg`.

Use case: precise-object-edit. Asset type: game terrain base-color texture, exactly 2048 by 2048 pixels. Edit target: attached small square texture; it is the original old game texture, not a UI screenshot. Create a crisp detailed 2K remaster of this exact worn carved stone paving material. Preserve the reference's full top-down orthographic composition, the EXACT arrangement and size of every interlocking squared hooked Greek-key/L-shaped carved stone motif, and matching motifs at the edges; it must tile seamlessly on all four sides. Keep its subdued warm gray-beige / taupe palette, moderate darkness, tight thin dark grooves, fine mineral grain, eroded edges and slight earth in recesses. Make the weathered stone details finer and more convincing without changing the pattern layout. Uniform diffuse ambient illumination, flat unlit albedo/base color, no perspective, no cast shadows, no specular shine, no green moss blanket, no new blocks, no random cobbles, no yellow stone, no artificial sharpening halo. Full canvas texture only. No text, no labels, no frame, no collage, no reference inset. Preserve original old-world character. Output one 2048x2048 PNG.

## B/tile06 — dunkler Entwurf

Datei: `../custom/OrnamentB06-Entwurf.png`. Referenz: `../old-previews/076.jpg`.

Use case: precise-object-edit. Asset type: old fantasy game's ground material remaster preview. Edit target: reference is a flat square top-down carved dark stone texture. Rebuild this exact texture with sharper natural mineral detail. Keep the original full composition and pattern density: same interlocking angular squared hook/L-shaped meander motifs and rectangle arrangements at every location, all seen orthographically from directly above. Four edges must match as a seamless tile. Preserve the dark muted gray-brown reference color, dark thin grooves, heavily worn engraved geometric pattern, old chipped stone and restrained fine grain. Do not change the stone placement. No green moss, no cobblestones, no clean modern pavers, no strong beige/yellow cast. Calm middle contrast, no excessive speckled white noise, no lighting gradient, no glossy highlights, no strong shadows. Full canvas texture, no text, no frame, no side by side, no UI. Requested output resolution 2048x2048 pixels or larger, square.
