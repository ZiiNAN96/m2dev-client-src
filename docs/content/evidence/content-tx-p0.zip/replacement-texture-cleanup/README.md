# Ersatztexturen gelöscht

## Ersatztexturen auf Benutzerwunsch gelöscht

Nach der Rücksetzung wurden am 16.09.2026 alle gesicherten Ersatz-Bodentexturen, älteren Testkopien, Materialdownloads und eigenen Texturentwürfe entfernt. Das betrifft die Ersatzdateien im Originalclient sowie die Arbeitskopien unter `build-content-tx-p0`.

- 4.597 Dateieinträge gelöscht; wegen mehrfach verwendeter Hardlinks entsprechen sie 127 eigenständigen Dateien und rund 2,92 GB Dateidaten.
- Keine Ersatz-Bodentextur im geprüften Arbeitsbereich verblieben. Die ehemaligen Sicherungsordner enthalten nur noch Metadaten beziehungsweise leere Unterordner; sie stellen keine Textursicherung mehr dar.
- Originaltexturen, alle Packs, Konfigurationen und Programme unverändert. 12.641 geschützte Dateien erneut per SHA256 geprüft.
- Vergleichsbilder, Katalogvorschauen, Prüfnachweise und Herkunftsangaben bleiben als Dokumentation erhalten. Historische Ersatztextur-Prüfläufe können ohne erneuten Materialbezug nicht mehr wiederholt werden.
- Die ältere Release-EXE-Sicherung in `terrain-test-v4/production-deployment-v9/backup` bleibt erhalten.

Löschinventar mit Dateipfaden und SHA256: `C:/Users/ZiiNAN/Documents/GitHub/m2dev-client-src/build-content-tx-p0/replacement-texture-cleanup/deletion-plan.json`. Ergebnis: `docs/terrain-replacement-cleanup.json` im Originalclient. Der bereits geprüfte Originaltextur-Stand bleibt aktiv; für das Löschen inaktiver Dateien war kein neuer Spieltest nötig.

